Copyright 2006-2013 MarkLogic Corporation.  All Rights Reserved.

This directory contains documentation related to
the Java version of XCC (XCC/J).

The Javadocs are under the "api" directory.  The
zip file "xcc_apidocs.zip" is the same Javadoc
tree, already archived to make it easier to copy
to another system, such as a common web server.
