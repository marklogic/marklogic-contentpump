#! /bin/bash
#
# ureonrpmInstaller.sh - RPM specific code for monInstallera on SUSE

#/**
##* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

############################################################
# EXECUTION BEGINS HERE
############################################################
basedir=`dirname "$0"`
config_dir=`pwd`

export HTPASSWD_CMD="htpasswd"
export HTTPD_CMD="/etc/init.d/httpd"

# Base rpm installer for monitoring
source ${basedir}/monrpmInstaller.sh

preInstall() {
  return
}

postInstall() {
  return
}

deployNetSnmpRpms() {
  if [[ "$monitor_config_only" != "yes" ]]; then
    echo0 "Installing Net SNMP RPMs"
    monsshall "$installpkgcmd net-snmp"
    sshgw "$installpkgcmd net-snmp-utils"
    # TODO: If gateway is different than localhost?
    # good to login to gw and nagios server and
    # use the smoke test
    $installpkgcmd net-snmp-utils >> $outlog
  fi
}

deployNagiosRpms() {
  if [[ "$monitor_config_only" != "yes" ]]; then
    echo0 "Install Nagios RPMs"
    local pkgs="wget httpd php net-snmp-perl perl-Net-SNMP fping nagios-3.2.3 nagios-plugins-1.4.9 hdp_mon_nagios_addons"
    sshnagios "$installpkgcmd $pkgs"
  fi
  ensureJson ${nagioshost}
}

ensureJson() {
  local host=$1
  # Check json dependency
  is_json_enabled_on_host $host
  json_enabled=$?
  if [[ "${json_enabled}" == "0" ]]; then
    xssh $host "$installpkgcmd php-pecl-json"
  fi
  is_json_enabled_on_host ${host}
  json_enabled=$?
  if [[ "${json_enabled}" == "0" ]]; then
    echo "Error: json could not be installed using php-pecl-json"
    echo "Error: please use yum install php-pear and/or pecl to install json"
  else
    echo "php-json is enabled on ${host}"
  fi
}

