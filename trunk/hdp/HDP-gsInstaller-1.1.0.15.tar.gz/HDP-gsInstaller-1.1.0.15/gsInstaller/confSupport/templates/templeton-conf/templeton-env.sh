# The file containing the running pid
PID_FILE=TODO-TEMPLETON-PID-DIR/templeton.pid

TEMPLETON_LOG_DIR=TODO-TEMPLETON-LOG-DIR

# The console error log
ERROR_LOG=TODO-TEMPLETON-LOG-DIR/templeton-console-error.log

# The console log
CONSOLE_LOG=TODO-TEMPLETON-LOG-DIR/templeton-console.log

TEMPLETON_JAR=TODO-TEMPLETON-NAME-JAR
