#!/bin/sh

#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

##############################################################
# This script is used to bring up the KDC server on EC2 machine
# This also creates and pushes service keytabs for namenode, secondary namenode, jobtracker, datanode, tasktracker, hbase master, hivemetastore, regionserver and headless users keytabs for hdfs and smoke_test_user
# The script requires:
#                 Files named as namenode, jobtracker, snamenode, hbasemaster, hivemetastore, nodes, gateway and kdcserver be present at the same location as where this script is located
#                 File name 
##############################################################

basedir=`pwd`
source ${basedir}/gsInstaller.properties
source ${basedir}/gsLib.sh

USERS="$hdfsuser $smoke_test_user"
namenode=`cat namenode`
jobtracker=`cat jobtracker`
secondarynamenode=`cat snamenode`
slaves=`cat nodes`
regionservers=`cat hbasenodes`
gateway=`cat gateway`
hbasemaster=`cat hbasemaster`
hivemetastore=`cat hivemetastore`
kerberosServer=`cat kdcserver`
[ -n "$sshkey" ] && usesshkey="-i $sshkey"
if [[ "$SYSTEM_OS" == "$OS_SLES" ]]; then
  export KD5_UTIL_PATH="/usr/lib/mit/sbin/kdb5_util"
  export KADMIN_PATH="/usr/lib/mit/sbin/kadmin.local"
else
  if [[ "$OS_VERSION" == "5" ]]; then
    export KD5_UTIL_PATH="/usr/kerberos/sbin/kdb5_util"
    export KADMIN_PATH="/usr/kerberos/sbin/kadmin.local"
  else
    export KD5_UTIL_PATH="/usr/sbin/kdb5_util"
    export KADMIN_PATH="/usr/sbin/kadmin.local"
  fi
fi

#########################
# Function to generate a kerberos principal
# takes a space delimited list or principals and a keytab file
#########################
function generateKerberosPrincipal
{
  local principals="$1"
  local keytab_file="$2"
  #delete the existing keytab file
  ssh ${usesshkey} root@$kerberosServer "rm -rf $keytab_file"

  for principal in $principals
  do
    #check if the principal exists
    ssh ${usesshkey} root@$kerberosServer "echo 'get_principal $principal' | $KADMIN_PATH" 2>&1 | grep 'get_principal: Principal does not exist'
    if [ $? -eq 0 ]; then
      #if not then add it
      ssh ${usesshkey} root@$kerberosServer "echo 'addprinc -randkey $principal' | $KADMIN_PATH"
    fi
  done
  #now add it to the keytab
  ssh ${usesshkey} root@$kerberosServer "echo 'xst -k $keytab_file $principals' | $KADMIN_PATH"
}

###########################
# Function to scp keytab
###########################
function scp_keytab
{
  local keytab="$1"
  local host="$2"

  local cmd="ssh ${usesshkey} root@$host 'mkdir -p /etc/security/keytabs/'"
  echo $cmd
  eval $cmd
  cmd="scp ${usesshkey} root@$kerberosServer:/root/$keytab ."
  echo $cmd
  eval $cmd
  cmd="scp ${usesshkey} $keytab root@$host:/etc/security/keytabs/"
  echo $cmd
  eval $cmd
  cmd="ssh ${usesshkey} root@$host 'chmod -R 755 /etc/security/'"
  echo $cmd
  eval $cmd
  cmd="rm -rf $keytab"
  echo $cmd
  eval $cmd
}

###########################
# Function to display the host names being used
###########################
function displayEnvironment {
  echo "============="
  echo "ENVIRONMENT DETAILS"
  echo "============="
  echo "KERBEROS SERVER      = $kerberosServer"
  echo "NAMENODE             = $namenode"
  echo "JOBTRACKER           = $jobtracker"
  echo "SECONDARY NAMENODE   = $secondarynamenode"
  echo "HBASEMASTER          = $hbasemaster"
  echo "HIVEMETASTORE           = $hivemetastore"
}

###########################
# Function to update yum on the KDC
###########################
function updateYum {
  echo "============="
  echo "Updating yum"
  echo "============="
  echo "ssh ${usesshkey} root@$kerberosServer "yum update""
  ssh ${usesshkey} root@$kerberosServer "yum update"
}

###########################
# Function to install krb5-server & krb5-client package on KDC
###########################
function installKrb5Server {
  echo "============="
  echo "Installing  krb5-server package on kdc"
  echo "============="
  ssh ${usesshkey} root@$kerberosServer "${installpkgcmd} krb5-server krb5-client"
}

###########################
# Setting up the correct krb5.conf on all machines
###########################
function populateKrb5Conf {
  echo "============="
  echo "Populating all the nodes with krb5.conf with correct configuration"
  echo "============="

  printf "[logging] \n \
    default = FILE:/var/log/krb5libs.log \n \
      kdc = FILE:/var/log/krb5kdc.log \n \
      admin_server = FILE:/var/log/kadmind.log \n \n \
      [libdefaults]  \n \
      default_realm = $realm  \n \
      dns_lookup_realm = false  \n \
      dns_lookup_kdc = false  \n \
      ticket_lifetime = 24h  \n \
      forwardable = yes  \n \
      udp_preference_limit = 1  \n \n \
      [realms]  \n \
      $realm = {  \n \
      kdc = $kerberosServer:88  \n \
      admin_server = $kerberosServer:749  \n \
      default_domain = hadoop.com  \n \
      }  \n \n \
      [domain_realm]  \n \
      .hadoop.com = $realm  \n \
      hadoop.com = $realm  \n \n \
      [appdefaults]  \n \
      pam = {  \n \
      debug = false  \n \
      ticket_lifetime = 36000  \n \
      renew_lifetime = 36000  \n \
      forwardable = true  \n \
      krb4_convert = false  \n \
      }" > krb5.conf

  for host in $kerberosServer $allhosts; do
    scp ${usesshkey}  krb5.conf  root@$host:/etc/krb5.conf
  done
}

###########################
# Function to setup the correct kdc conf on all the nodes
###########################
function populateKdcConf {
  echo "============="
  echo "Populating kdc conf on all the nodes"
  echo "============="

  if [[ "$SYSTEM_OS" == "$OS_SLES" ]]; then
    krbconfpath="/var/lib/kerberos/krb5kdc"
  else
    krbconfpath="/var/kerberos/krb5kdc"
  fi
    printf "[kdcdefaults]  \n \
      v4_mode = nopreauth \n \
      kdc_ports = 0 \n \
      kdc_tcp_ports = 88 \n \n \
      [realms]  \n \
      $realm = {  \n \
      acl_file = $krbconfpath/kadm5.acl  \n \
      dict_file = /usr/share/dict/words  \n \
      admin_keytab = $krbconfpath/kadm5.keytab  \n \
      supported_enctypes = des3-hmac-sha1:normal arcfour-hmac:normal des-hmac-sha1:normal des-cbc-md5:normal des-cbc-crc:normal des-cbc-crc:v4 des-cbc-crc:afs3 \n \
      }" > kdc.conf


  for host in $kerberosServer ; do
   scp ${usesshkey}  kdc.conf  root@$host:$krbconfpath/kdc.conf
  done


}

###########################
# Function to stop iptables to let the nodes communicate with each other
###########################
function stopIptables {
  echo "============="
  echo "Stop iptables on all the nodes"
  echo "============="

  for host in $kerberosServer $allhosts; do
    ssh ${usesshkey} root@$host "/etc/init.d/iptables stop"
  done
}


###########################
# Function to create database on KDC
###########################
function createKeyDatabase {
  echo "============="
  echo "Creating key database"
  echo "============="

  ssh ${usesshkey} root@$kerberosServer "$KD5_UTIL_PATH create -s"
}

###########################
# FUnction to start KDC
###########################
function startKdc {
  echo "============="
  echo "Starting KDC"
  echo "============="

  ssh ${usesshkey} root@$kerberosServer "/sbin/chkconfig krb5kdc on"
  if [[ "$SYSTEM_OS" == "$OS_SLES" ]]; then
    ssh ${usesshkey} root@$kerberosServer "/etc/rc.d/krb5kdc start"
  else
    ssh ${usesshkey} root@$kerberosServer "/etc/rc.d/init.d/krb5kdc start"
  fi
}


###########################
# Function to create host and hdfs keytab for namenode
###########################
function createNNKeytab {
  echo "============="  
  echo "Creating NN keytab"
  echo "============="
  toLowerNamenode=`echo $namenode | tr '[:upper:]' '[:lower:]'`
  generateKerberosPrincipal "nn/$toLowerNamenode" "nn.service.keytab"

  echo " "
  echo "============="
  echo "Pushing NN keytab to $namenode"
  echo "============="
  scp_keytab "nn.service.keytab" "$namenode"
}

###########################
# Function to create hdfs keytab for secondary namenode
###########################
function createSNNKeytab {
  echo "============="
  echo "Creating SNN keytab to $secondarynamenode"
  echo "============="
  toLowerSecondaryNamenode=`echo $secondarynamenode | tr '[:upper:]' '[:lower:]'`
  generateKerberosPrincipal "nn/$toLowerSecondaryNamenode" "nn.service.keytab"

  echo " "
  echo "============="
  echo "Pushing SNN keytab to $secondarynamenode"
  echo "============="
  scp_keytab "nn.service.keytab" "$secondarynamenode"
}

###########################
# Function to create mapred keytab on jobtracker
###########################
function createJTKeytab {
  echo "============="
  echo "Creating JT keytab for $jobtracker"
  echo "============="
  toLowerJobtracker=`echo $jobtracker | tr '[:upper:]' '[:lower:]'`
  generateKerberosPrincipal "jt/$toLowerJobtracker" "jt.service.keytab"

  echo " "
  echo "============="
  echo "Pushing JT keytab to $jobtracker"
  echo "============="
  scp_keytab "jt.service.keytab" "$jobtracker"
}

###########################
# Function to create hdfs keytab on all the datanodes
###########################
function createDNKeytab {
  for host in $slaves ; do
    echo "============="
    echo "Creating DN keytab for $host"
    echo "============="
    toLowerHost=`echo $host | tr '[:upper:]' '[:lower:]'`
    generateKerberosPrincipal "dn/$toLowerHost" "dn.service.keytab"

    echo " "
    echo "============="
    echo "Pushing DN keytab to $host"
    echo "============="
    scp_keytab "dn.service.keytab" "$host"
  done

}

###########################
# Function to create mapred keytab on all the tasktrackers
###########################
function createTTKeytab {
  for host in $slaves ; do
    echo "============="
    echo "Creating TT keytab for $host"
    echo "============="
    toLowerHost=`echo $host | tr '[:upper:]' '[:lower:]'`
    generateKerberosPrincipal "tt/$toLowerHost" "tt.service.keytab"

    echo " "
    echo "============="
    echo "Pushing TT keytab to $host"
    echo "============="
    scp_keytab "tt.service.keytab" "$host"
  done
}

###########################
# Function to create hive keytab on hivemetastore and gateway
###########################
function createHiveKeytab {
  if [[ "$installhive" == "yes" ]] ; then
    for host in $hivemetastore ; do
      echo "============="
      echo "Creating hive keytab for $host"
      echo "============="
      toLowerHost=`echo $host | tr '[:upper:]' '[:lower:]'`
      generateKerberosPrincipal "hive/$toLowerHost" "hive.service.keytab"

      echo " "
      echo "============="
      echo "Pushing hive keytab to $host"
      echo "============="
      scp_keytab "hive.service.keytab" "$host"
    done
  fi
}
###########################
# Function to create hm keytab on hbasemaster
###########################
function createHMKeytab {
  if [[ "$installhbase" == "yes" ]] ; then
    echo "============="
    echo "Creating HM keytab for $hbasemaster"
    echo "============="
    toLowerHbaseMaster=`echo $hbasemaster | tr '[:upper:]' '[:lower:]'`
    generateKerberosPrincipal "hm/$toLowerHbaseMaster" "hm.service.keytab"

    echo " "
    echo "============="
    echo "Pushing HM keytab to $hbasemaster"
    echo "============="
    scp_keytab "hm.service.keytab" "$hbasemaster"
  fi
}

###########################
# Function to create rs keytab on all regionservers
###########################
function createRSKeytab {
  if [[ "$installhbase" == "yes" ]] ; then
    for host in $regionservers ; do
      echo "============="
      echo "Creating rs keytab for $host"
      echo "============="
      toLowerHost=`echo $host | tr '[:upper:]' '[:lower:]'`
      generateKerberosPrincipal "rs/$toLowerHost" "rs.service.keytab"

      echo " "
      echo "============="
      echo "Pushing rs keytab to $host"
      echo "============="
      scp_keytab "rs.service.keytab" "$host"
    done
  fi
}


###########################
# Function to create headless keytabs for all the users
###########################
function createHeadlessUserKeytab {

  for user in $USERS ; do
    echo " "
    echo "============="
    echo "Creating headless keytab for user $user"
    echo "============="
    generateKerberosPrincipal "$user@$realm" "$user.headless.keytab"
  done

  echo " "
  for user in $USERS ; do
    for host in $allhosts; do
      echo "============="
      echo "Pushing headless keytab user $user to $host"
      echo "============="
      #dont use the method as location is different
      scp ${usesshkey} root@$kerberosServer:/root/$user.headless.keytab .
      scp ${usesshkey} $user.headless.keytab root@$host:/tmp/
      ssh ${usesshkey} root@$host "chmod  755 /tmp/$user.headless.keytab"
  done
  done

}

###########################
# Function to create oozie keytab
###########################
function createOozieKeytab {
  if [ "$installoozie" != "yes" ] ; then
    return
  fi

  echo "============="
  echo "Creating oozie keytab for $oozieshost"
  echo "============="
  toLowerHost=`echo $oozieshost | tr '[:upper:]' '[:lower:]'`
  generateKerberosPrincipal "oozie/$toLowerHost" "oozie.service.keytab"

  echo " "
  echo "============="
  echo "Pushing oozie keytab to $oozieshost"
  echo "============="
  scp_keytab "oozie.service.keytab" "$oozieshost"
}

###########################
# Function to create spnego keytab
###########################
function createSpnegoKeytab {
  local hosts="$namenode $secondarynamenode"
  
  #if installing templeton add the host
  if [ "yes" == "$installtempleton" ] ; then
    hosts="$hosts $ttonhosts"
  fi
  
  if [ 'yes' == "$installoozie" ] ; then
    hosts="$hosts $oozieshost"
  fi

  #convert hosts to lowercase
  hosts="`echo $hosts | tr '[:upper:]' '[:lower:]'`"
  #de dup the hosts
  hosts="`echo $hosts | tr ' ' '\n' | sort -u | tr '\n' ' '`"
  
  for host in $hosts
  do
    principal="HTTP/${host}"
    #keytab file to use
    local keytab="spnego.service.keytab"

    echo "============="
    echo "Creating spnego keytabs for $host"
    echo "============="
    generateKerberosPrincipal "$principal" "$keytab"
  
    echo " "
    echo "============="
    echo "Pushing spnego keytab to $host"
    echo "============="    
    scp_keytab "$keytab" "$host"
  done
}

#method to install kerberos client on all machines
function installKerbClient
{
  local pkgs=""
  if [[ "$SYSTEM_OS" == "$OS_SLES" ]]; then
    pkgs="krb5-client"
  else
    pkgs="krb5-workstation"
  fi

  # install kinit everywhere
  ssh2host "`echo $allhosts  | tr ' ' ','`" "$installpkgcmd $pkgs"
}

displayEnvironment
#This is commented out as it is not needed for
#a rhel 5 image we in aws
#updateYum
installKrb5Server
installKerbClient
populateKrb5Conf
populateKdcConf
if [[ "$SYSTEM_OS" != "$OS_SLES" ]]; then
  stopIptables
fi
createKeyDatabase
startKdc
createNNKeytab
createSNNKeytab
createJTKeytab
createDNKeytab
createTTKeytab
createHiveKeytab
createHMKeytab
createRSKeytab
createOozieKeytab
createSpnegoKeytab
createHeadlessUserKeytab
