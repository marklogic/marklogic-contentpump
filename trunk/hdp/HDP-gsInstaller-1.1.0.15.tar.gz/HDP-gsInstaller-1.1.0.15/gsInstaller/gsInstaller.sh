#! /bin/bash
#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/
  clear
  basedir=`pwd`
  source ${basedir}/gsInstaller.properties
  source ${basedir}/gsCluster.properties
  source ${basedir}/gsLib.sh
  source ${basedir}/gsConfigLib.sh


  if [[ ! -z "${addon_properties_file}" && -f ${addon_properties_file} ]]; then
    source ${addon_properties_file}
  fi

  [ -f $outlog ] && rm -f $outlog
  [ -d $artifactdownloaddir ] && rm -rf $artifactdownloaddir ; mkdir -p $artifactdownloaddir
  
  echo0 "Grid Stack Installer" | tee -a $outlog
  echo
  echo0 "Installation Details" | tee -a $outlog
  
  #set install dependencies like snappy, zookeeper etc
  setInstallDependencies

  #check the install dependencies
  checkInstallDependencies

  if [[ `validatefalse $security` == "yes" ]]; then
    if [[ "$realm" != "" && "${hdfs_user_keytab}" != "" \
     && "${smoke_test_user_keytab}" != "" ]] ; then
      enablesecurity=yes
      kinitcmd="${kinitpath} -kt ${hdfs_user_keytab} ${hdfsuser};"
      kinitcmd_smoke_test_user="${kinitpath} -kt ${smoke_test_user_keytab} ${smoke_test_user};"
    else
      echo "Error: Security set to enabled but one of \"realm\", \
\"hdfs_user_keytab\" or \"smoke_test_user_keytab\" not defined "
      dumpErrorExitStatus "INIT" "Invalid settings provided to enable security";
      exit 1
    fi
  else
     enablesecurity=no
  fi

  [ `validate $installpig` == "yes" ] && installpig=yes
  [ `validate $installhbase` == "yes" ] && installhbase=yes
  [ `validate $installhcat` == "yes" ] && installhcat=yes
  [ `validate $installtempleton` == "yes" ] && installtempleton=yes
  [ `validate $installoozie` == "yes" ] && installoozie=yes
  [ `validate $enablemon` == "yes" ] && enablemon=yes
  [ `validatefalse $upgrade` == "yes" ] && upgrade=yes
  [[ -z "$hdfsuser" ]] && echo "Enter a valid hdfsuser" \
    && dumpErrorExitStatus "INIT" "Invalid HDFS user" && exit 1
  [[ -z "$mapreduser" ]]  && echo "Enter a valid mapreduser" \
    && dumpErrorExitStatus "INIT" "Invalid mapred user" && exit 1
  [[ -z "$smoke_test_user" ]]  && echo "Enter a valid smoke_test_user" \
    && dumpErrorExitStatus "INIT" "Invalid smoke test user" && exit 1
  [[ "$installhbase" == "yes" && "$hbaseuser" == "" ]] && echo "Enter a valid hbaseuser" \
    && dumpErrorExitStatus "INIT" "Invalid hbase user" && exit 1
  [[ "$installhbase" == "yes" && "$zkuser" == "" ]] && echo "Enter a valid zkuser" \
    && dumpErrorExitStatus "INIT" "Invalid zookeeper user" && exit 1
  [[ "$installhive" == "yes" && "$hiveuser" == "" ]] && echo "Enter a valid hiveuser" \
    && dumpErrorExitStatus "INIT" "Invalid hive user" && exit 1
  [[ "$installtempleton" == "yes" && "$templetonuser" == "" ]] && echo "Enter a valid templetonuser" \
    && dumpErrorExitStatus "INIT" "Invalid templeton user" && exit 1
  [[ "$installoozie" == "yes" && "$oozieuser" == "" ]] && echo "Enter a valid oozie user" \
    && dumpErrorExitStatus "INIT" "Invalid oozie user" && exit 1
  [[ "$installhcat" == "yes" && "$mysqldbhost" == "" ]] && echo "Enter a valid mysql host" \
    && dumpErrorExitStatus "INIT" "Invalid mysql host" && exit 1

  [ `validate $installsqoop` == "yes" ] && installsqoop=yes

  [ "$nnhost" == "" ] && echo "Enter a valid Namenodehost" \
    && dumpErrorExitStatus "INIT" "Invalid namenode host" && exit 1
  [ "$gwhost" == "" ] && echo "Enter a valid Gatewayhost" \
    && dumpErrorExitStatus "INIT" "Invalid gateway host" && exit 1
  [ "$snhost" == "" ] && echo "Enter a valid Secondary Namenode host" \
    && dumpErrorExitStatus "INIT" "Invalid secondary namenode host" && exit 1
  [ "$jthost" == "" ] && echo "Enter a valid Jobtracker" \
    && dumpErrorExitStatus "INIT" "Invalid jobtracker host" && exit 1
  [ "$slaves" == "" ] && echo "Enter a valid Slaves hostname list" \
    && dumpErrorExitStatus "INIT" "Invalid slaves host list" && exit 1
  [[ "$hivehost" == "" && "$installhive" == "yes" ]] && echo "Enter a valid hostname for hivemetastore" \
    && dumpErrorExitStatus "INIT" "Invalid hcat server host" && exit 1
  [[ "$ttonhosts" == "" && "$installtempleton" == "yes" ]] && echo "Enter a valid hostname for templeton" \
    && dumpErrorExitStatus "INIT" "Invalid templeton host" && exit 1
  [[ "$oozieshost" == "" && "$installoozie" == "yes" ]] && echo "Enter a valid hostname for oozieserver" \
    && dumpErrorExitStatus "INIT" "Invalid oozie server" && exit 1
  [[ "$hbmhost" == "" || "$rshosts" == "" || "$zkhosts" == "" ]] && [[ "$installhbase" == "yes" ]]  && \
    echo "Enter a valid hostname for hbasemaster, regionserver, zookeeper" \
    && dumpErrorExitStatus "INIT" "Invalid host specs for hbase" && exit 1
  if [[ "$nnsafemodetimeout" == "" ]]; then
    nnsafemodetimeout=600
  fi

  [[ "$enablemon" == "yes" && "$gangliahost" == "" ]] && echo "Enter a valid ganglia host" \
    && dumpErrorExitStatus "INIT" "Invalid ganglia host" && exit 1

  if [[ -z "${user_configs}" ]]; then
    user_configs=""
  fi

  if [[ "${user_configs}" != "" ]]; then
    validateuserconfigs ${user_configs}
    usercfgret=$?
    if [[ "$usercfgret" != "0" ]]; then
      echo "Invalid configs provided in ${user_configs}"
      dumpErrorExitStatus "INIT" "Invalid User Configs"
      exit 1
    fi
    confRoot=${user_configs}
    echo "Using configs provided from ${confRoot}" | tee -a $outlog
  else
    if [[ "$upgrade" == "yes" ]]; then
      echo "Warning: Upgrade mode - original configs not provided \
- new configs will be generated" | tee -a $outlog
    fi
  fi

  case "$package" in
    rpm|RPM)
      installpkg=rpm
      if [[ -z "$java64home" ]] ; then
         installjava="true"
      fi
      source ${basedir}/rpmInstaller.sh
      ;;
    deb|DEB|Deb)
      installpkg=deb
      source ${basedir}/debInstaller.sh
      ;;
    tar|TAR|Tar)
      installpkg=tar
      hadoopconfdir="${deploypath}/hadoop-conf"
      hcatconfdir="${deploypath}/hcat-conf"
      oozieconfdir="${deploypath}/oozie-conf"
      zkconfdir="${deploypath}/zk-conf"
      hbaseconfdir="${deploypath}/hbase-conf"
      if [[ -z "$java64home" ]] ; then
         installjava="true"
         java64home="${installdir}/jdk64/jdk1.6.0_26"
      fi
      source ${basedir}/tarInstaller.sh
      [[ -z "$installdir" ]] && echo "Specify the installdir for the tarball installation" \
      dumpErrorExitStatus "INIT" "No install dir specified for tar install" && exit 1
      ;;
     *)
      echo "Please provide the package type you want to install rpm | deb | tar"
      dumpErrorExitStatus "INIT" "Invalid package type"
      exit 1
      ;;
  esac

  displayselection
  clusterdetails

  echo -n "Proceed with above options? (y/N) "
  read CONFIRM
  if [ "${CONFIRM}" != "y" ]; then
    echo "User aborted setup, exiting..."
    dumpErrorExitStatus "INIT" "Aborted by user"
    exit 1
  fi
  echo0 "check your Install logs at : $outlog "

  case "$enableshortcircuit" in
    true)
      setshortcircuit="--dfs-client-read-shortcircuit=true --dfs-client-read-shortcircuit-skip-checksum=true"
      setshortcircuitdataaccess="--dfs-datanode-dir-perm=750 --dfs-block-local-path-access-user=${hbaseuser}" ;;
    false)
      setshortcircuit="--dfs-client-read-shortcircuit=false --dfs-client-read-shortcircuit-skip-checksum=false"
      setshortcircuitdataaccess="--dfs-datanode-dir-perm=700"
  esac

  if [[ "$enablesecurity" == "yes" && $installhbase == "yes" ]] ; then
     hbasekinitcmd="${kinitpath} -kt ${smoke_test_user_keytab} ${smoke_test_user};"
     addhbaseuser="--hbase-user=${hbaseuser}"
  fi

  ############################################################
  # EXECUTION BEGINS HERE
  ############################################################
  add2knownhosts
  if [[ "$upgrade" != "yes" ]]; then
    checkDirAreEmpty
    if [ "$?" -ne "0" ]; then
      dumpErrorExitStatus "CHECK_EMPTY_DIR" "Found non-empty data dirs"
      exit 1
    fi
  fi
  setup

  # Deploy stage
  dumpStatus "DEPLOY" "START" "ALL" ""

  dumpStatus "DEPLOY" "START" "HADOOP" ""
  deployHadoop
  dumpStatus "DEPLOY" "START" "SNAPPY" ""
  deploySnappy
  dumpStatus "DEPLOY" "START" "ZOOKEEPER" ""
  deployZookeeper
  dumpStatus "DEPLOY" "START" "HBASE" ""
  deployHbase
  dumpStatus "DEPLOY" "START" "HIVE" ""
  deployHive
  dumpStatus "DEPLOY" "START" "HCAT" ""
  deployHcat
  dumpStatus "DEPLOY" "START" "PIG" ""
  deployPig
  dumpStatus "DEPLOY" "START" "TEMPLETON" ""
  deployTempleton
  dumpStatus "DEPLOY" "START" "SQOOP" ""
  deploySqoop
  dumpStatus "DEPLOY" "START" "OOZIE" ""
  deployOozie
  dumpStatus "DEPLOY" "END" "ALL" ""

  # Post RPM install local fs dir creations
  # Create required log dirs, pid dirs etc
  # No step at this point requires a service to be started
  dumpStatus "POST-DEPLOY SETUP" "START" "ALL" ""

  dumpStatus "POST-DEPLOY SETUP" "START" "HADOOP" ""
  hadoopDirSetup
  dumpStatus "POST-DEPLOY SETUP" "START" "HIVE" ""
  hiveDirSetup
  dumpStatus "POST-DEPLOY SETUP" "START" "OOZIE" ""
  oozieDirSetup
  dumpStatus "POST-DEPLOY SETUP" "START" "ZOOKEEPER" ""
  zkDirSetup
  dumpStatus "POST-DEPLOY SETUP" "START" "HBASE" ""
  hbaseDirSetup
  dumpStatus "POST-DEPLOY SETUP" "START" "TEMPLETON" ""
  templetonDirSetup

  dumpStatus "POST-DEPLOY SETUP" "END" "ALL" ""

  # Hadoop
  dumpStatus "START" "START" "HADOOP" ""
  startHadoop
  dumpStatus "SMOKE_TEST" "RUN" "HADOOP" ""
  runHadoopSmokeTest
  dumpStatus "SMOKE_TEST" "RUN" "PIG" ""
  runPigSmokeTest

  # Hive
  dumpStatus "START" "START" "HIVE" ""
  startHive
  dumpStatus "SMOKE_TEST" "RUN" "HIVE" ""
  runHiveSmokeTest
  dumpStatus "SMOKE_TEST" "RUN" "HCAT" ""
  runHcatSmokeTest

  # Oozie
  dumpStatus "START" "START" "OOZIE" ""
  startOozie
  dumpStatus "SMOKE_TEST" "RUN" "OOZIE" ""
  runOozieSmokeTest

  # ZK
  dumpStatus "START" "START" "ZOOKEEPER" ""
  startZk
  dumpStatus "SMOKE_TEST" "RUN" "ZOOKEEPER" ""
  runZkSmokeTest

  # HBase
  dumpStatus "START" "START" "HBASE" ""
  startHbase
  dumpStatus "SMOKE_TEST" "RUN" "HBASE" ""
  runHbaseSmokeTest

  # Templeton
  dumpStatus "START" "START" "TEMPLETON" ""
  startTempleton
  dumpStatus "SMOKE_TEST" "RUN" "TEMPLETON" ""
  runTempletonSmokeTest

  # Sqoop
  dumpStatus "SMOKE_TEST" "RUN" "SQOOP" ""
  runSqoopSmokeTest

  displaySmokeTestSummary
  smoke_results=$?

  clusterdetails
  if [[ "${smoke_results}" != "0" ]]; then
    dumpErrorExitStatus "SMOKE_TEST" "Smoke Tests failed"
  else
    dumpStatus "EXIT" "OK" "SMOKE_TEST" "Smoke Tests passed"
  fi

  exit $smoke_results
