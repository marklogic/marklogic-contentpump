#! /bin/bash
#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

  function usage() {
    echo "
usage: $0 <parameters>
  Required parameters:
    --action=preinstallcheck/start/stop/deploypkg/deployconfig/smoketest     Default:start
    --services=hdfs/mapreduce/hbase/hcat/templeton/
               oozie/pig/sqoop/mon/zk                                        Default:all

  Optional parameters:
  --runpostinstallsetup              Required if this is the first start after
                                     an install. Triggers format, etc.
  "
  }

  clear
  basedir=`pwd`
  source ${basedir}/gsInstaller.properties
  source ${basedir}/gsCluster.properties
  source ${basedir}/gsLib.sh
  source ${basedir}/gsConfigLib.sh
  source ${basedir}/monLib.sh
  source ${basedir}/monInstaller.properties

  if [[ ! -z "${addon_properties_file}" && -f ${addon_properties_file} ]]; then
    source ${addon_properties_file}
  fi

  # allow root only
  [[ `id -u` -ne 0 ]] && echo0 "ERROR: Please execute $0 as root" && exit 1

  OPTS=$(getopt \
    -n $0 \
    -o '' \
    -l 'action:' \
    -l 'services:' \
    -l 'runpostinstallsetup' \
    -l 'help' \
    -- "$@")

  if [ $? != 0 ] ; then
    usage
  fi

  eval set -- "${OPTS}"
  while true ; do
    case "$1" in
      --action)
        ACTION=$2 ; shift 2
        ;;
      --services)
        SERVICES=$2 ; shift 2
        ;;
      --runpostinstallsetup)
        RUNPOSTINSTALLSETUP=1 ; shift
        ;;
      --help)
        usage ;
        exit 0
        ;;
      --)
        shift ; break
        ;;
      *)
        echo "Unknown option: $1"
        usage
        exit 1
        ;;
    esac
  done

  SERVICES=${SERVICES:-hdfs,mapreduce,hbase,hcat,templeton,oozie,pig,sqoop,mon,zk}
  ACTION=${ACTION:-start}
  RUNPOSTINSTALLSETUP=${RUNPOSTINSTALLSETUP:-0}

  HADOOP_ENABLE=0
  HDFS_ENABLE=0
  MAPREDUCE_ENABLE=0
  HBASE_ENABLE=0
  ZOOKEEPER_ENABLE=0
  PIG_ENABLE=0
  SQOOP_ENABLE=0
  TEMPLETON_ENABLE=0
  OOZIE_ENABLE=0
  HCAT_ENABLE=0
  MON_ENABLE=0

  ACTION_PREINSTALLCHECK="preinstallcheck"
  ACTION_START="start"
  ACTION_STOP="stop"
  ACTION_DEPLOYPKG="deploypkg"
  ACTION_DEPLOYCONFIG="deployconfig"
  ACTION_SMOKETEST="smoketest"

  service_list=$( echo ${SERVICES} | tr "," " " )
  service_count=0
  for svc in ${service_list}
  do
    if [[ "$svc" == "hdfs" || $svc == "HDFS" ]]; then
      HDFS_ENABLE=1
      HADOOP_ENABLE=1
      (( service_count++ ))
    elif [[ "$svc" == "mapreduce" || $svc == "MAPREDUCE" ]]; then
      MAPREDUCE_ENABLE=1
      HADOOP_ENABLE=1
      (( service_count++ ))
    elif [[ "$svc" == "hbase" || $svc == "HBASE" ]]; then
      HBASE_ENABLE=1
      (( service_count++ ))
    elif [[ "$svc" == "zk" || $svc == "ZOOKEEPER" || $svc == "ZK" ]]; then
      ZOOKEEPER_ENABLE=1
      (( service_count++ ))
    elif [[ "$svc" == "pig" || $svc == "PIG" ]]; then
      PIG_ENABLE=1
      (( service_count++ ))
    elif [[ "$svc" == "sqoop" || $svc == "SQOOP" ]]; then
      SQOOP_ENABLE=1
      (( service_count++ ))
    elif [[ "$svc" == "templeton" || $svc == "TEMPLETON" ]]; then
      TEMPLETON_ENABLE=1
      (( service_count++ ))
    elif [[ "$svc" == "oozie" || $svc == "OOZIE" ]]; then
      OOZIE_ENABLE=1
      (( service_count++ ))
    elif [[ "$svc" == "hcat" || $svc == "HCAT" ]]; then
      HCAT_ENABLE=1
      (( service_count++ ))
    elif [[ "$svc" == "mon" || $svc == "MON" ]]; then
      MON_ENABLE=1
      (( service_count++ ))
    else
      echo "Error: Invalid service specified: $svc"
      exit 1
    fi
  done

  # By default run actions on all services if none specified
  if [[ "${service_count}" == "0" ]]; then
	  HADOOP_ENABLE=1
	  HDFS_ENABLE=1
	  MAPREDUCE_ENABLE=1
	  HBASE_ENABLE=1
	  ZOOKEEPER_ENABLE=1
	  PIG_ENABLE=1
	  SQOOP_ENABLE=1
	  TEMPLETON_ENABLE=1
	  OOZIE_ENABLE=1
	  HCAT_ENABLE=1
	  MON_ENABLE=1
  fi

  # Disable services based on install flag settings
  if [[ "${HBASE_ENABLE}" == "1" && "$installhbase" != "yes" ]]; then
    HBASE_ENABLE=0
  fi
  if [[ "${HCAT_ENABLE}" == "1" && "$installhcat" != "yes" ]]; then
    HCAT_ENABLE=0
  fi
  if [[ "${PIG_ENABLE}" == "1" && "$installpig" != "yes" ]]; then
    PIG_ENABLE=0
  fi
  if [[ "${OOZIE_ENABLE}" == "1" && "$installoozie" != "yes" ]]; then
    OOZIE_ENABLE=0
  fi
  if [[ "${SQOOP_ENABLE}" == "1" && "$installsqoop" != "yes" ]]; then
    SQOOP_ENABLE=0
  fi
  if [[ "${TEMPLETON_ENABLE}" == "1" && "$installtempleton" != "yes" ]]; then
    TEMPLETON_ENABLE=0
  fi
  if [[ "$installtempleton" != "yes" && "$installhbase" != "yes" ]]; then
    if [[ "${ZOOKEEPER_ENABLE}" == "1" ]]; then
      ZOOKEEPER_ENABLE=0
    fi
  fi
  if [[ "${MON_ENABLE}" == "1" && "$enablemon" != "yes" ]]; then
    MON_ENABLE=0
  fi

  if [[ "${ACTION}" != "${ACTION_START}" &&
        "${ACTION}" != "${ACTION_STOP}" &&
        "${ACTION}" != "${ACTION_PREINSTALLCHECK}" &&
        "${ACTION}" != "${ACTION_DEPLOYPKG}" &&
        "${ACTION}" != "${ACTION_DEPLOYCONFIG}" &&
        "${ACTION}" != "${ACTION_SMOKETEST}" ]]; then
    echo "Error: Invalid action specified: ${ACTION}"
    exit 1
  fi

  # Do all easy install related checks here
  #TODO

  #set install dependencies like snappy, zookeeper etc
  setInstallDependencies

  #check the install dependencies
  checkInstallDependencies

  # Below is copy-pasted code from gsInstaller.sh
  # Need to keep below code in sync

  echo0 "Grid Stack Installer"
  echo
  echo0 "Installation Details"

  [ -f $outlog ] && rm -f $outlog
  [ -d $artifactdownloaddir ] && rm -rf $artifactdownloaddir ; mkdir -p $artifactdownloaddir

  if [[ `validatefalse $security` == "yes" ]]; then
    if [[ "$realm" != "" && "${hdfs_user_keytab}" != "" \
     && "${smoke_test_user_keytab}" != "" ]] ; then
      enablesecurity=yes
      kinitcmd="${kinitpath} -kt ${hdfs_user_keytab} ${hdfsuser};"
      kinitcmd_smoke_test_user="${kinitpath} -kt ${smoke_test_user_keytab} ${smoke_test_user};"
    else
      echo "Error: Security set to enabled but one of \"realm\", \
\"hdfs_user_keytab\" or \"smoke_test_user_keytab\" not defined "
      exit
    fi
  else
     enablesecurity=no
  fi

  [ `validate $installpig` == "yes" ] && installpig=yes
  [ `validate $installhbase` == "yes" ] && installhbase=yes
  [ `validate $installhcat` == "yes" ] && installhcat=yes
  [ `validate $installtempleton` == "yes" ] && installtempleton=yes
  [ `validate $installoozie` == "yes" ] && installoozie=yes
  [ `validate $enablemon` == "yes" ] && enablemon=yes
  [ `validatefalse $upgrade` == "yes" ] && upgrade=yes
  [[ -z "$hdfsuser" ]] && echo "Enter a valid hdfsuser" && exit 1
  [[ -z "$mapreduser" ]]  && echo "Enter a valid mapreduser" && exit 1
  [[ -z "$smoke_test_user" ]]  && echo "Enter a valid smoke_test_user" && exit 1
  [[ "$installhbase" == "yes" && "$hbaseuser" == "" ]] && echo "Enter a valid hbaseuser" && exit 1
  [[ "$installhbase" == "yes" && "$zkuser" == "" ]] && echo "Enter a valid zkuser" && exit 1
  [[ "$installhcat" == "yes" && "$hcatuser" == "" ]] && echo "Enter a valid hcatuser" && exit 1
  [[ "$installtempleton" == "yes" && "$templetonuser" == "" ]] && echo "Enter a valid templetonuser" && exit 1
  [[ "$installoozie" == "yes" && "$oozieuser" == "" ]] && echo "Enter a valid oozie user" && exit 1
  [[ "$installhcat" == "yes" && "$mysqldbhost" == "" ]] && echo "Enter a valid mysql host" && exit 1

  [ `validate $installsqoop` == "yes" ] && installsqoop=yes

  [ "$nnhost" == "" ] && echo "Enter a valid Namenodehost" && exit 1
  [ "$gwhost" == "" ] && echo "Enter a valid Gatewayhost" && exit 1
  [ "$snhost" == "" ] && echo "Enter a valid Secondary Namenode host" && exit 1
  [ "$jthost" == "" ] && echo "Enter a valid Jobtracker" && exit 1
  [ "$slaves" == "" ] && echo "Enter a valid Slaves hostname list" && exit 1
  [[ "$hcshost" == "" && "$installhcat" == "yes" ]] && echo "Enter a valid hostname for hcatserver" && exit 1
  [[ "$ttonhosts" == "" && "$installtempleton" == "yes" ]] && echo "Enter a valid hostname for templeton" && exit 1
  [[ "$oozieshost" == "" && "$installoozie" == "yes" ]] && echo "Enter a valid hostname for oozieserver" && exit 1
  [[ "$hbmhost" == "" || "$rshosts" == "" || "$zkhosts" == "" ]] && [[ "$installhbase" == "yes" ]]  && \
    echo "Enter a valid hostname for hbasemaster, regionserver, zookeeper" && exit 1
  if [[ "$nnsafemodetimeout" == "" ]]; then
    nnsafemodetimeout=600
  fi

  [[ "$enablemon" == "yes" && "$gangliahost" == "" ]] && echo "Enter a valid ganglia host" && exit 1
  [[ "$enablemon" == "yes" && "$nagioshost" == "" ]] && echo "Enter a valid nagios host" && exit 1
  [[ "$enablemon" == "yes" && "$dashboardhost" == "" ]] && echo "Enter a valid dashboard host" && exit 1

  if [[ -z "${user_configs}" ]]; then
    user_configs=""
  fi

  if [[ "${user_configs}" != "" ]]; then
    validateuserconfigs ${user_configs}
    usercfgret=$?
    if [[ "$usercfgret" != "0" ]]; then
      echo "Invalid configs provided in ${user_configs}"
      exit 1
    fi
    confRoot=${user_configs}
    echo "Using configs provided from ${confRoot}" | tee -a $outlog
  else
    if [[ "$upgrade" == "yes" ]]; then
      echo "Warning: Upgrade mode - original configs not provided \
- new configs will be generated" | tee -a $outlog
    fi
  fi

  case "$package" in
    rpm|RPM)
      installpkg=rpm
      hadoopconfdir="/etc/hadoop"
      hcatconfdir="/etc/hcatalog"
      oozieconfdir="/etc/oozie"
      zkconfdir="/etc/zookeeper"
      hbaseconfdir="/etc/hbase"
      pigconfdir="/etc/pig"
      jdkinstallpath=${jdkinstallpath:-/usr}
      if [[ -z "$java32home" || -z "$java64home" ]] ; then
        installjava="true"
        java32home="${jdkinstallpath}/jdk32/jdk1.6.0_26"
        java64home="${jdkinstallpath}/jdk64/jdk1.6.0_26"
        hadoopjdk64link="ln -fs ${jdkinstallpath}/jdk64/jdk1.6.0_26 ${jdkinstallpath}/hadoop-jdk1.6.0_26"
        hadoopjdk32link="ln -fs ${jdkinstallpath}/jdk32/jdk1.6.0_26 ${jdkinstallpath}/hadoop-jdk1.6.0_26"
      else
        hadoopjdk64link="ln -sf ${java64home} ${jdkinstallpath}/hadoop-jdk1.6.0_26"
        hadoopjdk32link="ln -sf ${java32home} ${jdkinstallpath}/hadoop-jdk1.6.0_26"
      fi
      source ${basedir}/rpmInstaller.sh
      source ${basedir}/monrpmInstaller.sh
      ;;
    deb|DEB|Deb)
      installpkg=deb
      source ${basedir}/debInstaller.sh
      echo "DEB not supported"
      exit 1
      ;;
    tar|TAR|Tar)
      installpkg=tar
      hadoopconfdir="${deploypath}/hadoop-conf"
      hcatconfdir="${deploypath}/hcat-conf"
      oozieconfdir="${deploypath}/oozie-conf"
      zkconfdir="${deploypath}/zk-conf"
      hbaseconfdir="${deploypath}/hbase-conf"
      if [[ -z "$java32home" ]]  || [[ -z "$java64home" ]] ; then
         installjava="true"
         java32home="${installdir}/jdk32/jdk1.6.0_26"
         java64home="${installdir}/jdk64/jdk1.6.0_26"
      fi
      source ${basedir}/tarInstaller.sh
      [[ -z "$installdir" ]] && echo "Specify the installdir for the tarball installation" && exit 1
      echo "Tar not supported"
      exit 1
      ;;
     *)
      echo "Please provide the package type you want to install rpm | deb | tar"
      exit 1
      ;;
  esac

  displayselection
  clusterdetails

  if [[ "$enablemon" == "yes" ]]; then
    moncollectserverlist;
    mondisplayselection
  fi

  echo0 "check your Install logs at : $outlog "
  allhosts="gateway namenode snamenode jobtracker nodes"
  [[ "$installhbase" == "yes" ]] && allhosts="${allhosts} hbasemaster hbasenodes zknodes"
  [[ "$installhcat" == "yes" ]] && allhosts="${allhosts} hcatserver"
  [[ "$installtempleton" == "yes" ]] && allhosts="${allhosts} templetonnode zknodes"
  [[ "$installoozie" == "yes" ]] && allhosts="${allhosts} oozieserver"
  allhosts="$(cat $allhosts | sort | uniq)"

  case "$enableshortcircuit" in
    true)
      setshortcircuit="--dfs-client-read-shortcircuit=true --dfs-client-read-shortcircuit-skip-checksum=true"
      setshortcircuitdataaccess="--dfs-datanode-dir-perm=750 --dfs-block-local-path-access-user=${hbaseuser}" ;;
    false)
      setshortcircuit="--dfs-client-read-shortcircuit=false --dfs-client-read-shortcircuit-skip-checksum=false"
      setshortcircuitdataaccess="--dfs-datanode-dir-perm=700"
  esac

  if [[ "$enablesecurity" == "yes" && $installhbase == "yes" ]] ; then
     hbasekinitcmd="${kinitpath} -kt ${smoke_test_user_keytab} ${smoke_test_user};"
     addhbaseuser="--hbase-user=${hbaseuser}"
  fi

  ############################################################
  # EXECUTION BEGINS HERE
  ############################################################

  smoke_results=0
  add2knownhosts

  if [[ "${ACTION}" == "${ACTION_PREINSTALLCHECK}" ]]; then
    echo "Running pre-install checks"
    if [[ "$upgrade" != "yes" ]]; then
      checkDirAreEmpty
      if [ "$?" -ne "0" ]; then
        exit 1
      fi
      exit 0
    fi
  fi

  if [[ "${ACTION}" == "${ACTION_DEPLOYPKG}" ]]; then
    echo "Running pkg deploy"
    setup
    deployJdk
    if [[ "${HADOOP_ENABLE}" == "1" ]]; then
      deploySnappy
      deployHadoopRpms
      hadoopDirSetup
    fi
    if [[ "${ZOOKEEPER_ENABLE}" == "1" ]]; then
      deployZkRpms
    fi
    if [[ "${HBASE_ENABLE}" == "1" ]]; then
      deployHbaseRpms
      hbaseDirSetup
    fi
    if [[ "${HCAT_ENABLE}" == "1" ]]; then
      deployHcatRpms
      hcatDirSetup
    fi
    if [[ "${PIG_ENABLE}" == "1" ]]; then
      deployPigRpms
    fi
    if [[ "${OOZIE_ENABLE}" == "1" ]]; then
      deployOozieRpms
      oozieDirSetup
    fi
    if [[ "${SQOOP_ENABLE}" == "1" ]]; then
      deploySqoopRpms
    fi
    if [[ "${TEMPLETON_ENABLE}" == "1" ]]; then
      deployTempletonRpms
      templetonDirSetup
    fi
    if [[ "${MON_ENABLE}" == "1" ]]; then
      deployNetSnmpRpms
      deployNagiosRpms
      deployGangliaRpms
      deployDashboardRpms
    fi
  fi

  if [[ "${ACTION}" == "${ACTION_DEPLOYCONFIG}" ]]; then
    echo "Running config deploy"
    if [[ "${HADOOP_ENABLE}" == "1" ]]; then
      deployHadoopConfigs
    fi
    if [[ "${ZOOKEEPER_ENABLE}" == "1" ]]; then
      deployZkConfigs
    fi
    if [[ "${HBASE_ENABLE}" == "1" ]]; then
      deployHbaseConfigs
    fi
    if [[ "${HCAT_ENABLE}" == "1" ]]; then
      deployHcatConfigs
    fi
    if [[ "${PIG_ENABLE}" == "1" ]]; then
      deployPigConfigs
    fi
    if [[ "${OOZIE_ENABLE}" == "1" ]]; then
      deployOozieConfigs
    fi
    if [[ "${SQOOP_ENABLE}" == "1" ]]; then
      deploySqoopConfigs
    fi
    if [[ "${TEMPLETON_ENABLE}" == "1" ]]; then
      deployTempletonConfigs
    fi
    if [[ "${MON_ENABLE}" == "1" ]]; then
      install_monitor_config
      deployNetSnmpConfigs
      deployNagiosConfigs
      deployGangliaConfigs
      deployDashboardConfigs
    fi
  fi

  if [[ "${ACTION}" == "${ACTION_START}" ]]; then
    echo "Running service start"
    if [[ "${HDFS_ENABLE}" == "1" ]]; then
      if [[ ${RUNPOSTINSTALLSETUP} == "1" ]]; then
         formatHdfs
      fi
      startHdfs
      if [[ ${RUNPOSTINSTALLSETUP} == "1" ]]; then
         setupHdfsDirs
      fi
    fi
    if [[ "${MAPREDUCE_ENABLE}" == "1" ]]; then
      startMapReduce
    fi
    if [[ "${ZOOKEEPER_ENABLE}" == "1" ]]; then
      startZk
    fi
    if [[ "${HBASE_ENABLE}" == "1" ]]; then
      startHbase
    fi
    if [[ "${HCAT_ENABLE}" == "1" ]]; then
      startHcat
    fi
    if [[ "${OOZIE_ENABLE}" == "1" ]]; then
      startOozie
    fi
    if [[ "${TEMPLETON_ENABLE}" == "1" ]]; then
      startTempleton
    fi
    if [[ "${MON_ENABLE}" == "1" ]]; then
      startnetsnmp
      startnagios
      startganglia
      startdashboard
    fi
  fi

  if [[ "${ACTION}" == "${ACTION_STOP}" ]]; then
    echo "Running service stop"
    if [[ "${TEMPLETON_ENABLE}" == "1" ]]; then
      stopTempleton
    fi
    if [[ "${OOZIE_ENABLE}" == "1" ]]; then
      stopOozie
    fi
    if [[ "${HCAT_ENABLE}" == "1" ]]; then
      stopHcat
    fi
    if [[ "${HBASE_ENABLE}" == "1" ]]; then
      stopHbase
    fi
    if [[ "${ZOOKEEPER_ENABLE}" == "1" ]]; then
      stopZk
    fi
    if [[ "${MAPREDUCE_ENABLE}" == "1" ]]; then
      stopMapReduce
    fi
    if [[ "${HDFS_ENABLE}" == "1" ]]; then
      stopHdfs
    fi
    if [[ "${MON_ENABLE}" == "1" ]]; then
      stopnetsnmp
      stopnagios
      stopganglia
      stopdashboard
    fi
  fi

  if [[ "${ACTION}" == "${ACTION_SMOKETEST}" ]]; then
    echo "Running smoke tests"
    if [[ "${HADOOP_ENABLE}" == "1" ]]; then
      runHadoopSmokeTest
    fi
    if [[ "${ZOOKEEPER_ENABLE}" == "1" ]]; then
      runZkSmokeTest
    fi
    if [[ "${HBASE_ENABLE}" == "1" ]]; then
      runHbaseSmokeTest
    fi
    if [[ "${HCAT_ENABLE}" == "1" ]]; then
      runHcatSmokeTest
      runHiveSmokeTest
    fi
    if [[ "${PIG_ENABLE}" == "1" ]]; then
      runPigSmokeTest
    fi
    if [[ "${OOZIE_ENABLE}" == "1" ]]; then
      runOozieSmokeTest
    fi
    if [[ "${SQOOP_ENABLE}" == "1" ]]; then
      runSqoopSmokeTest
    fi
    if [[ "${TEMPLETON_ENABLE}" == "1" ]]; then
      runTempletonSmokeTest
    fi
    if [[ "${MON_ENABLE}" == "1" ]]; then
      netsnmpsmoketest
      nagiossmoketest
      gangliasmoketest
      dashboardsmoketest
    fi
    displaySmokeTestSummary
    smoke_results=$?
  fi

  clusterdetails
  exit ${smoke_results}