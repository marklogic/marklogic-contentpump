#!/bin/bash
#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

basedir=`pwd`
source ${basedir}/gsInstaller.properties
source ${basedir}/gsLib.sh

displayDataDirs() {
  echo "Namenode Dir: ${namenode_dir}"
  echo "Secondary Namenode Dir: ${snamenode_dir}"
  echo "Datanode Dir: ${datanode_dir}"
  echo "Mapred Dir: ${mapred_dir}"
  if [ 'yes' == "$installzk" ]; then
    echo "Zookeeper Dir: ${zk_data_dir}"
  fi
  if [ 'yes' == "$installoozie" ]; then
    echo "Oozie DB Dir: ${oozie_db_dir}"
  fi
}

deleteDataDir() {
  hosts=$1
  dirs=$2
  dirs=$(echo $dirs | tr "," " ")
  #check each dir
  for dir in $dirs
  do
    echo "Deleting $dir on $hosts"
    ssh2host "$hosts" "rm -rf $dir"
  done
}

setInstallDependencies

displayDataDirs
echo -n "Do you really want to delete all the data (y/N) ?"
read CONFIRM
if [ "${CONFIRM}" != "y" ]; then
  echo "User aborted setup, exiting..."
  exit 1
fi

# Delete data from all the required dirs

# Purge hdfs, mr dirs
echo "Delete namenode dirs"
deleteDataDir "$nnhost" "$namenode_dir"
deleteDataDir "$snhost" "$snamenode_dir"
echo "Delete datanode and mapred local dirs"
slaves_list=`commaSeparatedHostList ${slaves}`
deleteDataDir "${slaves_list}" "$datanode_dir $mapred_dir"

#Purge  zk data dir
if [ 'yes' == "$installzk" ]; then
  echo "Delete zk data dir"
  zk_list=`commaSeparatedHostList $zkhosts`
  deleteDataDir "${zk_list}" "$zk_data_dir"
fi

#purge oozie dir
if [ 'yes' == "$installoozie" ]; then
  echo "Delete Oozie db dir"
  deleteDataDir "$oozieshost" "$oozie_db_dir"
fi

