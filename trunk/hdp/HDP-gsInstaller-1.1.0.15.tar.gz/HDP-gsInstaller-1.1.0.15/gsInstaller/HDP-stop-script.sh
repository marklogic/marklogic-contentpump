#----- Stop script -------------
echo "For slave node"

echo "Stop Hbase regionserver"
su hbase - -c "/usr/bin/hbase-daemon.sh --config /etc/hbase/ stop regionserver"

echo "Stop HDFS datanode"
su hdfs - -c "hadoop-daemon.sh --config /etc/hadoop/ stop datanode"

echo "Stop Hadoop tasktracker"
su mapred - -c "hadoop-daemon.sh --config /etc/hadoop/ stop tasktracker"

echo "Stop zookeeper node"
su zookeeper - -c "/usr/sbin/zkServer.sh stop"

echo "Stop the secondary name node"
su hdfs - -c "/usr/sbin/hadoop-daemon.sh --config /etc/hadoop stop secondarynamenode"

echo "Stop the name node"
su hdfs - -c "/usr/sbin/hadoop-daemon.sh --config /etc/hadoop stop namenode"

echo "Stop the job tracker and history server"
su mapred - -c "/usr/sbin/hadoop-daemon.sh --config /etc/hadoop stop historyserver"
su mapred - -c "/usr/sbin/hadoop-daemon.sh --config /etc/hadoop stop jobtracker"

echo "Stop the hbase master"
su hbase - -c "/usr/bin/hbase-daemon.sh --config /etc/hbase stop master"

echo "Stop the hcat server"
/etc/init.d/hcatalog-server stop

echo "Service associated with port"
netstat -nltp

echo "     			"
echo "                          "
echo "Java Process"
ps auxwwwf | grep java | grep -v grep | awk '{print $1, $11,$12}'

echo "======================================="
echo "Service associated with port"
netstat -nltp

echo "                          "
echo "                          "
echo "Java Process"
ps auxwwwf | grep java | grep -v grep | awk '{print $1, $11,$12}'
