#!/bin/sh

#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/
  basedir=`pwd`
  source ${basedir}/gsLib.sh
  echo "" > ${outlog} 

  echo
  echo0 "GRID UNINSTALLER"
  echo

  message="YOU ARE ABOUT TO UNINSTALL HDP"
  if [[ "tar" == "$package"
        || "TAR" == "$package"
        || "Tar" == "$package" ]]; then
    message="YOU ARE ABOUT TO REMOVE THE HDP TAR INSTALL FROM DIR: ${installdir}"
  fi

  echo "$message"
  echo -n "Do you want to proceed? (y/N) "
  read CONFIRM
  if [ "${CONFIRM}" != "y" ]; then
    echo "User aborted setup, exiting..."
    exit 1
  fi

  case "$package" in
    rpm|RPM)
      sh ${basedir}/rpmUninstaller.sh pack
      sh ${basedir}/rpmUninstaller.sh conf
      ;;
    deb|DEB|Deb)
      installpkg=deb
      # source ${basedir}/debUninstaller.sh
      echo "Error: DEBs not supported"
      exit 1
      ;;
    tar|TAR|Tar)
      sh ${basedir}/tarUninstaller.sh
      ;;
    *)
      echo "Please provide the package type you want to uninstall rpm | deb | tar"
      exit 1
      ;;
  esac
