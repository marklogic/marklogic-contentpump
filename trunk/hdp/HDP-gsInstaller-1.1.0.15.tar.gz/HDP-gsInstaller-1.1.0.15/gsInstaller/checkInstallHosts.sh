#! /bin/bash

#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

#! /bin/bash
BASE_DIR=`dirname $0`
basedir=`dirname $0`
#source diff files
. ${BASE_DIR}/gsInstaller.properties
. ${BASE_DIR}/gsLib.sh

#HOSTDETAILS
ALL_HOSTS="$gwhost $nnhost $snhost $jthost $slaves"
USERS="$hdfsuser $mapreduser"
SSH_CMD=""
if [ "x${sshkey}x" == "xx" ]; then
  SSH_CMD="$sshcmd"
else
  SSH_CMD="$sshcmd -i $sshkey"
fi

#if installing hbase add hbase and zk users and hosts to the list
if [ 'yes' == "$installhbase" ]; then
  USERS="$USERS $hbaseuser $zkuser"
  ALL_HOSTS="$ALL_HOSTS $hbmhost $rshosts $zkhosts"
fi

#if installing hcat add that to users and hosts
if [ 'yes' == "$installhcat" ]; then
  USERS="$USERS $hcatuser"
  ALL_HOSTS="$ALL_HOSTS $hcshost"
fi

#if installing templeton, add that to users and hosts
if [ 'yes' == "$installtempleton" ]; then
  USERS="$USERS $templetonuser"
  ALL_HOSTS="$ALL_HOSTS $ttonhosts"
fi

ALL_HOSTS="`echo $ALL_HOSTS | tr ' ' '\n' | sort | uniq | tr '\n' ' '`"

#check if you can ssh to all hosts
function checkSSHToHosts
{
  local ssh_failed_nodes=''
  local i=0
  for host in $ALL_HOSTS
  do
    echo "Checking ssh to $host"
    local cmd="$SSH_CMD $deployuser@$host 'hostname -f' | grep -q $host"
    #echo $cmd
    eval $cmd
    #if ssh did not succeed add it to the failed nodes list
    if [ "$?" -ne "0" ]; then
      ssh_failed_nodes="${ssh_failed_nodes}${host}\n"
      ((i=$i +1))
    fi
  done
  if [ "$i" -ne "0" ]; then
    echo -e "SSH to the following hosts failed ->\n$ssh_failed_nodes"
    return 1
  else
    echo "SSH to all hosts passed."
    return 0
  fi
}

#function to check users on approprite hosts
function checkSudoToUserOnHosts
{
  local hosts=$1
  hosts="`echo $hosts | tr ' ' '\n' | sort | uniq | tr '\n' ' '`"
  local users=$2
  
  local ssh_failed_nodes=''
  local i=0
  #log onto to each host
  for host in $hosts
  do
    local j=0
    local failed_users=''
    echo "Checking different users on $host"
    #check each user
    for user in $users
    do
      echo "$user"
      local cmd="$SSH_CMD -q -t $host \"sudo -i -u $user 'whoami'\" | grep -q '^$user'"
      #echo $cmd
      eval $cmd
      if [ "$?" -ne "0" ]; then
        failed_users="${failed_users}${user}\n"
        ((j=$j+1))
      fi
    done
    if [ "$j" -ne "0" ]; then
      ssh_failed_nodes="${ssh_failed_nodes}Host: $host Failed Users->\n${failed_users}\n"
      ((i=$i+1))
    fi
  done
  if [ "$i" -ne "0" ]; then
    echo -e "$ssh_failed_nodes"
    return 1
  else
    echo "Able to switch to all different users on hosts"
    return 0
  fi
}

#log onto each host and check if you can become all the different users
function checkSudoToUser
{
  local rc=0
  local status

  #check the install user on all host
  checkSudoToUserOnHosts "$ALL_HOSTS" "$deployuser"
  status="$?"
  ((rc=$rc+$status))

  #what hosts to check the smoke test users one
  local smoke_test_hosts="$gwhost"

  #check the hdfs and mapred users on hadoop hosts
  checkSudoToUserOnHosts "$gwhost $nnhost $snhost $jthost $slaves" "$hdfsuser $mapreduser"
  status="$?"
  ((rc=$rc+$status))

  #check for the hbase and zookeeper user
  if [ 'yes' == "$installhbase" ]; then
    #check the hbase user
    checkSudoToUserOnHosts "$hbmhost $rshosts" "$hbaseuser"
    status="$?"
    ((rc=$rc+$status))
    #check the zookeeper user
    checkSudoToUserOnHosts "$zkhosts" "$zkuser"
    status="$?"
    ((rc=$rc+$status))
    #since we are install hbase add zk hosts
    smoke_test_hosts="$gwhost $zkhosts"
  fi
  
  #if install hcat check for the hcat user (add namenode host to it also)
  if [ 'yes' == "$installhcat" ]; then
    checkSudoToUserOnHosts "$hcshost $nnhost" "$hcatuser"
    status="$?"
    ((rc=$rc+$status))
  fi

  #if install hcat check for the hcat user (add namenode host to it also)
  if [ 'yes' == "$installtempleton" ]; then
    checkSudoToUserOnHosts "$ttonhosts" "$templetonuser"
    status="$?"
    ((rc=$rc+$status))
  fi

  
  #check the smoke test user
  checkSudoToUserOnHosts "$smoke_test_hosts" "$smoke_test_user"
  status="$?"
  ((rc=$rc+$status))

  return $rc
}


#function to check if dir's are empty on host
function checkIfDirAreEmpty
{
  local hosts=$1
  hosts="`echo $hosts | tr ' ' '\n' | sort | uniq | tr '\n' ' '`"
  local dirs=$2
  dirs="`echo $dirs | tr ',' ' '`"
  
  local i=0
  for host in $hosts
  do
    echo "Checking existence of non emtpy dirs on $host"
    local j=0
    local existing_dirs=''
    #check each dir
    for dir in $dirs
    do
      echo "dir -> $dir"
      local cmd="$SSH_CMD $host \"ls $dir | wc -l\" | grep -q '0'"
      #echo $cmd
      eval $cmd
      #if and file is found is found
      if [ "$?" -ne "0" ]; then
        existing_dirs="${existing_dirs}${dir}\n"
        ((j=$j+1))
      fi
    done
    if [ "$j" -ne "0" ]; then
      non_empty_nodes="${non_empty_nodes}Host: $host Non empty dirs->\n${existing_dirs}\n"
      ((i=$i+1))
    fi
  done
  if [ "$i" -ne "0" ]; then
    echo -e "$non_empty_nodes"
    return 1
  else
    echo "All expected directories are empty"
    return 0
  fi
}

#function to check for the hdfs and zookeeper related dirs on local fs are empty or not. If not it will return non zero exit code
function checkLocalFSDirIsEmpty
{
  local rc=0
  local status

  #check to make sure the namenode dir is empty on the namenode
  checkIfDirAreEmpty "$nnhost" "$namenode_dir"
  status="$?"
  ((rc=$rc+$status))

  #check to make sure the secondary namenode dir is empty on the secondary namenode
  checkIfDirAreEmpty "$snhost" "$snamenode_dir"
  status="$?"
  ((rc=$rc+$status))
  
  #check for the data dirs on the datanodes
  checkIfDirAreEmpty "$slaves" "$datanode_dir"
  status="$?"
  ((rc=$rc+$status))

  #if installing hbase add zk data dir
  if [ 'yes' == "$installhbase" ]; then
    checkIfDirAreEmpty "$zkhosts" "$zk_data_dir"
    status="$?"
    ((rc=$rc+$status))
  fi
  return $rc
}

#function to check if a proccess is running on host
function checkProcessOnHosts
{
  local hosts=$1
  hosts="`echo $hosts | tr ' ' '\n' | sort | uniq | tr '\n' ' '`"
  local process_strings=$2
  local type=$3
  type=( $type )
  local rc=0
  for host in $hosts
  do
    local i=0;
    local results=''
    for proc_string in $process_strings
    do
      local output=""
      local cmd="$SSH_CMD $host \"ps aux | grep '$proc_string'\" | grep -v grep | awk '{print \$1,\$2}'"
      output=`eval $cmd`
      #if out is not empty then print it
      if [ "x${output}x" != "xx" ]; then
        results="${results}${type[$i]}\n$output\n-------\n"
        rc=1
      fi
      ((i=$i+1))
      done
    if [ "x${results}x" != "xx" ]; then
      echo -e "On $host found ->\n$results"
    fi
  done

  return $rc
}

function checkProccess
{
  local rc=0
  #test hdfs proccess
  checkProcessOnHosts "$ALL_HOSTS" "\-Dproc_namenode \-Dproc_secondarynamenode \-Dproc_datanode \-Dproc_jobtracker \-Dproc_historyserver \-Dproc_tasktracker org.apache.hadoop.hbase.master.HMaster org.apache.hadoop.hbase.regionserver.HRegionServer org.apache.zookeeper.server.quorum.QuorumPeerMain \-Dproc_jar" "Namenode SecondaryNamenode Datanode Jobtracker HistoryServer Tasktracker HbaseMaster HbaseRegionServer Zookeeper Hcatalog"
  rc="$?"

  return $rc
}


function checkOwnershipOnHost {
  local hosts=$1
  hosts="`echo $hosts | tr ' ' '\n' | sort | uniq | tr '\n' ' '`"
  local dir_name=$2
  local user_string=$3
  local group_string=$4
  local rc=0
  for host in $hosts
  do
    echo "Checking for user and group ownership of $dir_name on $host" 
    local i=0;
    local results=''
      local output=""
      local cmd="$SSH_CMD $host \"ls -ld $dir_name | cut -f 3 -d ' '\""
      output=`eval $cmd`
      #if out is not empty then print it
      if [ "x${output}x" != "x${user_string}x" ]; then
        error_str="Owner of $dir_name is $output but was expecting $user_string"
        results="${results}\n$error_str\n"
        rc=1
      fi
      local output=""
      local cmd="$SSH_CMD $host \"ls -ld $dir_name | cut -f 4 -d ' '\""
      output=`eval $cmd`
      #if out is not empty then print it
      if [ "x${output}x" != "x${group_string}x" ]; then
        error_str="Owner of $dir_name is $output but was expecting $group_string"
        results="${results}\n$error_str\n"
        rc=1
      fi
      ((i=$i+1))
    if [ "x${results}x" != "xx" ]; then
      echo -e "On $host found ->\n$results"
    fi
  done

  return $rc

}

function checkOwnerships {
  local rc=0
  if  [[ $package == "tar" ]] ; then
    checkOwnershipOnHost "$ALL_HOSTS" $installdir $deployuser  hadoop
    checkOwnershipOnHost "$nnhost $snhost $jthost $slaves" $log_dir $deployuser hadoop
    checkOwnershipOnHost "$nnhost $snhost $jthost $slaves" $pid_dir $deployuser hadoop
    checkOwnershipOnHost "$nnhost" $namenode_dir $hdfsuser hadoop
    checkOwnershipOnHost "$snhost" $snamenode_dir $hdfsuser hadoop
    for dir in `echo $datanode_dir |  tr "," " "` ; do
      checkOwnershipOnHost "$slaves" $dir $hdfsuser hadoop 
    done
    for dir in `echo $mapred_dir |  tr "," " "` ; do
      checkOwnershipOnHost "$slaves" $dir $mapreduser hadoop 
    done
    checkOwnershipOnHost "$hbmhost $rshosts" $hbase_log_dir $hbaseuser hadoop
    checkOwnershipOnHost "$hbmhost $rshosts" $hbase_pid_dir $hbaseuser hadoop
    checkOwnershipOnHost "$zkhosts" $zk_log_dir $zkuser hadoop
    checkOwnershipOnHost "$zkhosts" $zk_pid_dir $zkuser hadoop
    checkOwnershipOnHost "$zkhosts" $zk_data_dir $zkuser hadoop
    checkOwnershipOnHost "$hcshost" $hcat_log_dir $hcatuser hadoop
    checkOwnershipOnHost "$hcshost" $hcat_pid_dir $hcatuser hadoop
    rc="$?"
  fi
  return $rc
}


function checkPermissionOnHost {
  local hosts=$1
  hosts="`echo $hosts | tr ' ' '\n' | sort | uniq | tr '\n' ' '`"
  local dir_name=$2
  local perm_string=$3
  local rc=0
  for host in $hosts
  do
    echo "Checking for $dir_name permission on $host"
    local i=0;
    local results=''
      local output=""
      local cmd="$SSH_CMD $host \"ls -ld $dir_name | cut -f 1 -d ' '\""
      output=`eval $cmd`
      #if out is not empty then print it
      if [ "x${output}x" != "x${perm_string}x" ]; then
        error_str="Owner of $dir_name is $output but was expecting $perm_string"
        results="${results}\n$error_str\n"
        rc=1
      fi
      ((i=$i+1))
    if [ "x${results}x" != "xx" ]; then
      echo -e "On $host found ->\n$results"
    fi
  done

  return $rc
}

function checkPermissions {
  local rc=0
  if  [[ $package == "tar" ]] ; then
    checkPermissionOnHost "$ALL_HOSTS" $installdir drwxr-xr-x
    checkPermissionOnHost "$nnhost $snhost $jthost $slaves" $log_dir drwxrwxr-x
    checkPermissionOnHost "$nnhost $snhost $jthost $slaves" $pid_dir drwxrwxr-x
    checkPermissionOnHost "$nnhost" $namenode_dir drwxrwxr-x
    checkPermissionOnHost "$snhost" $snamenode_dir drwxrwxr-x
    for dir in `echo $datanode_dir |  tr "," " "` ; do
      if [[ "true" == "$enableshortcircuit" ]] ; then
         checkPermissionOnHost "$slaves" $dir drwxr-x---
      else
        checkPermissionOnHost "$slaves" $dir drwxr----- 
      fi
    done
    for dir in `echo $mapred_dir |  tr "," " "` ; do
      checkPermissionOnHost "$slaves" $dir drwxrwxr-x
    done
    checkPermissionOnHost "$hbmhost $rshosts" $hbase_log_dir drwxr-xr-x
    checkPermissionOnHost "$hbmhost $rshosts" $hbase_pid_dir drwxr-xr-x
    checkPermissionOnHost "$zkhosts" $zk_log_dir drwxr-xr-x
    checkPermissionOnHost "$zkhosts" $zk_pid_dir drwxr-xr-x
    checkPermissionOnHost "$zkhosts" $zk_data_dir drwxr-xr-x
    checkPermissionOnHost "$hcshost" $hcat_log_dir drwxrwxr-x
    checkPermissionOnHost "$hcshost" $hcat_pid_dir drwxrwxr-x
    rc="$?"
  fi
  return $rc
}

#read the option from the command line
OPTION="$1"
rc=0;
case "$OPTION" in
  #check onls pwdless ssh
  ssh)
    checkSSHToHosts
    rc="$?"
  ;;
  #check if the user can sudo to different users
  users)
    checkSudoToUser
    rc="$?"
  ;;
  #check if the directories are empty or not
  empty_dirs)
    checkLocalFSDirIsEmpty
    rc="$?"
  ;;
  #check the proccess
  process)
    checkProccess
    rc="$?"
  ;;
  owners)
    checkOwnerships
    rc=$?
  ;;
  permissions)
    checkPermissions
    rc=$?
  ;; 
  #check everything
  *)
    checkSSHToHosts
    status="$?"
    ((rc=$rc+$status))
    checkSudoToUser
    status="$?"
    ((rc=$rc+$status))
    checkLocalFSDirIsEmpty
    status="$?"
    ((rc=$rc+$status))
    checkProccess
    status="$?"
    ((rc=$rc+$status))
    checkOwnerships
    status="$?"
    ((rc=$rc+$status))
    checkPermissions
    status="$?"
    ((rc=$rc+$status))
  ;;
esac

#exit with appropriate return code
exit $rc
