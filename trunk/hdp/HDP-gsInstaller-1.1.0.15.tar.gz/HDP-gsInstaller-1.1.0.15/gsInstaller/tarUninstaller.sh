#!/bin/sh

#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

 basedir=`pwd`
 source ${basedir}/gsInstaller.properties
 source ${basedir}/gsLib.sh
 
 setInstallDependencies

 [ -n "$sshkey" ] && usesshkey="-i $sshkey"
 clear

 cleanup() {
   stopHadoopServices
   stopHbaseServices
   stopZkServices
   stopHcatService
   stopOozieService
   stopTtonService
  }

 killJavaProc() {
  local host=$1
  local user=$2

  ssh -q -t ${usesshkey} $host "$SUDOUSERPREFIX ${user} $SUDOCMDOPTION \"ps -ef | grep [j]ava | awk '{ print \\\$2 }' | xargs kill -9 >> /dev/null 2>&1\""
 }

 stopHadoopServices() {
   echo0 "kill all java service started by $hdfsuser $mapreduser"
   for i in $(cat nodes gateway jobtracker namenode snamenode | sort | uniq )
     do
       echo ==============================on $i
       killJavaProc $i $hdfsuser
       killJavaProc $i $mapreduser
       ssh -q -t ${usesshkey} $i "rm -rf ${installdir}/*"
   done
  }

 stopHbaseServices() {
   echo0 "kill all java service started by $hbaseuser "
   for i in $(cat hbasemaster hbasenodes | sort | uniq )
     do
       echo ==============================on $i
       killJavaProc $i $hbaseuser
       ssh -q -t ${usesshkey} $i "rm -rf ${installdir}/*"
   done
  }

  stopZkServices() {
    echo0 "kill all java service started by $zkuser "
    for i in $(cat zknodes | sort | uniq )
      do
        echo ==============================on $i
        killJavaProc $i $zkuser
        ssh -q -t ${usesshkey} $i "rm -rf ${installdir}/*"
    done
   }

  stopHcatService() {
    echo0 "kill all java service started by $hcatuser "
    for i in $(cat hcatserver | sort | uniq )
      do
        echo ==============================on $i
        killJavaProc $i $hcatuser
        ssh -q -t ${usesshkey} $i "rm -rf ${installdir}/*"
   done
  }

  stopOozieService() {
    echo0 "kill all java service started by $oozieuser "
    for i in $(cat oozieserver | sort | uniq )
      do
        echo ==============================on $i
        killJavaProc $i $oozieuser
        ssh -q -t ${usesshkey} $i "rm -rf ${installdir}/*"
   done
  }

  stopTtonService() {
    echo0 "kill all java service started by $templetonuser "
    for i in $(cat templetonnode | sort | uniq )
      do
        echo ==============================on $i
        killJavaProc $i $templetonuser
        ssh -q -t ${usesshkey} $i "rm -rf ${installdir}/*"
    done
  }

  cleanup
