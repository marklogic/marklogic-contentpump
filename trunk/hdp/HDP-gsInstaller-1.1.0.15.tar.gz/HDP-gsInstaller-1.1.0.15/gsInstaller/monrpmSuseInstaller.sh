#! /bin/bash
#
# ureonrpmInstaller.sh - RPM specific code for monInstallera on SUSE

#/**
##* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

############################################################
# EXECUTION BEGINS HERE
############################################################
basedir=`dirname "$0"`
config_dir=`pwd`

export HTPASSWD_CMD="htpasswd2"
export HTTPD_CMD="/etc/init.d/apache2"

# Base rpm installer for monitoring
source ${basedir}/monrpmInstaller.sh

preInstall() {
  return
}

postInstall() {
  return
}

deployNetSnmpRpms() {
  if [[ "$monitor_config_only" != "yes" ]]; then
    echo0 "Installing Net SNMP RPMs"
    monsshall "$installpkgcmd net-snmp"
  fi
}

deployNagiosRpms() {
  if [[ "$monitor_config_only" != "yes" ]]; then
    echo0 "Install Nagios RPMs"
    local pkgs="wget apache2 php php-curl perl-SNMP perl-Net-SNMP fping nagios-3.2.3-2.1 nagios-plugins-1.4.9 hdp_mon_nagios_addons"
    sshnagios "$installpkgcmd $pkgs"
  fi
}

ensureJson() {
  # Nothing to do for SUSE, json is provided by php
  return
}

