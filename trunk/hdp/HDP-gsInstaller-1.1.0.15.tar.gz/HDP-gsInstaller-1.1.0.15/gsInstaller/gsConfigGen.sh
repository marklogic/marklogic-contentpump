#!/bin/bash

#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

function print_usage() {
  echo "Usage: $0 output_dir addon.properties"
  echo "  output_dir: output dir to write configs to"
  echo "  addon.properties: gsCluster.properties addon file"
}

############################################################
# EXECUTION BEGINS HERE
############################################################
basedir=`pwd`

outputConfDir=""
if [[ "$#" == "1" ]]; then
  if [[ "$1" == "help" ]]; then
    print_usage
    exit 0
  else
    outputConfDir=$1
  fi
fi
if [[ "$#" == "2" ]]; then
  outputConfDir=$1
  gsinstallpropsaddons=$2
fi

source ${basedir}/gsInstaller.properties
source ${basedir}/gsCluster.properties
source ${basedir}/gsLibCommon.sh
source ${basedir}/gsConfigLib.sh

if [[ "${gsinstallpropsaddons}" != "" ]]; then
  addonfiles=$(echo ${gsinstallpropsaddons} | tr ' ' ',')
  for addonfile in ${addonfiles}
  do
    source ${addonfile}
  done
fi

echo0 "Grid Stack Config Generator"
echo0 "Installation Details"
echo  "$line"

export outlog="/tmp/gsConfigGen-$$.log"

############################################################
#HOSTDETAILS
############################################################
gwhost=$(cat gateway)
nnhost=$(cat namenode)
snhost=$(cat snamenode)
jthost=$(cat jobtracker)
hbmhost=$(cat hbasemaster)
hcshost=$(cat hcatserver)
slaves=$(cat nodes)
rshosts=$(cat hbasenodes)
zkhosts=$(cat zknodes)
gangliahost=$(cat gangliaserver)
nagioshost=$(cat nagiosserver)
gangliaweb=$(cat gangliaweb)
dashboardhost=$(cat dashboardhost)

datanodes_count=0
tasktrackers_count=0
hbaseregionservers_count=0
if [[ "$slaves" != "" ]]; then
  tmp_nodes_array=( $slaves )
  datanodes_count=${#tmp_nodes_array[*]}
  tasktrackers_count=${#tmp_nodes_array[*]}
fi
if [[ "$rshosts" != "" ]]; then
  tmp_nodes_array=( $rshosts )
  hbaseregionservers_count=${#tmp_nodes_array[*]}
fi

if [[ `validatefalse $security` == "yes" ]]; then
  enablesecurity=yes
else
  enablesecurity=no
fi

[ `validate $installpig` == "yes" ] && installpig=yes
[ `validate $installhbase` == "yes" ] && installhbase=yes
[ `validate $installhcat` == "yes" ] && installhcat=yes
[ `validate $installtempleton` == "yes" ] && installtempleton=yes
[ `validatefalse $upgrade` == "yes" ] && upgrade=yes


[ "$hdfsuser" == "" ] && hdfsuser="hdfs"
[ "$mapreduser" == "" ] && mapreduser="mapred"
[[ "$installhase" == "yes" && "$hbaseuser" == "" ]] && hbaseuser="hbase"
[[ "$installhcat" == "yes" && "$hcatuser" == "" ]] && hcatuser="hcat"
[ "$nnhost" == "" ] && echo "Enter a valid Namenodehost" && exit
[ "$gwhost" == "" ] && echo "Enter a valid Gatewayhost" && exit
[ "$snhost" == "" ] && echo "Enter a valid Secondary Namenode host" && exit
[ "$jthost" == "" ] && echo "Enter a valid Jobtracker" && exit
[ "$slaves" == "" ] && echo "Enter a valid Slaves hostname list" && exit
[[ "$hcshost" == "" && "$installhcat" == "yes" ]] \
  && echo "Enter a valid hostname for hcatserver" && exit
[[ "$hbmhost" == "" || "$rshosts" == "" || "$zkhosts" == "" ]] \
  && [[ "$installhbase" == "yes" ]]  && \
  echo "Enter a valid hostname for hbasemaster, regionserver, zookeeper" && exit
if [[ "$nnsafemodetimeout" == "" ]]; then
  nnsafemodetimeout=600
fi


case "$package" in
  rpm|RPM|deb|DEB|Deb)
    deploypath="/usr"

    #hadoophome
    hadoophome="${deploypath}"

    #java home settings
    hadoopjavahome="${deploypath}/hadoop-jdk1.6.0_26"
    hbasejavahome="${deploypath}/hbase-jdk1.6.0_26"
    hcatjavahome="${deploypath}/hcat-jdk1.6.0_26"
    zkjavahome="${deploypath}/zk-jdk1.6.0_26"

    #Deploy conf dir locations
    hadoopconfdir="/etc/hadoop/"
    hcatconfdir="/etc/hcatalog/"
    ttonconfdir="/etc/templeton/"
    zkconfdir="/etc/zookeeper/"
    hbaseconfdir="/etc/hbase/"
    ;;
  tar|TAR|Tar)
    deploypath="${installdir}"

    #hadoophome
    hadoophome="${deploypath}/hadoop/"

    #java home settings
    hadoopjavahome="${deploypath}/hadoop-jdk1.6.0_26"
    hbasejavahome="${deploypath}/hbase-jdk1.6.0_26"
    hcatjavahome="${deploypath}/hcat-jdk1.6.0_26"
    zkjavahome="${deploypath}/zk-jdk1.6.0_26"

    #Deploy conf dir locations
    hadoopconfdir="${deploypath}/hadoop-conf/"
    hcatconfdir="${deploypath}/hcat-conf/"
    ttonconfdir="${deploypath}/templeton-conf"
    zkconfdir="${deploypath}/zk-conf/"
    hbaseconfdir="${deploypath}/hbase-conf/"
    ;;
  *)
    echo "Please provide the package type you want to install rpm | deb | tar"
    exit 1
    ;;
esac

tmpworkdir="/tmp/HDP-gsConfigGen-$$/"
mkdir -p ${tmpworkdir}

templates=${basedir}/confSupport/templates

if [[ "${outputConfDir}" != "" ]]; then
  confRoot="${outputConfDir}"
else
  confRoot="${tmpworkdir}/generated-confs/"
fi

echo "Using ${confRoot} to write generate configs to"
mkdir -p ${confRoot}
if [[ ! -d ${confRoot} ]]; then
  echo "Error: could not find/create dir ${confRoot}"
  exit 1
else
  cmd="ls ${confRoot} | wc -l"
  filecnt=`eval $cmd`
  if [[ ${filecnt} -ne 0 ]]; then
    echo "Error: ${confRoot} dir is not empty. Found ${filecnt} entries"
    exit 1
  fi
fi

### to support config generation for hadoop
clusterproperties="${tmpworkdir}/cluster.properties"

valueFiles="${clusterproperties}"

### to support config generation for hbase
hbaseproperties="${tmpworkdir}/hbase.properties"
hbasevalueFiles="${hbaseproperties}"

### to support config generation for hcat
hcatclusterproperties="${tmpworkdir}/hcatcluster.properties"

### to support config generation for pig
pigclusterproperties="${tmpworkdir}/pig.properties"

### to support config generation for templeton
templetonclusterproperties="${tmpworkdir}/templeton.properties"

### to support config generation for hdp monitoring
hdpmonproperties="${tmpworkdir}/hdpmon.properties"


echo0 "Output logs generated at ${outlog}"

echo0 "Generating configs for hadoop in ${confRoot}"
hadoopconfgen
ret=$?
if [[ "$ret" != "0" ]]; then
  echo "Failed to generate hadoop configs"
  exit 1
fi

if [[ "${installhbase}" == "yes" ]]; then
  echo0 "Generating configs for hbase in ${confRoot}"
  hbaseconfgen
  ret=$?
  if [[ "$ret" != "0" ]]; then
    echo "Failed to generate hbase configs"
    exit 1
  fi
  echo0 "Generating configs for zookeeper in ${confRoot}"
  zkconfgen
  ret=$?
  if [[ "$ret" != "0" ]]; then
    echo "Failed to generate zookeeper configs"
    exit 1
  fi
fi

if [[ "${installhcat}" == "yes" ]]; then
  echo0 "Generating configs for hcatalog in ${confRoot}"
  hcatconfgen
  ret=$?
  if [[ "$ret" != "0" ]]; then
    echo "Failed to generate hcat configs"
    exit 1
  fi
fi

if [[ "${installpig}" == "yes" ]]; then
  echo0 "Generating configs for pig in ${confRoot}"
  pigconfgen
  ret=$?
  if [[ "$ret" != "0" ]]; then
    echo "Failed to generate pig configs"
    exit 1
  fi
fi

if [[ "${installtempleton}" == "yes" ]]; then
  echo0 "Generating configs for templeton in ${confRoot}"
  templetonconfgen
  ret=$?
  if [[ "$ret" != "0" ]]; then
    echo "Failed to generate templeton configs"
    exit 1
  fi
fi

if [[ "$enablemon" == "yes" ]]; then
  echo0 "Generating configs for hdp-mon in ${confRoot}"
  hdpmonconfgen
  ret=$?
  if [[ "$ret" != "0" ]]; then
    echo "Failed to generated hdp monitoring configs"
    exit 1
  fi
fi

echo0 "Generated confs available at ${confRoot}"
