#!/bin/bash
#
# monInstaller.sh - Install the monitoring code for an HDP cluster.
# We install
# - snmp
# - nagios
# - ganglia
#

#/**
##* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/


############################################################
# EXECUTION BEGINS HERE
############################################################
basedir=`dirname "$0"`
config_dir=`pwd`
source ${config_dir}/gsInstaller.properties
source ${config_dir}/gsCluster.properties
source ${basedir}/gsLib.sh
source ${basedir}/gsConfigLib.sh
source ${config_dir}/monInstaller.properties
source ${basedir}/monLib.sh

source ${basedir}/rpmInstaller.sh
tput clear

echo0 "Monitoring Installer"
echo0 "Installation Details"
echo  "$line"

if [ "$enablemon" != "yes" ]; then
  echo
  echo "Error: Monitoring is not enabled while installing Hadoop using gsInstaller\n"
  echo "Uninstall and reInstall Hadoop using gsInstaller w/ enablemon property set to yes"
  echo
  exit 1;
fi

#default user should be root as the monInstaller can only be run by root user at the moment.
deployuser=root
#default package should be rpm as the monInstaller can only install rpm's at the moment.
package=rpm

# Fail monInstaller if its executed by non-root user.
[[ `id -u` -ne 0 ]] && echo0 "ERROR: Please execute $0 as root" && exit 1 

[ -f $outlog ] && rm -f $outlog
[ -d $artifactdownloaddir ] && rm -rf $artifactdownloaddir ; mkdir -p $artifactdownloaddir

#  [ "$nnhost" == "" ] && echo "Enter a valid Namenodehost" && exit

setos
case "$package" in
  rpm|RPM)
    installpkg=rpm

    if [ $SYSTEM_OS == $OS_SLES ]; then
      source ${basedir}/monrpmSuseInstaller.sh
    else
      #todo: check for rhel/centos
      source ${basedir}/monrpmRhelInstaller.sh
    fi;
    ;;
  deb|DEB|Deb)
    installpkg=deb
    source ${basedir}/mondebInstaller.sh
    ;;
  tar|TAR|Tar)
    installpkg=tar
    source ${basedir}/montarInstaller.sh
    [[ -z "$installdir" ]] && echo "Specify the installdir for the tarball installation" && exit
    ;;
   *)
     echo "Please provide the package type you want to install rpm | deb | tar"
    ;;
esac
moncollectserverlist
mondisplayselection

echo -n "Proceed with above options? (y/N) "
read CONFIRM
if [ "${CONFIRM}" != "y" ]; then
  echo "User aborted setup, exiting..."
  exit 1
fi
echo0 "check your install logs at : $outlog "

########################################
## MONITORING INSTALLATION STARTS HERE
########################################
preInstall
add2knownhosts
installwget
install_monitor_config
installnetsnmp
installnagios
installganglia
installdashboard
postInstall
startnetsnmp
startnagios
startganglia
startdashboard
netsnmpsmoketest
nagiossmoketest
gangliasmoketest
dashboardsmoketest
monclusterdetails
