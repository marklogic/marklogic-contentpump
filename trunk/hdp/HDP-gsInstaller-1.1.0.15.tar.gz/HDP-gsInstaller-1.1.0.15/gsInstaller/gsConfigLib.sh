#! /bin/bash

#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

  ############################################################
  #FUNCTION TO GENERATE HADOOP CONFIGS FROM TEMPLATES
  ############################################################
  hadoopconfgen(){
    echo "TODO-NAMENODE-HOSTNAME=$nnhost" > ${clusterproperties}
    echo "TODO-JTNODE-HOSTNAME=$jthost" >> ${clusterproperties}
    echo "TODO-SECONDARYNAMENODE-HOSTNAME=$snhost" >> ${clusterproperties}
    echo "TODO-MAPREDUSER=$mapreduser" >> ${clusterproperties}
    echo "TODO-HDFSUSER=$hdfsuser" >> ${clusterproperties}
    echo "TODO-MAPRED-LOCAL-DIR=$mapred_dir" >> ${clusterproperties}
    echo "TODO-DFS-NAME-DIR=$namenode_dir" >> ${clusterproperties}
    echo "TODO-FS-CHECKPOINT-DIR=$snamenode_dir" >> ${clusterproperties}
    echo "TODO-DFS-DATA-DIR=$datanode_dir" >> ${clusterproperties}
    echo "TODO-SUPPORT-APPEND=${enableappend:-true}" >> ${clusterproperties}
    echo "TODO-JAVA-HOME=$hadoopjavahome" >> ${clusterproperties}
    echo "TODO-DFS-HOSTS-EXCLUDE=$hadoopconfdir/dfs.exclude" >> ${clusterproperties}
    echo "TODO-DFS-HOSTS-INCLUDE=$hadoopconfdir/dfs.include" >> ${clusterproperties}
    echo "TODO-MAPRED-HOSTS-INCLUDE=$hadoopconfdir/mapred.include" >> ${clusterproperties}
    echo "TODO-MAPRED-HOSTS-EXCLUDE=$hadoopconfdir/mapred.exclude" >> ${clusterproperties}
    echo "TODO-CONF-DIR=$hadoopconfdir" >> ${clusterproperties}
    echo "TODO-KERBEROS-DOMAIN=$realm" >> ${clusterproperties}
    echo "TODO-KEYTAB-PATH=$keytabdir" >> ${clusterproperties}
    echo "TODO-HADOOP-HEAPSIZE=${hadoop_heap_size:-1024m}" >> ${clusterproperties}
    echo "TODO-NAMENODE-JAVAHEAP=${namenode_javaheap:-1G}" >> ${clusterproperties}
    echo "TODO-FS-INMEMORY-SIZE=${fs_inmemory_size:-256}" >> ${clusterproperties}
    echo "TODO-NAMENODE-OPT-NEWSIZE=${namenode_opt_newsize:-640m}" >> ${clusterproperties}
    echo "TODO-NAMENODE-OPT-MAXNEWSIZE=${namenode_opt_newsize:-640m}" >> ${clusterproperties}
    echo "TODO-NAMENODE-GC-SIZE=${namenode_gc_size:-1G}" >> ${clusterproperties}
    echo "TODO-DATANODE-DU-RESERVED=${datanode_du_reserved:-1073741824}" >> ${clusterproperties}
    echo "TODO-DTNODE-HEAPSIZE=${dt_heapsize:-1024m}" >> ${clusterproperties}
    echo "TODO-JTNODE-OPT-NEWSIZE=${jtnode_opt_newsize:-200m}" >> ${clusterproperties}
    echo "TODO-JTNODE-OPT-MAXNEWSIZE=${jtnode_opt_maxnewsize:-200m}" >> ${clusterproperties}
    echo "TODO-JTNODE-HEAPSIZE=${jt_heapsize:-1024m}" >> ${clusterproperties}
    echo "TODO-MAPRED-MAP-TASKS-MAX=${mapred_map_tasks_max:-4}" >> ${clusterproperties}
    echo "TODO-MAPRED-RED-TASKS-MAX=${mapred_red_tasks_max:-4}" >> ${clusterproperties}
    echo "TODO-MAPRED-CLUSTER-MAP-MEM-MB=${mapred_cluster_map_mem_mb:-1536}" >> ${clusterproperties}
    echo "TODO-MAPRED-CLUSTER-RED-MEM-MB=${mapred_cluster_red_mem_mb:-2048}" >> ${clusterproperties}
    echo "TODO-MAPRED-CLUSTER-MAX-MAP-MEM-MB=${mapred_cluster_max_map_mem_mb:-6144}" >>  ${clusterproperties}
    echo "TODO-MAPRED-CLUSTER-MAX-RED-MEM-MB=${mapred_cluster_max_red_mem_mb:-8192}" >>  ${clusterproperties}
    echo "TODO-MAPRED-JOB-MAP-MEM-MB=${mapred_job_map_mem_mb:-1536}" >> ${clusterproperties}
    echo "TODO-MAPRED-JOB-RED-MEM-MB=${mapred_job_red_mem_mb:-4096}" >> ${clusterproperties}
    echo "TODO-MAPRED-CHILD-JAVA-OPTS-SZ=${mapred_child_java_opts_sz:--Xmx768m}" >> ${clusterproperties}
    echo "TODO-IO-SORT-MB=${io_sort_mb:-200}" >> ${clusterproperties}
    echo "TODO-IO-SORT-SPILL-PERCENT=${io_sort_spill_percent:-0.9}" >> ${clusterproperties}
    echo "TODO-MAPREDUCE-USERLOG-RETAINHOURS=${mapreduce_userlog_retainhours:-24}" >> ${clusterproperties}
    echo "TODO-MAXTASKS-PER-JOB=${max_tasks_per_job:--1}" >> ${clusterproperties}
    echo "TODO-DFS-WEBHDFS-ENABLED=${enablewebhdfs:-false}" >> ${clusterproperties}
    echo "TODO-DFS-DATANODE-FAILED-VOLUME-TOLERATED=${dfs_datanode_failed_volume_tolerated:-0}" >> ${clusterproperties}
    echo "TODO-DFS-BLOCK-LOCAL-PATH-ACCESS-USER=${hbaseuser:-hbase}" >> ${clusterproperties}

    #TODO: this has to be done for other components like hbase
    if [[ -z $gcLogFileOption ]] ; then
      echo "TODO-JDK-GC-LOGFILE-OPTION=loggc" >> ${clusterproperties}
    else
      echo "TODO-JDK-GC-LOGFILE-OPTION=${gcLogFileOption}" >> ${clusterproperties}
    fi

    #determine hadoop_prefix based on the install type
    if [ "tar" == "$package" ]; then
      hadoop_prefix="${installdir}/hadoop"
    else
      hadoop_prefix="/usr"
    fi

    #determine where the task controller executable is
    taskcontrollerexe="${hadoophome}/bin/task-controller"

    if [[ $security = "yes" ]] ; then
      setsecurity="true"
      securitytype="kerberos"
      taskcontrollername="org.apache.hadoop.mapred.LinuxTaskController"
      dnaddress="1019"
      dnhttpaddress="1022"
    else
      setsecurity="false"
      securitytype="simple"
      taskcontrollername="org.apache.hadoop.mapred.DefaultTaskController"
      dnaddress="50010"
      dnhttpaddress="50075"
    fi
    if [[ $installhive = "yes" ]] ; then
      echo "TODO-HIVEUSER=${hiveuser:-hive}"  >> ${clusterproperties}
      echo "TODO-PROXYUSER-GROUP=users" >> ${clusterproperties}
      echo "TODO-PROXYUSER-HOST=$hivehost" >> ${clusterproperties}
    else
      echo "TODO-HIVEUSER=${hiveuser:-hive}"  >> ${clusterproperties}
      echo "TODO-PROXYUSER-GROUP=" >> ${clusterproperties}
      echo "TODO-PROXYUSER-HOST=" >> ${clusterproperties}
    fi
   
    if [[ $installoozie = "yes" ]] ; then
      echo "TODO-OOZIEUSER=${oozieuser:-oozie}"  >> ${clusterproperties}
      echo "TODO-OOZIEPROXYUSER-GROUP=users" >> ${clusterproperties}
      echo "TODO-OOZIEPROXYUSER-HOST=${oozieshost}" >> ${clusterproperties}
     else
      echo "TODO-OOZIEUSER=${oozieuser:-oozie}"  >> ${clusterproperties}
      echo "TODO-OOZIEPROXYUSER-GROUP=" >> ${clusterproperties}
      echo "TODO-OOZIEPROXYUSER-HOST=" >> ${clusterproperties}
    fi
    
    if [[ 'yes' = "$installtempleton" ]] ; then
      echo "TODO-TEMPLETONUSER=${templetonuser:-templeton}"  >> ${clusterproperties}
      echo "TODO-TEMPLETONPROXYUSER-GROUP=users" >> ${clusterproperties}
      echo "TODO-TEMPLETON-HOST=$ttonhosts" >> ${clusterproperties}
     else
      echo "TODO-TEMPLETONUSER=${templetonuser:-templeton}"  >> ${clusterproperties}
      echo "TODO-TEMPLETONPROXYUSER-GROUP=" >> ${clusterproperties}
      echo "TODO-TEMPLETON-HOST=" >> ${clusterproperties}
    fi


    if [[ "true" == "$enableshortcircuit" ]] ; then
      echo "TODO-DFS-DATANODE-DATA-DIR-PERM=750"   >> ${clusterproperties}
    else
      echo "TODO-DFS-DATANODE-DATA-DIR-PERM=700"  >> ${clusterproperties}
    fi
    echo "TODO-SECURITY-TYPE=$securitytype" >> ${clusterproperties}
    echo "TODO-HBASE-USER=${hbaseuser:-hbase}" >> ${clusterproperties}
    echo "TODO-SECURITY-ENABLED=$setsecurity" >> ${clusterproperties}
    echo "TODO-ENABLE-SECURITY-AUTHORIZATION=$setsecurity" >> ${clusterproperties}
    echo "TODO-HADOOP-PID-DIR=$pid_dir/$USER" >> ${clusterproperties}
    echo "TODO-HADOOP-LOG-DIR=$log_dir/$USER" >> ${clusterproperties}
    echo "TODO-HADOOP-PIDDIRPREFIX=$pid_dir" >> ${clusterproperties}
    echo "TODO-HADOOP-LOGDIRPREFIX=$log_dir" >> ${clusterproperties}
    echo "TODO-MAPRED-JOBSTATUS-DIR=file:///$log_dir/$mapreduser/jobstatus" >> ${clusterproperties}
    echo "TODO-SCHEDULER-NAME=$taskscheduler" >> ${clusterproperties}
    echo "TODO-TASK-CONTROLLER=$taskcontrollername" >> ${clusterproperties}
    echo "TODO-TASK-BIN-EXE=$taskcontrollerexe" >> ${clusterproperties}
    echo "TODO-DFS-DATANODE-ADDRESS=$dnaddress" >> ${clusterproperties}
    echo "TODO-DFS-DATANODE-HTTP-ADDRESS=$dnhttpaddress" >> ${clusterproperties}
    echo "TODO-GANGLIA-SERVER=$gangliahost" >> ${clusterproperties}
    if [[ "$enablesnappy" == "yes" && "$enablelzo" == "yes" ]] ; then
      echo "TODO-MAPRED-COMPRESS-MAP-OUTPUT=true" >> ${clusterproperties}
      echo "TODO-COMPRESSION-CODECS=org.apache.hadoop.io.compress.GzipCodec,org.apache.hadoop.io.compress.DefaultCodec,com.hadoop.compression.lzo.LzoCodec,com.hadoop.compression.lzo.LzopCodec,org.apache.hadoop.io.compress.SnappyCodec" >> ${clusterproperties}
      echo "TODO-MAPRED-MAP-OUTPUT-COMPRESSION-CODEC=org.apache.hadoop.io.compress.SnappyCodec" >> ${clusterproperties}
    elif [[ "$enablesnappy" == "yes" ]] ; then
      echo "TODO-MAPRED-COMPRESS-MAP-OUTPUT=true" >> ${clusterproperties}
      echo "TODO-COMPRESSION-CODECS=org.apache.hadoop.io.compress.GzipCodec,org.apache.hadoop.io.compress.DefaultCodec,org.apache.hadoop.io.compress.SnappyCodec" >> ${clusterproperties}
      echo "TODO-MAPRED-MAP-OUTPUT-COMPRESSION-CODEC=org.apache.hadoop.io.compress.SnappyCodec" >> ${clusterproperties}
    elif [[ "$enablelzo" == "yes" ]] ; then
      echo "TODO-MAPRED-COMPRESS-MAP-OUTPUT=true" >> ${clusterproperties}
      echo "TODO-COMPRESSION-CODECS=org.apache.hadoop.io.compress.GzipCodec,org.apache.hadoop.io.compress.DefaultCodec,com.hadoop.compression.lzo.LzoCodec,com.hadoop.compression.lzo.LzopCodec" >> ${clusterproperties}
      echo "TODO-MAPRED-MAP-OUTPUT-COMPRESSION-CODEC=com.hadoop.compression.lzo.LzoCodec" >> ${clusterproperties}
    else
      echo "TODO-MAPRED-COMPRESS-MAP-OUTPUT=false" >> ${clusterproperties}
      echo "TODO-COMPRESSION-CODECS=org.apache.hadoop.io.compress.GzipCodec,org.apache.hadoop.io.compress.DefaultCodec" >> ${clusterproperties}
      echo "TODO-MAPRED-MAP-OUTPUT-COMPRESSION-CODEC=org.apache.hadoop.io.compress.DefaultCodec" >> ${clusterproperties}
    fi

    hadoopConfRoot="${confRoot}/hadoop-conf/"
    [[ -d $hadoopConfRoot ]] && rm -rf $hadoopConfRoot
    mkdir -p $hadoopConfRoot
    cp ${basedir}/confSupport/templates/hadoop-conf/* $hadoopConfRoot
    if [[ "$enablemon" == "yes" ]] ; then
      rm -f $hadoopConfRoot/hadoop-metrics2.properties
      mv $hadoopConfRoot/hadoop-metrics2.properties-GANGLIA $hadoopConfRoot/hadoop-metrics2.properties
    else
      rm $hadoopConfRoot/hadoop-metrics2.properties-GANGLIA
    fi
    for i in $(cat $clusterproperties); do
      for f in $(ls ${hadoopConfRoot}) ; do
        token=`echo $i | awk -F= ' { print $1}'`
        value=`echo $i | awk -F= ' { print $2}'`
        safevalue=$(printf "%s\n" "$value" | sed 's/[\&/]/\\&/g')
        sed "s!$token!${safevalue}!g" ${hadoopConfRoot}/${f} > ${hadoopConfRoot}/${f}.new
        mv ${hadoopConfRoot}/${f}.new ${hadoopConfRoot}/${f}
      done
    done
   cp ${basedir}/nodes ${hadoopConfRoot}/slaves
   cp ${basedir}/nodes ${hadoopConfRoot}/dfs.include
   cp ${basedir}/nodes ${hadoopConfRoot}/mapred.include
   touch ${hadoopConfRoot}/dfs.exclude
   touch ${hadoopConfRoot}/mapred.exclude
   chmod 755 ${hadoopConfRoot}/{slaves,dfs.include,mapred.include}
  }

  ############################################################
  #FUNCTION TO GENERATE ZOOKEEPER CONFIGS
  ############################################################
  zkconfgen() {
    zk_conf="${confRoot}/zk-conf"
    [[ -d ${zk_conf} ]] && rm -rf ${zk_conf}
    mkdir -p ${zk_conf}
    ## write zoo.cfg
    echo "tickTime=${tickTime:-200}" > ${zk_conf}/zoo.cfg
    echo "initLimit=${initLimit:-10}" >> ${zk_conf}/zoo.cfg
    echo "syncLimit=${syncLimit:-10}" >> ${zk_conf}/zoo.cfg
    echo "dataDir=${zk_data_dir}" >> ${zk_conf}/zoo.cfg
    echo "clientPort=${clientPort:-2181}" >> ${zk_conf}/zoo.cfg
    local i=1
    for host in $zkhosts
      do
        echo "server.${i}=${host}:2888:3888" >> ${zk_conf}/zoo.cfg
        ((i++))
    done
    #write zookeeper-env.sh
    echo "export JAVA_HOME=${zkjavahome}" > ${zk_conf}/zookeeper-env.sh
    echo "export ZOO_LOG_DIR=${zk_log_dir}" >> ${zk_conf}/zookeeper-env.sh
    echo "export ZOOPIDFILE=${zk_pid_dir}/zookeeper_server.pid" >> ${zk_conf}/zookeeper-env.sh
    echo "export SERVER_JVMFLAGS= " >> ${zk_conf}/zookeeper-env.sh
    cp ${basedir}/confSupport/templates/zk-conf/log4j.properties ${zk_conf}/log4j.properties
    cp ${basedir}/confSupport/templates/zk-conf/configuration.xsl ${zk_conf}/configuration.xsl
  }

  ############################################################
  #FUNCTION TO GENERATE HBASE CONFIGS
  ############################################################
  hbaseconfgen() {
    zk_conf="${confRoot}/zk-conf"
    hbase_conf="${confRoot}/hbase-conf"
    [[ -d ${hbase_conf} ]] && rm -rf ${hbase_conf}
    mkdir -p ${hbase_conf}
    ## hbase-env.sh
    echo "TODO-HBASE-JAVA-HOME=$hbasejavahome" > ${hbaseproperties}
    echo "TODO-HADOOP-CONF-DIR=$hadoopconfdir" >> ${hbaseproperties}
    echo "TODO-HBASE-CONF-DIR=$hbaseconfdir" >> ${hbaseproperties}
    echo "TODO-ZKCFG-PATH=${zkconfdir}" >> ${hbaseproperties}
    echo "TODO-HBASE-PID-DIR=${hbase_pid_dir}" >> ${hbaseproperties}
    echo "TODO-HBASE-LOG-DIR=${hbase_log_dir}" >> ${hbaseproperties}
    echo "TODO-KEYTAB-PATH=$keytabdir" >> ${hbaseproperties}
    echo "TODO-KERBEROS-DOMAIN=$realm" >> ${hbaseproperties}
    ## hbase-site.xml
    echo "TODO-HBASE-NAMENODE-HOSTNAME=$nnhost" >> ${hbaseproperties}
    echo "TODO-HBASE-TMP-DIR=${hbase_log_dir}" >> ${hbaseproperties}
    echo "TODO-HBASEMASTER-HOSTNAME=$hbmhost" >> ${hbaseproperties}
    echo "TODO-REGIONSERVER-MEMSTORE-UPPERLIMIT=${memstoreUpperLimit:-0.4}" >> ${hbaseproperties}
    echo "TODO-REGIONSERVER-MEMSTORE-LOWERLIMIT=${memstoreLowerLimit:-0.35}" >> ${hbaseproperties}
    echo "TODO-REGIONSERVER-MEMSTORE-LAB=${memstoreLab:-true}" >> ${hbaseproperties}
    echo "TODO-HSTOREFILE-MAXSIZE=${hstorefileMaxsize:-268435456}" >> ${hbaseproperties}
    echo "TODO-HSTORE-COMPACTIONTHRESHOLD=${hstoreCompactionThreshold:-3}" >> ${hbaseproperties}
    echo "TODO-HSTORE-BLOCKINGSTOREFILES=${hstoreBlockingStorefiles:-7}" >> ${hbaseproperties}
    echo "TODO-HFILE-BLOCKCACHE-SIZE=${hfileBlockCacheSize:-0.25}" >> ${hbaseproperties}
    echo "TODO-PRELOADED-REGIONCOPROCESSOR-CLASSES=${regionCoprocessorClasses}" >> ${hbaseproperties}
    echo "TODO-PRELOADED-MASTERCOPROCESSOR-CLASSES=${masterCoprocessorClasses}" >> ${hbaseproperties}
    echo "TODO-ZOOKEEPERQUORUM-SERVERS=$(echo $zkhosts | tr " ", ",")" >> ${hbaseproperties}
    echo "TODO-HDFS-SUPPORT-APPEND=${enableappend:-true}" >> ${hbaseproperties}
    echo "TODO-HDFS-ENABLE-SHORTCIRCUIT-READ=${enableshortcircuit:-true}" >> ${hbaseproperties}
    echo "TODO-HDFS-ENABLE-SHORTCIRCUIT-SKIPCHECKSUM=${enableShortCircuitSkipChecksum:-false}" >> ${hbaseproperties}
    echo "TODO-HBASE-MASTER-HEAPSIZE=${hbase_master_heapsize:-1000m}" >> ${hbaseproperties}
    echo "TODO-HBASE-REGIONSERVER-HEAPSIZE=${hbase_regionserver_heapsize:-1000m}" >> ${hbaseproperties}
    ## hadoop-metrics.properties
    echo "TODO-GANGLIA-SERVER=$gangliahost" >> ${hbaseproperties}

    cp  ${basedir}/confSupport/templates/hbase-conf/* $hbase_conf
    if [[ "$enablemon" == "yes" ]] ; then
      rm -f $hbase_conf/hadoop-metrics.properties
      # Keep both, $hbase_conf/hadoop-metrics.properties.master-GANGLIA and
      # $hbase_conf/hadoop-metrics.properties.regionservers-GANGLIA lying 
      # around - installHbaseConfigs() will take care of copying the fitting 
      # one over to the relevant boxes (renaming each to 
      # hadoop-metrics.properties in the process, of course). 
    else
      rm $hbase_conf/hadoop-metrics.properties.master-GANGLIA
      rm $hbase_conf/hadoop-metrics.properties.regionservers-GANGLIA
    fi
    for i in $(cat $hbasevalueFiles); do
      for f in $(ls ${hbase_conf}) ; do
        token=`echo $i | awk -F= ' { print $1}'`
        value=`echo $i | awk -F= ' { print $2}'`
        safevalue=$(printf "%s\n" "$value" | sed 's/[\&/]/\\&/g')
        sed "s!$token!${safevalue}!g" ${hbase_conf}/${f} > ${hbase_conf}/${f}.new
        mv ${hbase_conf}/${f}.new ${hbase_conf}/${f}
      done
    done
    cp ${basedir}/hbasenodes $hbase_conf/regionservers
  }

  ############################################################
  #FUNCTION TO GENERATE HIVE CONFIGS
  ############################################################
  hiveconfgen() {
    echo "TODO-HADOOP-CONF-DIR=$hadoopconfdir" >> ${hiveclusterproperties}
    echo "TODO-HADOOP-HOME=${hadoophome}" >> ${hiveclusterproperties}
    echo "TODO-HIVE-JAVA-HOME=${hivejavahome}" >> ${hiveclusterproperties}
    echo "TODO-HIVE-CONF-DIR=${hiveconfdir}" >> ${hiveclusterproperties}
    echo "TODO-HIVE-DBROOT=${mysql_connector_path}" >> ${hiveclusterproperties}
    echo "TODO-HIVE-USER=${hiveuser}" >> ${hiveclusterproperties}
    echo "TODO-HIVE-METASTORE-PORT=9083" >> ${hiveclusterproperties}
    echo "TODO-HIVE-MYSQL-SERVER=${mysqldbhost}" >> ${hiveclusterproperties}
    echo "TODO-HIVE-DATABASE-NAME=${databasename}" >> ${hiveclusterproperties}
    echo "TODO-HIVE-METASTORE-USER-NAME=${mysqldbuser}" >> ${hiveclusterproperties}
    echo "TODO-HIVE-METASTORE-USER-PASSWD=${mysqldbpasswd}" >> ${hiveclusterproperties}
    echo "TODO-KEYTAB-PATH=$keytabdir" >> ${hiveclusterproperties}
    echo "TODO-HIVE-HOME=$hivehome" >> ${hiveclusterproperties}
    if [[ $security = "yes" ]] ; then
      setsecurity="true"
    else
      setsecurity="false"
    fi
    if [[ $installhbase = "yes" ]] ; then
       echo "TODO-HBASE-CONF-DIR=$hbaseconfdir" >> ${hiveclusterproperties} 
    fi
    echo "TODO-HIVE-METASTORE-SASL-ENABLED=${setsecurity}" >> ${hiveclusterproperties}
    echo "TODO-HIVE-METASTORE-PRINCIPAL=hive/_HOST@${realm}" >> ${hiveclusterproperties}
    echo "TODO-HIVE-METASTORE-SERVER-HOST=${hivehost}" >> ${hiveclusterproperties}
    if [[ 'yes' = "$installtempleton" ]] ; then
      echo "TODO-TEMPLETONPROXYUSER-GROUP=users" >> ${hiveclusterproperties}
      echo "TODO-TEMPLETON-HOST=$ttonhosts" >> ${hiveclusterproperties}
     else
      echo "TODO-TEMPLETONPROXYUSER-GROUP=" >> ${hiveclusterproperties}
      echo "TODO-TEMPLETON-HOST=" >> ${hiveclusterproperties}
    fi
    
    #This is hardcoded based on the version, need to find a better solution
    echo "TODO-HIVE-AUX-JARS=${hcathome}/share/hcatalog/hcatalog-${hcatalog_version}.jar" >> ${hiveclusterproperties}
    echo "TODO-HIVE-SECURITY-AUTH-ENABLED=true" >> ${hiveclusterproperties}
    echo "TODO-HIVE-SECURITY-AUTH-MANAGER=org.apache.hcatalog.security.HdfsAuthorizationProvider" >> ${hiveclusterproperties}

    hive_conf="${confRoot}/hive-conf"
    [[ -d ${hive_conf} ]] && rm -rf ${hive_conf}
    mkdir -p ${hive_conf}
    cp  ${basedir}/confSupport/templates/hive-conf/* ${hive_conf}
    for i in $(cat ${hiveclusterproperties}); do
      for f in $(ls ${hive_conf}) ; do
        token=`echo $i | awk -F= ' { print $1}'`
        value=`echo $i | awk -F= ' { print $2}'`
        safevalue=$(printf "%s\n" "$value" | sed 's/[\&/]/\\&/g')
        sed "s!$token!${safevalue}!g" ${hive_conf}/${f} > ${hive_conf}/${f}.new
        mv ${hive_conf}/${f}.new ${hive_conf}/${f}
      done
    done
  }


  ############################################################
  #FUNCTION TO GENERATE OOZIE  CONFIGS
  ############################################################
  oozieconfgen() {
    local setsecurityoozie
    if [[ $security = "yes" ]] ; then
      setsecurityoozie="true"
      #this should be kerberos, trying out simple for now
      ooziesecuritytype="kerberos"
    else
      setsecurityoozie="false"
      ooziesecuritytype="simple"
    fi
    echo "TODO-OOZIE-PIDDIRPREFIX=${oozie_pid_dir}/pid" > ${oozieclusterproperties}
    echo "TODO-HADOOP-CONF-DIR=$hadoopconfdir" >> ${oozieclusterproperties}
    echo "TODO-OOZIE-JAVA-HOME=${ooziejavahome}" >> ${oozieclusterproperties}
    echo "TODO-OOZIE-LOGDIRPREFIX=${oozie_log_dir}" >> ${oozieclusterproperties}
    echo "TODO-OOZIE-DB-DIR=${oozie_db_dir}" >> ${oozieclusterproperties}
    echo "TODO-OOZIE-CONF-DIR=${oozieconfdir}" >> ${oozieclusterproperties}
    echo "TODO-OOZIE-USER=${oozieuser}" >> ${oozieclusterproperties}
    echo "TODO-OOZIE-SASL-ENABLED=${setsecurityoozie}" >> ${oozieclusterproperties}
    echo "TODO-KEYTAB-PATH=$keytabdir" >> ${oozieclusterproperties}
    echo "TODO-OOZIE-REALM=${realm}" >> ${oozieclusterproperties}
    local ooziehost_lowercase="`echo $oozieshost | tr '[:upper:]' '[:lower:]'`"
    echo "TODO-OOZIE-PRINCIPAL=oozie/${ooziehost_lowercase}@${realm}" >> ${oozieclusterproperties}
    echo "TODO-OOZIE-HTTP-PRINCIPAL=HTTP/${ooziehost_lowercase}@${realm}" >> ${oozieclusterproperties}
    echo "TODO-OOZIE-JAVA-HOME=${ooziejavahome}" >> ${oozieclusterproperties}
    echo "TODO-OOZIE-SECURITY-TYPE=${ooziesecuritytype}" >> ${oozieclusterproperties}
    echo "TODO-OOZIE-HADOOP-HOME=${hadoophome}" >> ${oozieclusterproperties}
    echo "TODO-OOZIE-SERVER=${oozieshost}" >> ${oozieclusterproperties}
    echo "TODO-MAPREDUSER=$mapreduser" >> ${oozieclusterproperties}
    echo "TODO-HDFSUSER=$hdfsuser" >> ${oozieclusterproperties}
    echo "TODO-HBASE-USER=${hbaseuser:-hbase}" >> ${oozieclusterproperties}
    echo "TODO-KERBEROS-DOMAIN=$realm" >> ${oozieclusterproperties}
    
    echo "TODO-NAMENODE-HOSTNAME=$nnhost" >> ${oozieclusterproperties}
    echo "TODO-MAPREDUSER=$mapreduser" >> ${oozieclusterproperties}
    echo "TODO-HDFSUSER=$hdfsuser" >> ${oozieclusterproperties}
    echo "TODO-HBASE-USER=${hbaseuser:-hbase}" >> ${oozieclusterproperties}

    oozie_conf="${confRoot}/oozie-conf"
    [[ -d ${oozie_conf} ]] && rm -rf ${oozie_conf}
    mkdir -p ${oozie_conf}
    cp  ${basedir}/confSupport/templates/oozie-conf/* ${oozie_conf}
    for i in $(cat ${oozieclusterproperties}); do
      for f in $(ls ${oozie_conf}) ; do
        token=`echo $i | awk -F= ' { print $1}'`
        value=`echo $i | awk -F= ' { print $2}'`
        safevalue=$(printf "%s\n" "$value" | sed 's/[\&/]/\\&/g')
        sed "s!$token!${safevalue}!g" ${oozie_conf}/${f} > ${oozie_conf}/${f}.new
        mv ${oozie_conf}/${f}.new ${oozie_conf}/${f}
      done
    done
  }


  ############################################################
  #FUNCTION TO GENERATE PIG CONFIGS
  ############################################################
  pigconfgen() {
    echo "TODO-HADOOP-HOME=${hadoophome}" > ${pigclusterproperties}
    echo "TODO-JAVA-HOME=${hadoopjavahome}" >> ${pigclusterproperties}

    pig_conf="${confRoot}/pig-conf"
    [[ -d ${pig_conf} ]] && rm -rf ${pig_conf}
    mkdir -p ${pig_conf}
    cp  ${basedir}/confSupport/templates/pig-conf/* ${pig_conf}
    for i in $(cat ${pigclusterproperties}); do
      for f in $(ls ${pig_conf}) ; do
        token=`echo $i | awk -F= ' { print $1}'`
        value=`echo $i | awk -F= ' { print $2}'`
        safevalue=$(printf "%s\n" "$value" | sed 's/[\&/]/\\&/g')
        sed "s!$token!${safevalue}!g" ${pig_conf}/${f} > ${pig_conf}/${f}.new
        mv ${pig_conf}/${f}.new ${pig_conf}/${f}
      done
    done
  }
  
  ############################################################
  #FUNCTION TO GENERATE SQOOP CONFIGS
  ############################################################
  sqoopconfgen() {
    echo "TODO-HADOOP-HOME-TODO=${hadoophome}" > ${sqoopclusterproperties}
    if [ "yes" == "$installhbase" ] ; then
       echo "TODO-HBASE-HOME-TODO=$hbasehome" >> ${sqoopclusterproperties} 
       echo "TODO-ZK-CONF_DIR-TODO=$zkconfdir" >> ${sqoopclusterproperties} 
    fi
    if [ "yes" == "$installhcat" ] ; then
       echo "TODO-HIVE-HOME-TODO=$hivehome" >> ${sqoopclusterproperties} 
    fi
    sqoop_conf="${confRoot}/sqoop-conf"
    [[ -d ${sqoop_conf} ]] && rm -rf ${sqoop_conf}
    mkdir -p ${sqoop_conf}
    cp  ${basedir}/confSupport/templates/sqoop-conf/* ${sqoop_conf}
    for i in $(cat ${sqoopclusterproperties}); do
      for f in $(ls ${sqoop_conf}) ; do
        token=`echo $i | awk -F= ' { print $1}'`
        value=`echo $i | awk -F= ' { print $2}'`
        safevalue=$(printf "%s\n" "$value" | sed 's/[\&/]/\\&/g')
        sed "s!$token!${safevalue}!g" ${sqoop_conf}/${f} > ${sqoop_conf}/${f}.new
        mv ${sqoop_conf}/${f}.new ${sqoop_conf}/${f}
      done
    done
  }

  ############################################################
  #FUNCTION TO GENERATE TEMPLETON CONFIGS
  ############################################################
  templetonconfgen() {

    echo "TODO-HADOOP-CONF-DIR=$hadoopconfdir" > ${templetonclusterproperties}

    #TODO create function for this
    #determine hadoop_prefix based on the install type
    if [ "tar" == "$package" ]; then
      hadoop_prefix="${installdir}/hadoop"
      hcat_prefix="${installdir}/hcat"
    else
      hadoop_prefix="$hadoophome"
      hcat_prefix="/usr"
    fi

    echo "TODO-HADOOP-PREFIX=$hadoop_prefix" >> ${templetonclusterproperties}
    echo "TODO-PIG-TAR-GZ=$pigtarname" >> ${templetonclusterproperties}
    echo "TODO-PIG-TAR-NAME=$pigtarprefix" >> ${templetonclusterproperties}
    echo "TODO-HIVE-TAR-GZ=$hivetarname" >> ${templetonclusterproperties}
    echo "TODO-HIVE-TAR-NAME=$hivetarprefix" >> ${templetonclusterproperties}
    echo "TODO-HCAT-PREFIX=$hcat_prefix" >> ${templetonclusterproperties}
    echo "TODO-HIVE-METASTORE-HOST=$hivehost" >> ${templetonclusterproperties}
    echo "TODO-HIVE-METASTORE-PORT=9083" >> ${templetonclusterproperties}
    echo "TODO-TEMPLETON-PID-DIR=$templeton_pid_dir" >> ${templetonclusterproperties}
    echo "TODO-TEMPLETON-LOG-DIR=$templeton_log_dir" >> ${templetonclusterproperties}

    #templeton requires comma seperated list of host:port for zookeeper servers
    #remove trailing newline
    zkhosts_no_trail_newline="${zkhosts%\\n}"         
    #get all hosts on one line
    zkhosts_line=`echo $zkhosts_no_trail_newline | tr '\n' ' ' `    

    zkhost_port=${clientPort:-2181};
    zkhost_templeton_format=`echo $zkhosts_line | sed "s/ /:${zkhost_port},/g"`
    zkhost_templeton_format="${zkhost_templeton_format}:${zkhost_port}"

    echo "TODO-ZOOKEEPER-HOSTS=$zkhost_templeton_format" >> ${templetonclusterproperties}

    templetonjardir="/usr/share/templeton"
    echo "TODO-TEMPLETON-JAR=${templetonjardir}/templeton.jar" >> ${templetonclusterproperties}
    echo "TODO-TEMPLETON-NAME-JAR=templeton.jar" >> ${templetonclusterproperties}

    zkjarbasedir=$zkhome
    echo "TODO-ZOOKEEPER-JAR=${zkhome}/zookeeper.jar" >> ${templetonclusterproperties}
    echo "TODO-HIVE-METASTORE-SASL-ENABLED=${security}" >> ${templetonclusterproperties}
    local ttonhosts_lowercase="`echo $ttonhosts | tr '[:upper:]' '[:lower:]'`"
    echo "TODO-TEMPLETON-HTTP-PRINCIPAL=HTTP/${ttonhosts_lowercase}@${realm}" >> ${templetonclusterproperties}
    echo "TODO-KEYTAB-PATH=$keytabdir" >> ${templetonclusterproperties}


    templeton_conf="${confRoot}/templeton-conf"
    [[ -d ${templeton_conf} ]] && rm -rf ${templeton_conf}
    mkdir -p ${templeton_conf}
    cp  ${basedir}/confSupport/templates/templeton-conf/* ${templeton_conf}
    for i in $(cat ${templetonclusterproperties}); do
      for f in $(ls ${templeton_conf}) ; do
        token=`echo $i | awk -F= ' { print $1}'`
        value=`echo $i | awk -F= ' { print $2}'`
        safevalue=$(printf "%s\n" "$value" | sed 's/[\&/]/\\&/g')
        sed "s!$token!${safevalue}!g" ${templeton_conf}/${f} > ${templeton_conf}/${f}.new
        mv ${templeton_conf}/${f}.new ${templeton_conf}/${f}
      done
    done
  }

  ############################################################
  #FUNCTION TO GENERATE HDP MONITORING CONFIGS
  ############################################################
  hdpmonconfgen() {
    log0 "Generating configs for HDP Monitoring Dashboard"
    source ${basedir}/resolve_private_to_public_dns.sh

    echo "TODO-NAMENODE-HOSTNAME=${public_nnhost}" > ${hdpmonproperties}
    echo "TODO-SECONDARYNAMENODE-HOSTNAME=${public_snhost}" >> ${hdpmonproperties}
    echo "TODO-JTNODE-HOSTNAME=${public_jthost}" >> ${hdpmonproperties}
    echo "TODO-JOBHISTORY-HOSTNAME=${public_jthost}" >> ${hdpmonproperties}
    echo "TODO-SCHEDULER-NAME=$taskscheduler" >> ${hdpmonproperties}

    echo "TODO-GANGLIAWEB-HOSTNAME=${public_gangliaweb}" >> ${hdpmonproperties}
    echo "TODO-NAGIOSSERVER-HOSTNAME=${public_nagioshost}" >> ${hdpmonproperties}

    echo "TODO-DATANODES-COUNT=${datanodes_count:=0}" >> ${hdpmonproperties}
    echo "TODO-TASKTRACKERS-COUNT=${tasktrackers_count:=0}" >> ${hdpmonproperties}
    echo "TODO-HBASEREGIONSERVERS-COUNT=${hbaseregionservers_count:=0}" >> ${hdpmonproperties}

    echo "TODO-HDP-MON-DASHBOARD-HOSTNAME=${public_dashboardhost}" >> ${hdpmonproperties}
    echo "TODO-HDP-MON-DATASERVICES-HOSTNAME=${public_dashboardhost}" >> ${hdpmonproperties}

    echo "TODO-HDP-CLUSTER-NAME=HDP Cluster" >> ${hdpmonproperties}

    if [[ "$installhbase" == "yes" ]]; then
      echo "TODO-HBASE-INSTALLED=true" >> ${hdpmonproperties}
      echo "TODO-HBASEMASTER-HOSTNAME=${public_hbmhost}" >> ${hdpmonproperties}
    else
      echo "TODO-HBASE-INSTALLED=false" >> ${hdpmonproperties}
      echo "TODO-HBASEMASTER-HOSTNAME=null" >> ${hdpmonproperties}
    fi

    if [[ "$installhive" == "yes" ]]; then
      echo "TODO-HIVE-INSTALLED=true" >> ${hdpmonproperties}
    else
      echo "TODO-HIVE-INSTALLED=false" >> ${hdpmonproperties}
    fi

    if [[ "$installtempleton" == "yes" ]]; then
      echo "TODO-TEMPLETON-INSTALLED=true" >> ${hdpmonproperties}
    else
      echo "TODO-TEMPLETON-INSTALLED=false" >> ${hdpmonproperties}
    fi

    if [[ "$installoozie" == "yes" ]]; then
      echo "TODO-OOZIE-INSTALLED=true" >> ${hdpmonproperties}
      echo "TODO-OOZIE-HOSTNAME=${public_ooziehost}" >> ${hdpmonproperties}
    else
      echo "TODO-OOZIE-INSTALLED=false" >> ${hdpmonproperties}
      echo "TODO-OOZIE-HOSTNAME=null" >> ${hdpmonproperties}
    fi

    hdp_mon_conf="${confRoot}/hdp-mon-conf"
    [[ -d ${hdp_mon_conf} ]] && rm -rf ${hdp_mon_conf}
    mkdir -p ${hdp_mon_conf}
    cp  ${basedir}/confSupport/templates/hdp-mon-conf/* ${hdp_mon_conf}
    for i in $(cat ${hdpmonproperties}); do
      for f in $(ls ${hdp_mon_conf}) ; do
        token=`echo $i | awk -F= ' { print $1}'`
        value=`echo $i | awk -F= ' { print $2}'`
        safevalue=$(printf "%s\n" "$value" | sed 's/[\&/]/\\&/g')
        sed "s!$token!${safevalue}!g" ${hdp_mon_conf}/${f} > ${hdp_mon_conf}/${f}.new
        mv ${hdp_mon_conf}/${f}.new ${hdp_mon_conf}/${f}
      done
    done
  }

  ############################################################
  #FUNCTION TO GENERATE GANGLIA CONFIGS
  ############################################################
  gangliaconfgen() {
    ganglia_runtime_components_dir="${1}";

    [[ -d "${ganglia_runtime_components_dir}" ]] && rm -rf ${ganglia_runtime_components_dir};
    mkdir -p ${ganglia_runtime_components_dir};
    cp ${basedir}/ganglia/* ${ganglia_runtime_components_dir};

    ganglia_conf_templates_dir="${basedir}/confSupport/templates/ganglia-conf";

    sed -e "s!TODO-GANGLIA-SERVER!${gangliahost}!g" \
          ${ganglia_conf_templates_dir}/gangliaClusters.conf.in > ${ganglia_runtime_components_dir}/gangliaClusters.conf;

    sed -e "s!TODO-GMETAD-USER!${gmetad_user}!g" \
        -e "s!TODO-GMOND-USER!${gmond_user}!g" \
        -e "s!TODO-WEBSERVER-GROUP!${webserver_group}!g" \
          ${ganglia_conf_templates_dir}/gangliaEnv.sh.in > ${ganglia_runtime_components_dir}/gangliaEnv.sh;
  }
