HOME="/home/hadoop"
HOME1="/home"
line="50"

#------- Start script ---------
echo "Start name node"
su hdfs - -c "hadoop-daemon.sh --config /etc/hadoop/ start namenode";sleep 5
tail -$line  $HOME/log_dir/hdfs/hadoop-hdfs-namenode-localhost.localdomain.log


echo "Start secondary name node"
su hdfs - -c "hadoop-daemon.sh --config /etc/hadoop start secondarynamenode";sleep 5
tail -$line  $HOME/log_dir/hdfs/hadoop-hdfs-secondarynamenode-localhost.localdomain.log

echo "Start single data node"
su hdfs - -c "hadoop-daemon.sh --config /etc/hadoop start datanode";sleep 5
tail -$line  $HOME/log_dir/hdfs/hadoop-hdfs-datanode-localhost.localdomain.log

echo "Start job tracker"
su mapred - -c "hadoop-daemon.sh --config /etc/hadoop start jobtracker; sleep 25"
tail -$line  $HOME/log_dir/mapred/hadoop-mapred-jobtracker-localhost.localdomain.log

echo "Start history server"
su mapred - -c "hadoop-daemon.sh --config /etc/hadoop start historyserver";sleep 5
tail -$line  $HOME/log_dir/mapred/hadoop-mapred-historyserver-localhost.localdomain.log

echo "Start task trackers"
su mapred - -c "hadoop-daemon.sh --config /etc/hadoop start tasktracker";sleep 5
tail -$line  $HOME/log_dir/mapred/hadoop-mapred-tasktracker-localhost.localdomain.log

echo "Start zookeeper nodes"
su zookeeper - -c "/usr/sbin/zkServer.sh start";sleep 5

echo "Start hbase master"
su hbase - -c "/usr/bin/hbase-daemon.sh --config /etc/hbase start master; sleep 25"
tail -$line  $HOME1/hbase_log_dir/hbase-hbase-master-localhost.localdomain.log

echo "Start hbase regionservers"
su hbase - -c "/usr/bin/hbase-daemon.sh --config /etc/hbase start regionserver";sleep 5
tail -$line  $HOME1/hbase_log_dir/hbase-hbase-regionserver-localhost.localdomain.log

echo "Start hcat server"
#If you are SURE it is not  remove /home/hcat_pid_dir//hcat.pid and re-run this script.
#rm -rf /home/hcat_pid_dir//hcat.pid
/etc/init.d/hcatalog-server start;sleep 5

echo "Service associated with port"
netstat -nltp

echo "*********************************************"

echo "Java Process"
ps auxwwwf | grep java | grep -v grep | awk '{print $1, $11,$12}'

