#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0#
#* Unless required by applicable law or agreed to in writing, software#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.#
#*/

##############################################################
# This script is used to install wget, curl and stop iptables
# The script requires:
#                 Files named as namenode, jobtracker, snamenode, hbasemaster, hivemetastore, nodes, gateway, zknodes and hbasenodes to be present at the same location as where this script is located
# The script reads values from gsInstaller.properties
##############################################################
basedir=`pwd`
source ${basedir}/gsLib.sh

######################################################
# Function to set any OS specific stuff
######################################################
function prepareos {
#  if [[ "$SYSTEM_OS" == "$OS_SLES" ]]; then
#    ssh2host "`echo $allhosts_with_mon | tr ' ' ','`" "if [[ -e '/usr/sbin/update-alternatives' && ! -e '/usr/sbin/alternatives' ]]; then ln -s /usr/sbin/update-alternatives /usr/sbin/alternatives; fi"
#  fi
  #install curl and wget
  ssh2host "$allhosts_with_mon" "${installpkgcmd} wget curl" 
}

add2knownhosts
prepareos

#install HDP repo
installHDPRepo

#only do the local yum repo if no doing suse install
if [ "yes" == "$localyumrepo" ] && [ "$SYSTEM_OS" != "$OS_SLES" ]; then
  echo0 "Setup local repo."
  setupRepo
elif [ "$SYSTEM_OS" == "$OS_SLES" ]; then
  echo0 "Setup local repo for suse."
  setupRepoSuse
fi

#set the install dependencies after install HDP repo again
setInstallDependencies

stopIptables
turnOffSelinux
setupEpel
