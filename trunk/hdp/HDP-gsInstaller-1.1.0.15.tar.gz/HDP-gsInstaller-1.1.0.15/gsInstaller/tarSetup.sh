#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0#
#* Unless required by applicable law or agreed to in writing, software#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.#
#*/

##############################################################
# This script is used to create all the directories prior to tar installation. It also modifies the sudoers file to allow tar install to be performed by user other than root
# The script requires
#                 Files named as namenode, jobtracker, snamenode, hbasemaster, hcatserver, nodes, gateway, zknodes and hbasenodes to be present at the same location as where this script is located
# The script reads values from gsInstaller.properties
##############################################################

basedir=`pwd`
source ${basedir}/gsInstaller.properties
source ${basedir}/gsLib.sh
[ -n "$sshkey" ] && usesshkey="-i $sshkey"

###########################
# Function to set correct permissions and ownership of Install directory
###########################
function setInstallDirs {
  echo0 "Setting up Install dirs"
  for host in $allhosts ; do
    echo "On host $host"
    ssh ${usesshkey} root@$host " mkdir -p $installdir ; chown -R $deployuser:hadoop $installdir ; chmod -R 755 $installdir"
  done
}

###########################
# Function to set correct permissions and ownership of Hadoop log and pid directories
###########################
function setHadoopDirs {
  echo0 "Setting up Hadoop log and pid dirs"
  for host in `echo $nnhost $jthost $snhost $slaves | tr ' ' '\n' | sort | uniq | tr '\n' ' ' ` ; do
    echo "On host $host"
    ssh ${usesshkey} root@$host "mkdir -p $log_dir $pid_dir; chown -R ${deployuser}:hadoop $log_dir $pid_dir; chmod 775 -R $log_dir $pid_dir"
  done
}

###########################
# Function to set correct permissions and ownership of namenode directory
###########################
function setNamenodeDirs {
  echo0 "Setting up namenode dir"
  for host in `echo $nnhost | tr ' ' '\n' | sort | uniq | tr '\n' ' '` ; do
    echo "On host $host"
    for dir in `echo $namenode_dir |  tr "," " "` ; do 
      ssh ${usesshkey} root@$host " mkdir -p $dir ; chown -R ${hdfsuser}:hadoop $dir  ; chmod 755 -R $dir "
    done
  done
}

###########################
# Function to set correct permissions and ownership of secondary namenode directory
###########################
function setSnamenodeDirs {
  echo0 "Setting up secondary namenode dir"
  for host in `echo $snhost | tr ' ' '\n' | sort | uniq | tr '\n' ' '` ; do
    echo "On host $host"
    for dir in `echo $snamenode_dir |  tr "," " "` ; do
      ssh ${usesshkey} root@$host " mkdir -p $dir ; chown -R ${hdfsuser}:hadoop $dir  ; chmod 755 -R $dir "
    done
  done
}

###########################
# Function to set correct permissions and ownership of datanode directory
###########################
function setDatanodeDirs {
  echo0 "Setting up datanode dir"
  for host in `echo $slaves | tr ' ' '\n' | sort | uniq | tr '\n' ' '` ; do
    echo "On host $host"
    for dir in `echo $datanode_dir |  tr "," " "` ; do
    if [[ "true" == "$enableshortcircuit" ]] ; then
      ssh ${usesshkey} root@$host " mkdir -p $dir ; chown -R $hdfsuser:hadoop $dir ; chmod 750 $dir"
    else
      ssh ${usesshkey} root@$host " mkdir -p $dir ; chown -R $hdfsuser:hadoop $dir ; chmod 700 $dir"
    fi
    done
  done
}

###########################
# Function to set correct permissions and ownership of mapreduce directory
###########################
function setMapredDirs {
  echo0 "Setting up mapred dir"
  for host in `echo $jthost $slaves | tr ' ' '\n' | sort | uniq | tr '\n' ' '` ; do
    echo "On host $host"
    for dir in `echo $mapred_dir |  tr "," " "` ; do
    ssh ${usesshkey} root@$host " mkdir -p $dir ; chown -R $mapreduser:hadoop $dir; chmod -R 755 $dir"
  done
done
}

###########################
# Function to set correct permissions and ownership of hbase log and pid directory
###########################
function setHbaseDirs {
  if [[ $installhbase="yes" ]] ; then
    echo0 "Setting hbase dir"
    for host in `echo $hbmhost $rshosts | tr ' ' '\n' | sort | uniq | tr '\n' ' '` ; do
      echo "On host $host"
      for dir in `echo $hbase_log_dir $hbase_pid_dir` ; do
        ssh ${usesshkey} root@$host " mkdir -p $dir ; chown -R $hbaseuser:hadoop $dir ; chmod -R 775 $dir"
      done
    done
  fi
}

###########################
# Function to set correct permissions and ownership of Zookeper data, log, pid directory
###########################
function setZkDirs {
  if [[ $installhbase="yes" ]] ; then
    echo0 "Setting up zookeeper dir"
    for host in `echo $zkhosts | tr ' ' '\n' | sort | uniq | tr '\n' ' '` ; do
      echo "On host $host"
      for dir in `echo  $zk_log_dir $zk_pid_dir $zk_data_dir` ; do
        ssh ${usesshkey} root@$host " mkdir -p $dir ; chown -R $zkuser:hadoop $dir ; chmod -R 775 $dir" 
      done
    done
  fi
}
###########################
# Function to set correct permissions and ownership of Oozie pid and log directory
###########################
function setOozieDirs {
  if [[ $installoozie="yes" ]] ; then
    echo0 "Setting up oozie dir"
    for host in `echo $oozieshost | tr ' ' '\n' | sort | uniq | tr '\n' ' '` ; do
      echo "On host $host"
      for dir in `echo  $oozie_log_dir $oozie_pid_dir $oozie_db_dir ` ; do
        ssh ${usesshkey} root@$host " mkdir -p $dir ; chown -R $oozieuser:hadoop $dir ; chmod -R 775 $dir"   
      done
    done
  fi
}


###########################
# Function to set correct permissions and ownership of Hcat pid and log directory
###########################
function setHcatDirs {
  if [[ $installhcat="yes" ]] ; then
    echo0 "Setting up hcat dir"
    for host in `echo $hcshost | tr ' ' '\n' | sort | uniq | tr '\n' ' '` ; do
      echo "On host $host"
      for dir in `echo  $hcat_log_dir $hcat_pid_dir ` ; do
        ssh ${usesshkey} root@$host " mkdir -p $dir ; chown -R $hcatuser:hadoop $dir ; chmod -R 775 $dir"   
      done
    done
  fi
}
###########################
# Function to set correct permissions and ownership of Templeton directories
###########################
function setTempletonDirs {
  if [[ $installtempleton="yes" ]] ; then
    echo0 "Setting up templeton dir"
    for host in `echo $ttonhosts | tr ' ' '\n' | sort | uniq | tr '\n' ' '` ; do
      echo "On host $host"
      for dir in `echo  $templeton_log_dir $templeton_pid_dir ` ; do
        ssh ${usesshkey} root@$host "rm -rf $dir/* ; mkdir -p $dir ; chown -R $templetonuser:hadoop $dir ; chmod -R 775 $dir"   
      done
    done
  fi
}

###########################
# Function setup passwordless ssh for deployuser
###########################
function setupPasswordlessSsh {
  echo0 "Setting up passwordless ssh for $deployuser"
  chown -R ${deployuser}:hadoop /home/${deployuser}/
  su - ${deployuser} -c "printf '\n' | ssh-keygen -t rsa -P ''"

  for host in $allhosts ; do
    echo "============="
    echo "Copying keyfiles from /home/$deployuser to host $host"
    echo "============="
    ssh ${usesshkey} root@$host "mkdir -p /home/$deployuser/.ssh"
    scp ${usesshkey}  /home/$deployuser/.ssh/id_rsa.pub root@$host:/home/${deployuser}/.ssh/authorized_keys2
  done
}

###########################
# Function to populate sudoers file
###########################
function populateSudoersFile {
  echo0 "Updating sudoers file"
  for host in $allhosts ; do
    echo "On host $host"
    ssh ${usesshkey} root@$host "echo '$deployuser ALL=($hdfsuser) NOPASSWD: ALL' >> /etc/sudoers"
    ssh ${usesshkey} root@$host "echo '$deployuser ALL=($mapreduser) NOPASSWD: ALL' >> /etc/sudoers"
    if [[ $installhbase="yes" ]] ; then
      ssh ${usesshkey} root@$host "echo '$deployuser ALL=($hbaseuser) NOPASSWD: ALL' >>  /etc/sudoers"
      ssh ${usesshkey} root@$host "echo '$deployuser ALL=($zkuser) NOPASSWD: ALL' >> /etc/sudoers"
    fi
    if [[ $installoozie="yes" ]] ; then
      ssh ${usesshkey} root@$host "echo '$deployuser ALL=($oozieuser) NOPASSWD: ALL' >> /etc/sudoers"
    fi
    if [[ $installhcat="yes" ]] ; then
      ssh ${usesshkey} root@$host "echo '$deployuser ALL=($hcatuser) NOPASSWD: ALL' >> /etc/sudoers"
    fi
    if [[ $installtempleton="yes" ]] ; then
      ssh ${usesshkey} root@$host "echo '$deployuser ALL=($templetonuser) NOPASSWD: ALL' >> /etc/sudoers"
    fi
    ssh ${usesshkey} root@$host "echo '$deployuser ALL=($smoke_test_user) NOPASSWD: ALL' >> /etc/sudoers"
  done
}

setInstallDirs
setHadoopDirs
setNamenodeDirs
setSnamenodeDirs
setDatanodeDirs
setMapredDirs
setHbaseDirs
setZkDirs
setOozieDirs
setHcatDirs
setTempletonDirs
setupPasswordlessSsh
populateSudoersFile

