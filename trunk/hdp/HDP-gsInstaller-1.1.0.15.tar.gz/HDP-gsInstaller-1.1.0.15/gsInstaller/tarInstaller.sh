#! /bin/bash

#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

  #SET ALL PROPERTIES REQUIRED BY TARINSTALLER
  jdkinstallpath="${jdkinstallpath:-$installdir}"
  hadooptarname=`echo $hadooptarurl | awk -F/ '{ print $NF }'`
  hadoopname=`echo $hadooptarname | sed -nre 's/[0-9]*(([0-9]+\.)*[0-9]+).*/\1/p'`
  pigtarname=`echo $pigtarurl | awk -F/ '{ print $NF }'`
  pigname=`echo $pigtarname | cut -d. -f-3`
  templetontarname=`echo $templetontarurl | awk -F/ '{ print $NF }'`
  templetonname=`echo $templetontarname | cut -d. -f-3`
  hcattarname=`echo $hcattarurl | awk -F/ '{ print $NF }'`
  hcatname=`echo $hcattarname | cut -d. -f-3`
  oozietarname=`echo $oozietarurl | awk -F/ '{ print $NF }'`
  extjszipname=`echo $extjsurl | awk -F/ '{ print $NF }'`
  ooziename=`echo $oozietarname | cut -d. -f-3 |  cut -d- -f-2`
  hbasetarname=`echo $hbasetarurl | awk -F/ '{ print $NF }'`
  hbasename=`echo $hbasetarname | cut -d. -f-3`
  zktarname=`echo $zookeepertarurl | awk -F/ '{ print $NF }'`
  zkname=`echo $zktarname | cut -d. -f-3`
  zkhome="${deploypath}/${zkname}"
  templetonhome="${deploypath}/templeton"
  hadoophome="${deploypath}/hadoop"
  hadoopconfdir="${deploypath}/hadoop-conf"
  hcatconfdir="${deploypath}/hcat-conf"
  jdk32name=`echo $jdk32url | awk -F/ '{ print $NF }' | cut -d'?' -f1`
  jdk64name=`echo $jdk64url | awk -F/ '{ print $NF }' | cut -d'?' -f1`
  jcepolicyname=`echo $jdksecurityurl | awk -F/ '{ print $NF }' | cut -d'?' -f1`
  java32install_cmd="mkdir -p ${jdkinstallpath}/jdk32 ; chmod +x ${destdir}/$jdk32name; \
    cd ${jdkinstallpath}/jdk32 ; echo A | ${destdir}/./$jdk32name -noregister > /dev/null 2>&1"
  java64install_cmd="mkdir -p ${jdkinstallpath}/jdk64 ; chmod +x ${destdir}/$jdk64name ; \
    cd ${jdkinstallpath}/jdk64 ; echo A | ${destdir}/./$jdk64name -noregister > /dev/null 2>&1"
  jceinstall_cmd="cd ${javahome}/jre/lib/security ; rm -f local_policy.jar ; \
    rm -f US_export_policy.jar; unzip -o -j -q ${destdir}/$jcepolicyname"
  hadoopjdk64link="ln -fs ${java64home} ${deploypath}/hadoop-jdk1.6.0_26"
  zkjdk32link="ln -fs ${java32home} ${deploypath}/zk-jdk1.6.0_26"
  hadoopjdk32link="ln -fs ${java32home} ${deploypath}/hadoop-jdk1.6.0_26"
  hbasejdk32link="ln -fs ${java32home} ${deploypath}/hbase-jdk1.6.0_26"
  jdk64link="ln -sf ${jdkinstallpath}/jdk64/jdk1.6.0_26 ${deploypath}/jdk1.6.0_26"
  jdk32link="ln -sf ${jdkinstallpath}/jdk32/jdk1.6.0_26 ${deploypath}/jdk1.6.0_26"
  hadoopmasternodes="$(cat jobtracker snamenode namenode)"
  hadoopslavenodes="$(cat nodes | tr '\n' ',')"
  hadoopnodes="${hadoopmasternodes} ${hadoopslavenodes}"
  mysql_connector_path="${deploypath}/hcat/share/hcatalog/lib"
  hcatjavahome="${installdir}/hcat-jdk1.6.0_26"
  hbasejavahome="${installdir}/hbase-jdk1.6.0_26"
  hadoopjavahome="${installdir}/hadoop-jdk1.6.0_26"
  hcatjavahome="${installdir}/hcat-jdk1.6.0_26"
  ttonjavahome="${installdir}/templeton-jdk1.6.0_26"
  ooziejavahome="${installdir}/oozie-jdk1.6.0_26"
  zkjavahome="${installdir}/zk-jdk1.6.0_26"
  hbasehome="${installdir}/hbase"
  hivehome="${installdir}/hcat"

  #Sqoop
  sqooptarname=`echo $sqooptarurl | awk -F/ '{ print $NF }'`

  ############################################################
  #FUNCTION TO download all artifacts
  ############################################################
  setup() {
    echo0 "Download all necessary Artifacts"
    downloadstuff $hadooptarurl $hadooptarsize
    if [[ "$installjava" == "true" && "$enablesecurity" == "yes" ]]; then
      downloadstuff $jdk32url $jdk32size
      downloadstuff $jdk64url $jdk64size
      downloadstuff $jdksecurityurl $jcesize
    elif [[ "$installjava" == "true" && "$enablesecurity" == "no" ]]; then
      downloadstuff $jdk32url $jdk32size
      downloadstuff $jdk64url $jdk64size
    fi
    [[ "$installzk" == "yes" ]] && downloadstuff $zookeepertarurl $zktarsize
    [[ "$installhbase" == "yes" ]] && downloadstuff $hbasetarurl $hbasetarsize
    [[ "$installhcat" == "yes" ]] && downloadstuff $hcattarurl $hcattarsize  \
       && downloadstuff $mysqljdbcurl $mysqljzipsize
    [[ "$installpig" == "yes" || "$installtempleton" == "yes" ]] && downloadstuff $pigtarurl $pigtarsize
    [[ "$installtempleton" == "yes" ]] && downloadstuff $templetontarurl $templetontarsize
    [[ "$installoozie" == "yes" ]] && downloadstuff $oozietarurl $oozietarsize
    [[ "$installoozie" == "yes" ]] && downloadstuff $extjsurl $extjssize
    [[ "$enablelzo" == "yes" ]] && downloadstuff $hadooplzourl $hadooplzosize
    #Sqoop
    [[ "$installsqoop" == "yes" ]] && downloadstuff $sqooptarurl $sqooptarsize
 }

  ############################################################
  #FUNCTION TO INSTALL HADOOP
  ############################################################
  installHadoop() {
   echo0 "Deploying Hadoop"
   hadoop_scp_cmd="${artifactdownloaddir}/${hadooptarname}"
   hadoop_cmd="cd ${deploypath} ; tar xzf ${destdir}/${hadooptarname} ; \
     chmod 755 -R ${deploypath}/$hadoopname/bin; \
     ln -sf ${deploypath}/$hadoopname ${deploypath}/hadoop"
   scp2host "${1}" "${hadoop_scp_cmd}" "${destdir}"
   ssh2host "${1}" "${hadoop_cmd}"
  }
  
  ############################################################
  #FUNCTION TO INSTALL Hadoop Lzo
  ############################################################
  installHadoopLzo() {
    if [ 'yes' != "$enablelzo" ]; then
      return
    fi
    local all_nodes="$1"
    echo0 "Deploying LZO"
    #scp the tar ball to all nodes
    local file_to_scp="${artifactdownloaddir}/${hadooplzotarname}"
    scp2host "$all_nodes" "${file_to_scp}" "${destdir}"
    
    #cmd to untar and copy the appropriate files over
    local untar_cmd="cd ${destdir}; tar xzf ${destdir}/${hadooplzotarname}; chown -R ${deployuser}:hadoop $hadooplzoname"
    #copy the files over
    local lzo_dir="${destdir}/${hadooplzoname}"
    #copy the lzo jar to $HADOOP_HOME/lib
    #copy the 32 and 64 bit native libraries
    #Use move so that symlinks are preserved
    local setup_cmd="cp -f ${lzo_dir}/hadoop-lzo-0.5.0.jar ${hadoophome}/lib/. ; \
                     rm -f ${hadoophome}/lib/native/Linux-{i386-32,amd64-64}/libgplcompression* ; \
                     mv ${lzo_dir}/lib/native/Linux-i386-32/libgplcompression* ${hadoophome}/lib/native/Linux-i386-32/. ; \
                     mv ${lzo_dir}/lib/native/Linux-amd64-64/libgplcompression* ${hadoophome}/lib/native/Linux-amd64-64/. "
    ssh2host "$all_nodes" "${untar_cmd};${setup_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL ZOOKEEPER
  ############################################################
  installZk() {
    echo0 "Deploying Zookeeper"
    zk_cmd="cd ${deploypath} ; tar xzf ${destdir}/${zktarname} ; \
        ln -sf ${deploypath}/$zkname ${deploypath}/zookeeper; \
        ln -sf ${deploypath}/$zkname/libexec/zkEnv.sh ${deploypath}/$zkname/bin/."
    scp2host "${1}" "${artifactdownloaddir}/${zktarname}" "${destdir}"
    ssh2host "${1}" "${zk_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL HBASE
  ############################################################
  installHbase() {
    echo0 "Deploying Hbase"
    hbasehome="${deploypath}/${hbasetarname}"
    hbase_cmd="cd ${deploypath}; tar xzf ${destdir}/${hbasetarname} ; \
        rm -f ${deploypath}/$hbasename/lib/hadoop-core-*.jar;\
        ln -sf ${deploypath}/$hbasename ${deploypath}/hbase;\
        ln -sf ${deploypath}/hadoop/hadoop-core-*.jar ${deploypath}/$hbasename/lib/.
        ln -sf ${deploypath}/hadoop/lib/commons-configuration-*.jar ${deploypath}/$hbasename/lib/."
    scp2host "${1}" "${artifactdownloaddir}/${hbasetarname}" "${destdir}"
    ssh2host "${1}" "${hbase_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL PIG
  ############################################################
  installPig() {
    echo0 "Deploying Pig"
    pig_cmd="cd ${deploypath} ; tar xzf ${destdir}/${pigtarname} ; \
        chmod 755 -R ${deploypath}/$pigname/bin; \
        ln -sf ${deploypath}/$pigname ${deploypath}/pig"
    scp2host "${1}" "${artifactdownloaddir}/${pigtarname}" "${destdir}"
    ssh2host "${1}" "${pig_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL TEMPLETON
  ############################################################
  installTempleton() {
    echo0 "Deploying Templeton"
    templeton_cmd="cd ${deploypath} ; tar xzf ${destdir}/${templetontarname} ; \
        ln -sf ${deploypath}/$templetonname ${deploypath}/templeton"
    scp2host "${1}" "${artifactdownloaddir}/${templetontarname}" "${destdir}"
    ssh2host "${1}" "${templeton_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL HCAT
  ############################################################
  installHcat() {
    echo0 "Deploying Hcat"
    hcat_cmd="cd ${deploypath} ; tar xzf ${destdir}/${hcattarname} ; \
        chmod 755 -R ${deploypath}/$hcatname/bin; \
        ln -fs ${deploypath}/$hcatname ${deploypath}/hcat; \
        ln -fs ${java32home} ${hcatjdkhome};\
        cd ${mysql_connector_path}; unzip -o -j ${destdir}/${mysqljzipname} '*.jar' -x */lib/*"

    local clientnodes="${1},$gwhost";

    if [[ "$installtempleton" == "yes" ]] ; then
      clientnodes="$(echo $ttonhosts | tr " " ","),${clientnodes}"
    fi

    scp2host "${clientnodes}" "${artifactdownloaddir}/${hcattarname},\
       ${artifactdownloaddir}/${mysqljzipname}" "${destdir}"
    ssh2host "${clientnodes}" "${hcat_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL OOZIE
  ############################################################
  installOozie() {
    echo0 "Deploying Oozie"
    oozie_cmd="cd ${deploypath} ; tar xzf ${destdir}/${oozietarname} ; \
        unzip -o -d ${deploypath}/extjs ${destdir}/${extjszipname}; \
        chown -R ${deployuser}:hadoop ${deploypath}/$ooziename ; \
        chmod 755 -R ${deploypath}/$ooziename/bin; \
        chmod 775 -R ${deploypath}/$ooziename; \
        ln -fs ${deploypath}/$ooziename ${deploypath}/oozie; \
        ln -fs ${java32home} ${ooziejavahome};"
    oozie_unpack_examples_cmd="cd ${deploypath}/oozie ; tar -xzf oozie-examples.tar.gz"
    scp2host "${1}" "${artifactdownloaddir}/${oozietarname}" "${destdir}"
    scp2host "${1}" "${artifactdownloaddir}/${extjszipname}" "${destdir}"
    ssh2host "${1}" "${oozie_cmd} ${oozie_unpack_examples_cmd}"
  }

 ############################################################
  #FUNCTION TO INSTALL JDK
  ############################################################
  installJdk() {
    echo0 "Installing Jdk"
    if [[ "$installjava" == "true" && "$enablesecurity" == "yes" ]] ; then
      scp2host "${1}" \
        "$artifactdownloaddir/$jdk32name,$artifactdownloaddir/$jdk64name,\
        $artifactdownloaddir/$jcepolicyname" "${destdir}"
      ssh2host "${1}" \
            "${java64install_cmd};${java32install_cmd};${jceinstall_cmd}"
    elif [[ "$installjava" == "true" && "$enablesecurity" == "no" ]] ; then
      scp2host "${1}" \
        "$artifactdownloaddir/$jdk32name,$artifactdownloaddir/$jdk64name" "${destdir}"
      ssh2host "${1}" \
            "${java64install_cmd};${java32install_cmd}" \
            "${destdir}"
    fi
  }

  ############################################################
  #FUNCTION TO INSTALL ZOOKEEPER CONFIGS
  ############################################################
  installZkConfigs() {
    echo0 "Installing Zookeeper Configs"
    if [[ "${user_configs}" == "" ]] ; then
      zkconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/zk-conf.tar.gz zk-conf
    scp2host "${1}" "${artifactdownloaddir}/zk-conf.tar.gz" "${destdir}"
    conf_cmd="cd ${deploypath} ; rm -rf ${deploypath}/zk-conf ; \
    tar xzf ${destdir}/zk-conf.tar.gz ; rm -rf zookeeper/conf ; \
    ln -s ${deploypath}/zk-conf zookeeper/conf"
    ssh2host "${1}" "${conf_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL HADOOP CONFIGS
  ############################################################
  installHadoopConfigs() {
    echo0 "Installing Hadoop Configs"
    if [[ "${user_configs}" == "" ]] ; then
      hadoopconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/hadoop-conf.tar.gz hadoop-conf;
    scp2host "${1}" "${artifactdownloaddir}/hadoop-conf.tar.gz" "${destdir}"
    conf_cmd="cd ${deploypath} ; rm -rf ${deploypath}/hadoop-conf ; \
    tar xzf ${destdir}/hadoop-conf.tar.gz ; rm -rf hadoop/conf ; \
    ln -fs ${deploypath}/hadoop-conf hadoop/conf ; chmod a+x ${deploypath}/hadoop-conf/health_check"
    ssh2host "${1}" "${conf_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL HCAT CONFIGS
  ############################################################
  installHcatConfigs() {
    echo0 "Installing Hcat Configs"
    if [[ "${user_configs}" == "" ]] ; then
      hcatconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/hcat-conf.tar.gz hcat-conf;

    local clientnodes="${1},$gwhost";
    if [[ "$installtempleton" == "yes" ]] ; then
      clientnodes="$(echo $ttonhosts | tr " " ","),${clientnodes}"
    fi

    scp2host "${clientnodes}" "${artifactdownloaddir}/hcat-conf.tar.gz" "${destdir}"

    conf_cmd="cd ${deploypath}; rm -rf ${deploypath}/hcat-conf ${deploypath}/hcat/conf ; \
    tar xzf ${destdir}/hcat-conf.tar.gz; rm -rf ${deploypath}/hcat/etc/* ;ln -sf ${deploypath}/hcat-conf ${deploypath}/hcat/etc/hcatalog; \
    ln -sf ${deploypath}/hcat-conf ${deploypath}/hcat/share/hcatalog/conf;"
    ssh2host "${clientnodes}" "${conf_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL OOZIE CONFIGS
  ############################################################
  installOozieConfigs() {
    echo0 "Installing Oozie Configs"
    if [[ "${user_configs}" == "" ]] ; then
      oozieconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/oozie-conf.tar.gz oozie-conf;
    scp2host "${1}" "${artifactdownloaddir}/oozie-conf.tar.gz" "${destdir}"
    conf_cmd="cd ${deploypath}; rm -rf ${deploypath}/oozie-conf ${deploypath}/oozie/conf ; \
    tar xzf ${destdir}/oozie-conf.tar.gz; ln -sf ${deploypath}/oozie-conf ${deploypath}/oozie/conf;"
    ssh2host "${1}" "${conf_cmd}"
    
    #copy the mapred-site.xml
    ssh2host "${oozieshost}" "$SUDOUSERPREFIX ${oozieuser} $SUDOCMDOPTION ln -s  ${hadoopconfdir}/mapred-site.xml ${deploypath}/oozie/oozie-server/lib/mapred-site.xml" 
  }


  ############################################################
  #FUNCTION TO INSTALL PIG CONFIGS
  ############################################################
  installPigConfigs() {
    echo0 "Installing Pig Configs"
    if [[ "${user_configs}" == "" ]] ; then
      pigconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/pig-conf.tar.gz pig-conf;
    scp2host "${1}" "${artifactdownloaddir}/pig-conf.tar.gz" "${destdir}"
    conf_cmd="cd ${deploypath}; rm -rf ${deploypath}/pig-conf ${deploypath}/pig/conf ; \
    tar xzf ${destdir}/pig-conf.tar.gz; ln -sf ${deploypath}/pig-conf ${deploypath}/pig/conf;"
    ssh2host "${1}" "${conf_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL TEMPLETON CONFIGS
  ############################################################
  installTempletonConfigs() {
    echo0 "Installing Templeton Configs"
    if [[ "${user_configs}" == "" ]] ; then
      templetonconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/templeton-conf.tar.gz templeton-conf;
    scp2host "${1}" "${artifactdownloaddir}/templeton-conf.tar.gz" "${destdir}"
    conf_cmd="cd ${deploypath}; rm -rf ${deploypath}/templeton-conf ${deploypath}/templeton/conf ; \
    tar xzf ${destdir}/templeton-conf.tar.gz; ln -sf ${deploypath}/templeton-conf ${deploypath}/templeton/conf;"
    ssh2host "${1}" "${conf_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL HBase CONFIGS
  ############################################################
  installHbaseConfigs() {
    echo0 "Installing Hbase Configs"
    if [[ "${user_configs}" == "" ]] ; then
      hbaseconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/hbase-conf.tar.gz hbase-conf;
    scp2host "${1}" "${artifactdownloaddir}/hbase-conf.tar.gz" "${destdir}"
    conf_cmd="cd ${deploypath}; rm -rf ${deploypath}/hbase-conf ${deploypath}/hbase/conf; \
    tar xzf ${destdir}/hbase-conf.tar.gz; ln -sf ${deploypath}/hbase-conf ${deploypath}/hbase/conf"
    ssh2host "${1}" "${conf_cmd}"
  }

  ############################################################
  #FUNCTION TO DEPLOY SQOOP
  ############################################################
  deploySqoop() {
    if [[ "$installsqoop" == "yes" ]] ; then
      installSqoop "$gwhost"
      installSqoopConfigs "$gwhost"
    fi
  }

  ############################################################
  #FUNCTION TO INSTALL SQOOP
  ############################################################
  installSqoop() {
    echo0 "Deploying Sqoop"
    sqoop_cmd="cd ${deploypath} ; tar xzf ${destdir}/${sqooptarname} ; \
        chmod 755 -R ${deploypath}/sqoop-[0-9]*/bin; \
        ln -sf ${deploypath}/sqoop-[0-9]* ${deploypath}/sqoop"
    scp2host "${1}" "${artifactdownloaddir}/${sqooptarname}" "${destdir}"
    ssh2host "${1}" "${sqoop_cmd}"
  }
  
  ############################################################
  #FUNCTION TO INSTALL SQOOP CONFIGS
  ############################################################
  installSqoopConfigs() {
    echo0 "Installing Sqoop Configs"
    sqoopconfgen
    cd ${confRoot}; tar czf ${artifactdownloaddir}/sqoop-conf.tar.gz sqoop-conf
    scp2host "${1}" "${artifactdownloaddir}/sqoop-conf.tar.gz" "${destdir}"
    conf_cmd="cd ${deploypath}; rm -rf ${deploypath}/sqoop-conf ${deploypath}/sqoop/conf; \
    tar xzf ${destdir}/sqoop-conf.tar.gz; ln -sf ${deploypath}/sqoop-conf ${deploypath}/sqoop/conf"
    ssh2host "${1}" "${conf_cmd}"
  }

  ###############################################################
  #FUNCTION TO SETUP THE INSTALL DIR
  ###############################################################
  installDirSetup () {
    setupinstalldir="[[ -d ${installdir} ]] && chown -R ${deployuser}:hadoop ${installdir} \
      &&  chmod 755 ${installdir}"
    ssh2host "${allhosts}" "${setupinstalldir}"
  }

  ###############################################################
  #FUNCTION TO SETUP HADOOP DIRS
  ###############################################################
  hadoopDirSetup() {
    echo0 "Setting up various directories required by hadoop"
    datanodedirs=`echo $datanode_dir | tr "," " "`
    namenodedirs=`echo $namenode_dir | tr "," " "`
    snamenodedirs=`echo $snamenode_dir | tr "," " "`
    mapreddirs=`echo $mapred_dir | tr "," " " `
    mapredtmpdir=`echo ${mapred_tmp_dir} | tr "," " "`
    hadoophosts=$(echo $snhost $nnhost $jthost $gwhost $slaves)
    uniquenamenodes=$(echo $snhost $nnhost | tr " " "\n" | sort | uniq )
    rmcmd="rm -rf"
      if [[ "$upgrade" == "yes" ]] ; then
        rmcmd="echo"
      fi
    setuplogdir="$rmcmd $log_dir/*; chmod -R 775 $log_dir; \
      chown -R ${deployuser}:hadoop $log_dir"
    setuppiddir="$rmcmd $pid_dir; chmod -R 775 $pid_dir; \
      chown -R ${deployuser}:hadoop $pid_dir"

    for i in $(echo $datanodedirs)
      do
        ssh2host "$(echo $slaves | tr " " ",")" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION $rmcmd $i/*"
    done
  }

  ###############################################################
  #FUNCTION TO SETUP HBASE DIRS
  ###############################################################
  hbaseDirSetup() {
    setuphbasedir1="mkdir -p ${hbase_log_dir} ${hbase_pid_dir}"
    setuphbasedir2="chown -R ${hbaseuser}:hadoop ${hbase_log_dir} ${hbase_pid_dir}"
    setuphbasedir3="chmod 755 -R ${hbase_log_dir} ${hbase_pid_dir}"
    if [[ $installhbase == "yes" ]] ; then
      echo0 "Setting up various directories required by Hbase"
      ssh2host "$(echo $hbmhost $rshosts | tr "\n" " ")" "$SUDOUSERPREFIX $hbaseuser $SUDOCMDOPTION $setuphbasedir1 ; \
      $SUDOUSERPREFIX $hbaseuser $SUDOCMDOPTION $setuphbasedir2 ; \
      $SUDOUSERPREFIX $hbaseuser $SUDOCMDOPTION $setuphbasedir3"
    fi
  }
  
  ###############################################################
  #FUNCTION TO SETUP ZOOKEEPER DIRS
  ###############################################################
  zkDirSetup() {
    zkdirs="$zk_log_dir $zk_pid_dir $zk_data_dir"
    setupzkdirs1="mkdir -p ${zkdirs}"
    setupzkdirs2="chmod 755 -R ${zkdirs}"
    setupzkdirs3="chown -R ${zkuser}:hadoop ${zkdirs}"
    if [[ $installzk == "yes" ]] ; then
      echo0 "Setting up various directories required by Zookeeper"
      ssh2host "$(echo ${zkhosts} | tr "\n " " ")" "$SUDOUSERPREFIX ${zkuser} $SUDOCMDOPTION $setupzkdirs1 ; \
      $SUDOUSERPREFIX ${zkuser} $SUDOCMDOPTION $setupzkdirs2 ; \
      $SUDOUSERPREFIX ${zkuser} $SUDOCMDOPTION $setupzkdirs3"
    fi
  }

  ###############################################################
  #FUNCTION TO SETUP HCAT DIRS
  ###############################################################
  hcatDirSetup() {
    setuphcatdir1="mkdir -p ${hcat_log_dir} ${hcat_pid_dir}"
    setuphcatdir2="chown -R ${hcatuser}:hadoop ${hcat_log_dir} ${hcat_pid_dir}"
    setuphcatdir3="chmod 775 -R ${hcat_log_dir} ${hcat_pid_dir}"
    if [[ $installhcat == "yes" ]] ; then
      echo0 "Setting up various directories required by hcatalog"
      ssh2host "${hcshost}" "$SUDOUSERPREFIX ${hcatuser} $SUDOCMDOPTION $setuphcatdir1 ; \
      $SUDOUSERPREFIX ${hcatuser} $SUDOCMDOPTION $setuphcatdir2 ; \
      $SUDOUSERPREFIX ${hcatuser} $SUDOCMDOPTION $setuphcatdir3"
    fi
  }

  ###############################################################
  #FUNCTION TO SETUP TEMPLETON DIRS
  ###############################################################
  templetonDirSetup() {
    setuptempletondir1="mkdir -p $templeton_log_dir; chown -R ${templetonuser}:hadoop $templeton_log_dir"
    setuptempletondir2="mkdir  -p $templeton_pid_dir; chown -R ${templetonuser}:hadoop $templeton_pid_dir"
    setuptempletondir3="chmod 775 -R $templeton_log_dir $templeton_pid_dir"

    if [[ $installtempleton == "yes" ]] ; then
        echo0 "Setting up various directories required by templeton"
        for i in $ttonhosts
          do
            ssh2host "${i}" "$SUDOUSERPREFIX ${templetonuser} $SUDOCMDOPTION $setuptempletondir1; \
            $SUDOUSERPREFIX ${templetonuser} $SUDOCMDOPTION $setuptempletondir2; \
            $SUDOUSERPREFIX ${templetonuser} $SUDOCMDOPTION $setuptempletondir3"
          done
    fi
  }

  ###############################################################
  #FUNCTION TO SETUP Oozie DIRS
  ###############################################################
  oozieDirSetup() {
    local oozie_dirs="$oozie_log_dir $oozie_pid_dir $oozie_db_dir"
    setupooziedir1="mkdir -p $oozie_dirs"
    setupooziedir2="chown -R ${oozieuser}:hadoop $oozie_dirs"
    setupooziedir3="chmod 755 -R $oozie_dirs"
    if [[ $installoozie == "yes" ]] ; then
      echo0 "Setting up various directories required by oozie"
      ssh2host "${oozieshost}" "$SUDOUSERPREFIX ${oozieuser} $SUDOCMDOPTION $setupooziedir1 ; \
      $SUDOUSERPREFIX ${oozieuser} $SUDOCMDOPTION $setupooziedir2 ; \
      $SUDOUSERPREFIX ${oozieuser} $SUDOCMDOPTION $setupooziedir3"
    fi
  }


  ############################################################
  #FUNCTION TO START ZOOKEEPER SERVER
  ############################################################
  startZk() {
    if [[ "$installzk" == "yes" ]] ; then
      echo0 "Starting Zookeeper Server"
      #startzkServer="${deploypath}/zookeeper/sbin/zkServer.sh start >> ${zk_log_dir}/zoo.out 2>&1"
      startzkServer="${deploypath}/zookeeper/sbin/zkServer.sh start"
      if [[ "$upgrade" != "yes" ]] ; then
        myid=1
        for i in $zkhosts
          do
            ssh2host "${i}" "ln -sf ${java32home} ${zkjavahome}; echo $myid | ( $SUDOUSERPREFIX ${zkuser} $SUDOCMDOPTION tee ${zk_data_dir}/myid ) >> /dev/null ; $SUDOUSERPREFIX ${zkuser} $SUDOCMDOPTION ${startzkServer}"
            ((myid++))
            sleep 30
        done
      fi
    fi
  }

  ############################################################
  #FUNCTION TO START HCAT SERVER
  ############################################################
  startHcat() {
    if [[ "$installhcat" == "yes" ]] ; then
      echo0 "Starting Hcatalog Server"
      starthcatserver="env HADOOP_HOME=${hadoophome} ${deploypath}/hcat/sbin/hcat_server.sh start"
      ssh2host "${gwhost}" "ln -fs ${java32home} ${hcatjavahome}; \
          $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -mkdir /user/${hcatuser} /apps/hive/warehouse; \
          $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -chown ${hcatuser}:users /apps/hive/warehouse ; \
          $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -chown ${hcatuser}:${hcatuser} /user/${hcatuser}; \
          $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -chmod -R 770  /apps/hive/warehouse "
      ssh2host "${hcshost}" "ln -fs ${java64home} ${hcatjavahome}; ${hadoopjdk64link}"
      ssh2host "${hcshost}" "$SUDOUSERPREFIX ${hcatuser} $SUDOCMDOPTION env HADOOP_HOME=${hadoophome} ${deploypath}/hcat/sbin/hcat_server.sh start"
    fi
  }

  ############################################################
  #FUNCTION TO START TEMPLETON SERVER
  ############################################################
  startTempleton() {
    if [[ "$installtempleton" == "yes" ]] ; then
      echo0 "Starting Templeton Server"
      templetonhost=`echo $ttonhosts | cut -f1 -d' '`
      scp2host $templetonhost "${artifactdownloaddir}/${hcattarname}" "${destdir}"
      scp2host $templetonhost "${artifactdownloaddir}/${pigtarname}" "${destdir}"

      ssh2host $templetonhost "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -mkdir /user/templeton; \
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -put  ${destdir}/${pigtarname} /user/templeton/ ; \
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -put  ${destdir}/${hcattarname} /user/templeton/ ; \
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -put  ${deploypath}/hadoop/contrib/streaming/hadoop-streaming*.jar /user/templeton/hadoop-streaming.jar ; \
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -put  ${deploypath}/templeton/templeton*jar /user/templeton/ugi.jar ; \
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -chown -R ${templetonuser} /user/templeton ; \
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -chmod -R 755 /user/templeton ; "


      #setup,start each templeton server
      for i in $ttonhosts
      do
        ssh2host "${i}" "ln -sf ${java32home} ${ttonjavahome}; \
           $SUDOUSERPREFIX ${templetonuser} $SUDOCMDOPTION \
               ${deploypath}/templeton/sbin/templeton_server.sh start "
      done
    fi
  }

  ############################################################
  #FUNCTION TO START OOZIE SERVER
  ############################################################
  startOozie() {
    if [[ "$installoozie" == "yes" ]] ; then
      echo0 "Starting Oozie Server"
      ssh2host "${gwhost}" "ln -fs ${java32home} ${ooziejavahome}; \
      $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -mkdir /user/${oozieuser}; \
      $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -chown ${oozieuser}:${oozieuser} /user/${oozieuser};"
      ssh2host "${oozieshost}" "ln -fs ${java64home} ${ooziejavahome}; ${hadoopjdk64link}"
      ssh2host "${oozieshost}" "$SUDOUSERPREFIX ${oozieuser} $SUDOCMDOPTION ${deploypath}/oozie/bin/oozie-setup.sh -hadoop 0.20.200 ${deploypath}/hadoop -extjs ${destdir}/${extjszipname}"
      ssh2host "${oozieshost}" "$SUDOUSERPREFIX ${oozieuser} $SUDOCMDOPTION ${deploypath}/oozie/bin/oozie-start.sh"
    fi
  }

  ############################################################
  #FUNCTION TO START HBASE SERVICES
  ############################################################
  startHbase() {
    if [[ "$installhbase" == "yes" ]] ; then
      echo0 "Starting Hbase Server"
      starthbasemaster="env HADOOP_HOME=${hadoophome} ${deploypath}/hbase/bin/hbase-daemon.sh --config ${deploypath}/hbase-conf start master"
      starthbasers="env HADOOP_HOME=${hadoophome} ${deploypath}/hbase/bin/hbase-daemon.sh --config ${deploypath}/hbase-conf start regionserver"
      ssh2host "${gwhost}" "ln -fs ${java64home} ${hbasejavahome}; ${hadoopjdk64link}; \
      $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -mkdir ${hbase_dfs_dir}; \
      $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -chown ${hbaseuser}:${hbaseuser} ${hbase_dfs_dir}"
      ssh2host "${hbmhost},$(echo $rshosts | tr " " "," )" "ln -fs ${java64home} ${hbasejavahome}"
      ssh2host "${hbmhost}" "$SUDOUSERPREFIX ${hbaseuser} $SUDOCMDOPTION ${starthbasemaster}"
      ssh2host "$(echo $rshosts | tr " " ",")" "$SUDOUSERPREFIX ${hbaseuser} $SUDOCMDOPTION ${starthbasers}"
    fi
  }

  ############################################################
  #FUNCTION TO START HADOOP SERVICES
  ############################################################
  startHadoop() {
    echo0 "Starting All Hadoop Services"
    formatnamenode="${hadoophome}/bin/hadoop \
      --config ${hadoopconfdir} namenode -format"
    upgradeflag=""
    if [[ "$upgrade" == "yes" ]]; then
      upgradeflag="-upgrade"
    fi
    startnamenode="${hadoophome}/bin/hadoop-daemon.sh \
      --config ${hadoopconfdir} start namenode ${upgradeflag}"
    startsnamenode="${hadoophome}/bin/hadoop-daemon.sh \
      --config ${hadoopconfdir} start secondarynamenode ${upgradeflag}"
    startdn="${hadoophome}/bin/hadoop-daemon.sh \
      --config ${hadoopconfdir} start datanode"
    startjt="${hadoophome}/bin/hadoop-daemon.sh \
      --config ${hadoopconfdir} start jobtracker"
    starttt="${hadoophome}/bin/hadoop-daemon.sh \
      --config ${hadoopconfdir} start tasktracker"
    starths="${hadoophome}/bin/hadoop-daemon.sh \
      --config ${hadoopconfdir} start historyserver"
    createdfsuserdir="${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -mkdir /user"
    setdfsuserdirperm="${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -chmod 755 /user"
    createdfstmpdir="${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -mkdir /tmp"
    createdfsdirs="${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -mkdir /mapred/system"
    setdfsperms="${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -chown ${mapreduser}:${mapreduser} /mapred /mapred/system"
    setdfstmpperm="${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -chmod 777 /tmp"
    if [[ "$upgrade" != "yes" ]] ; then
      ssh2host "${nnhost}" "${hadoopjdk64link}; yes Y | ( $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION $formatnamenode ) ; $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION $startnamenode"
      ssh2host "${snhost}" "${hadoopjdk64link}; $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION $startsnamenode"
      ssh2host "${hadoopslavenodes}" "${hadoopjdk32link}; $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${startdn}"
      ssh2host "${nnhost}" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${createdfsdirs} ; \
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${setdfsperms}; \
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${createdfstmpdir};\
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${setdfstmpperm};\
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${createdfsuserdir};\
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${setdfsuserdirperm}"
      ssh2host "${jthost}" "${hadoopjdk64link}; $SUDOUSERPREFIX ${mapreduser} $SUDOCMDOPTION ${startjt}; \
      $SUDOUSERPREFIX ${mapreduser} $SUDOCMDOPTION ${starths}"
      ssh2host "${hadoopslavenodes}" "${hadoopjdk32link}; $SUDOUSERPREFIX ${mapreduser} $SUDOCMDOPTION ${starttt}"
    else
      ssh2host "${nnhost}" "${hadoopjdk64link}; $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION $startnamenode "
      ssh2host "${snhost}" "${hadoopjdk64link}; $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION $startsnamenode "
      ssh2host "${hadoopslavenodes}" "${hadoopjdk32link}; $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${startdn}"
      # wait for nn to leave safemode
      hadoopnnwaitforsafemodeoff
      local ret=$?
      if [[ "$ret" != "0" ]]; then
        echo "Namenode ${nnhost} failed to come out of safemode"
        exit 1
      fi
      ssh2host "${jthost}" "${hadoopjdk64link}; $SUDOUSERPREFIX ${mapreduser} $SUDOCMDOPTION ${startjt} ; \
      $SUDOUSERPREFIX ${mapreduser} $SUDOCMDOPTION ${starths}"
      ssh2host "${hadoopslavenodes}" "${hadoopjdk32link}; $SUDOUSERPREFIX ${mapreduser} $SUDOCMDOPTION ${starttt}"
    fi
  }

  ############################################################
  #FUNCTION TO DEPLOY SNAPPY
  ############################################################
  deploySnappy() {
    if [ 'yes' != "$deploySnappy" ]; then
      return
    fi
    
    #THIS WILL NEED TO CHANGE ONCE WE HAVE SNAPPY FOR TAR
    return
  }

  ############################################################
  #FUNCTION TO DEPLOY HADOOP AND JDK
  ############################################################
  deployHadoop() {
    installJdk "$(echo $allhosts | tr " " ",")"
    installHadoop "$(echo $allhosts | tr " " ",")"
    installHadoopConfigs "$(echo $allhosts | tr " " ",")"
    installHadoopLzo "$(echo $allhosts | tr " " ",")"
  }

  ############################################################
  #FUNCTION TO DEPLOY ZOOKEEPER
  ############################################################
  deployZookeeper() {
    if [[ "$installzk" == "yes" ]] ; then
      local all_nodes="$(echo $zkhosts | tr " " ","),$gwhost"
      #add templeton nodes if templeton is being installed
      if [ 'yes' == "$installtempleton" ]; then
        all_nodes="${all_nodes},$(echo $ttonhosts | tr " " ",")"
      fi
      installZk "$all_nodes"
      installZkConfigs "$all_nodes"
    fi
  }

  ############################################################
  #FUNCTION TO DEPLOY HBASE
  ############################################################
  deployHbase() {
    if [[ "$installhbase" == "yes" ]] ; then
      installHbase "$(echo $hbmhost | tr " " ","),$(echo $rshosts | tr " " ","),$gwhost"
      installHbaseConfigs "$(echo $hbmhost | tr " " ","),$(echo $rshosts | tr " " ","), $gwhost"
    fi
  }

  ############################################################
  #FUNCTION TO DEPLOY HCAT
  ############################################################
  deployHcat() {
    if [[ "$installhcat" == "yes" ]] ; then
      installHcat "$(echo $hcshost | tr " " ",")"
      installHcatConfigs "$(echo $hcshost | tr " " ",")"
    fi
  }

  ############################################################
  #FUNCTION TO DEPLOY OOZIE
  ############################################################
  deployOozie() {
    if [[ "$installoozie" == "yes" ]] ; then
      installOozie "$(echo $oozieshost | tr " " ","),$gwhost"
      installOozieConfigs "$(echo $oozieshost | tr " " ","),$gwhost"
    fi
  }

 ############################################################
  #FUNCTION TO INSTALL PIG
  ############################################################
  deployPig() {
    if [[ "$installpig" == "yes" ]] ; then
      installPig "$gwhost"
      installPigConfigs "$gwhost"
    fi
  }

  ############################################################
  #FUNCTION TO INSTALL TEMPLETON
  ############################################################
  deployTempleton() {
    if [[ "$installtempleton" == "yes" ]] ; then
      installTempleton  "$(echo $ttonhosts | tr " " ",")"
      installTempletonConfigs  "$(echo $ttonhosts | tr " " ",")"
    fi
  }

  ############################################################
  #FUNCTION TO WAIT FOR NAMENODE TO COME OUT OF SAFEMODE
  ############################################################
  hadoopnnwaitforsafemodeoff(){
    echo0 "Waiting ${nnsafemodetimeout} seconds for namenode to come out of safe mode"
    wait_count=0
    safemodecmd="${hadoophome}/bin/hadoop \
      --config ${hadoopconfdir} \
      dfsadmin -safemode get"
    while (( "${wait_count}" < "${nnsafemodetimeout}" ))
    do
      sshgwfordfssafemode "\"$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION $safemodecmd\""
      ret=$?
      if [ "$ret" == "0" ]
      then
        return 0
      fi
      (( wait_count+=5 ))
      sleep 5s
    done
    echo "Namenode failed to come out of safe mode in ${nnsafemodetimeout} seconds"
    return 1
  }

  #########################################################
  #FUNCTION TO STOP ALL GRID STACK DAEMONS
  #########################################################
  killAllJava() {
    echo0 "Stop all Java Process"
    #ssh2host "${allhosts}" "ps -ef | grep [j]ava | awk '{ print \$2 }' | xargs $SUDOASROOT kill -9"
    echo0 "kill all java service started by $hdfsuser $mapreduser"
    host1=$(cat nodes gateway jobtracker namenode snamenode | sort | uniq )
    host1=$(echo $host1 | tr "\n" ",")
      ssh2host "${host1}" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ps -ef | grep [j]ava | awk '{ print \$2 }' | xargs kill -9  >> /dev/null 2>&1; \
        $SUDOUSERPREFIX ${mapreduser} $SUDOCMDOPTION ps -ef | grep [j]ava | awk '{ print \$2 }' | xargs kill -9  >> /dev/null 2>&1"
    if [[ "$installhbase" == "yes" ]] ; then
      echo0 "kill all java service started by $hbaseuser "
      host2=$(cat hbasemaster hbasenodes | sort | uniq )
      host2=$(echo $host2 | tr "\n" ",")
      ssh2host "$host2" "$SUDOUSERPREFIX ${hbaseuser} $SUDOCMDOPTION ps -ef | grep [j]ava | awk '{ print \$2 }' | xargs kill -9  >> /dev/null 2>&1"
      echo0 "kill all java service started by $zkuser "
      host3=$(cat zknodes | sort | uniq )
      host3=$(echo $host3 | tr "\n" ",")
      ssh2host "$host3" "$SUDOUSERPREFIX ${zkuser} $SUDOCMDOPTION ps -ef | grep [j]ava | awk '{ print \$2 }' | xargs kill -9  >> /dev/null 2>&1"
    fi
    if [[ "$installhcat" == "yes" ]] ; then
      echo0 "kill all java service started by $hcatuser "
      host4=$(cat hcatserver | sort | uniq )
      host4=$(echo $host4 | tr "\n" ",")
      ssh2host "$host4" "$SUDOUSERPREFIX ${hcatuser} $SUDOCMDOPTION ps -ef | grep [j]ava | awk '{ print \$2 }' | xargs kill -9  >> /dev/null 2>&1"
    fi
    if [[ "$installoozie" == "yes" ]] ; then
      echo0 "kill all java service started by $oozieuser "
      host4=$(cat oozieserver | sort | uniq )
      host4=$(echo $host4 | tr "\n" ",")
      ssh2host "$host4" "$SUDOUSERPREFIX ${oozieuser} $SUDOCMDOPTION ps -ef | grep [j]ava | awk '{ print \$2 }' | xargs kill -9  >> /dev/null 2>&1"
    fi
  }

  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON HADOOP
  ############################################################
  runHadoopSmokeTest() {
    echo0 "Hadoop smoke test - wordcount using /etc/passwd file"
    nnweburl="http://$nnhost:50070"
    jtweburl="http://$jthost:50030"
    jhweburl="http://$jthost:51111/jobhistoryhome.jsp"
    local outname=`date +"%M%d%y"`
    sshgwforsmoke "${hadoopjdk32link}; $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION \
      ${hadoophome}/bin/hadoop --config ${hadoopconfdir} fs -mkdir /user/${smoke_test_user}; \
      $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} \
       fs -chown ${smoke_test_user}:${smoke_test_user} /user/${smoke_test_user}"
    sshgwforsmoke "${hadoopjdk32link}; $SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION \
      ${hadoophome}/bin/hadoop --config ${hadoopconfdir} \
      fs -put /etc/passwd /user/${smoke_test_user}/passwd-${outname}"
    sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION ${hadoophome}/bin/hadoop \
      --config ${hadoopconfdir} jar ${hadoophome}/hadoop-examples-*.jar \
       wordcount /user/${smoke_test_user}/passwd-${outname} /user/${smoke_test_user}/${outname}.out"
    export HADOOP_EXIT_CODE=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION \
      ${hadoophome}/bin/hadoop --config ${hadoopconfdir} \
       fs -test -e /user/${smoke_test_user}/${outname}.out > /dev/null 2>&1; echo \\\$? " | sed 's/[ \r]//g'`
    if [[ "$HADOOP_EXIT_CODE" -ne "0" ]] ; then
      echo0 "Hadoop Smoke Test: Failed"
      exit 1 ;
    else
      echo0 "Hadoop Smoke Test: Passed"
    fi
    if [[ `checkurl "$nnweburl"` -eq 0 ]] ; then echo0 "NameNode web $nnweburl accessible";
      else echo0 "NameNode web $nnweburl not accessible"; fi
    if [[ `checkurl "$jtweburl"` -eq 0 ]] ; then echo0 "Jobtracker web $jtweburl accessible";
      else echo0 "Jobtracker web $jtweburl not accessible"; fi
    if [[ `checkurl "$jhweburl"` -eq 0 ]] ; then echo0 "Jobhistory web $jhweburl accessible";
      else echo0 "Jobhistory web $jhweburl not accessible"; fi
  }
  
  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON OOZIE
  ############################################################
  checkOozieJobStatus() {
    local job_id=$1
    local num_of_tries=$2
    #default num_of_tries to 10 if not present
    num_of_tries=${num_of_tries:-10}
    local i=0
    local rc=1
    local oozie_home="${installdir}/oozie"
    local cmd="$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION env JAVA_HOME=${ooziejavahome} ${oozie_home}/bin/oozie job --oozie http://${oozieshost}:11000/oozie -info $job_id | grep '^Status'"
    while [ $i -lt $num_of_tries ]
    do
      cmd_output=`ssh2hostwithreturnvalue "$gwhost" "$cmd" | sed 's/[ \r]//g'`
      act_status="`echo $cmd_output | cut -d':' -f2`"
      if [ "RUNNING" == "$act_status" ]; then
       #increment the couner and get the status again after waiting for 15 secs
       sleep 15
       (( i++ )) 
      elif [ "SUCCEEDED" == "$act_status" ]; then
        rc=0;
        break;
      else
        rc=1
        break;
      fi
    done
    return $rc
  }

  runOozieSmokeTest() {
    if [[ "$installoozie" == "yes" ]] ; then
      local oozie_home="${installdir}/oozie"
      JOB_SCRIPTS_DIR_NAME=${destdir}/oozie-examples
      JT=${jthost}:50300
      FS=hdfs://${nnhost}:8020
      echo0 "Initiate oozie smoke tests 1"
      ssh2host $gwhost "mkdir -p $JOB_SCRIPTS_DIR_NAME; \
      cd $JOB_SCRIPTS_DIR_NAME; \
      tar -zxf ${oozie_home}/oozie-examples.tar.gz; \
      sed -i 's|nameNode=hdfs://localhost:8020|nameNode=$FS|g'  examples/apps/map-reduce/job.properties; \
      sed -i 's|nameNode=hdfs://localhost:9000|nameNode=$FS|g'  examples/apps/map-reduce/job.properties; \
      sed -i 's|jobTracker=localhost:8021|jobTracker=$JT|g' examples/apps/map-reduce/job.properties; \
      sed -i 's|jobTracker=localhost:9001|jobTracker=$JT|g' examples/apps/map-reduce/job.properties; \
      sed -i 's|oozie.wf.application.path=hdfs://localhost:9000|oozie.wf.application.path=$FS|g' examples/apps/map-reduce/job.properties"
      ssh2host $gwhost "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION ${hadoophome}/bin/hadoop dfs -put ${JOB_SCRIPTS_DIR_NAME}/examples examples"
      ssh2host $gwhost "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION ${hadoophome}/bin/hadoop dfs -put ${JOB_SCRIPTS_DIR_NAME}/examples/input-data input-data"
      local cmd="env JAVA_HOME=${ooziejavahome} ${oozie_home}/bin/oozie job -oozie http://$oozieshost:11000/oozie -config $JOB_SCRIPTS_DIR_NAME/examples/apps/map-reduce/job.properties  -run"
      if [ 'yes' == "$security" ]; then
        cmd="$kinitcmd_smoke_test_user $cmd"
      fi
      local job_info=`ssh2hostwithreturnvalue $gwhost "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION $cmd" | sed 's/[ \r]//g'`
      local job_id="`echo $job_info | cut -d':' -f2`"
      checkOozieJobStatus "$job_id"
      OOZIE_EXIT_CODE="$?"
      #Oozie
      displaySmokeTestResult "Oozie" "$OOZIE_EXIT_CODE"
    fi
  }
 
  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON HCAT
  ############################################################
  runHcatSmokeTest() {
  if [[ "$installhcat" == "yes" ]] ; then
    hcathome="${installdir}/hcat"
    echo0 "Initiate hcat smoke tests - show tables, create table, and drop table"
    echo "export HADOOP_HOME=${hadoophome}" > ${artifactdownloaddir}/hcatsmoke.sh
    echo "${hcathome}/bin/hcat -e 'show tables'" >> ${artifactdownloaddir}/hcatsmoke.sh
    echo "${hcathome}/bin/hcat -e 'drop table IF EXISTS hcatsmoke$$;'" >> ${artifactdownloaddir}/hcatsmoke.sh
    echo "${hcathome}/bin/hcat -e 'create table hcatsmoke$$ \
      ( id INT, name string ) stored as rcfile ;'" >> ${artifactdownloaddir}/hcatsmoke.sh
    [[ -f ${artifactdownloaddir}/hcatsmoke.sh ]] && chmod 755 ${artifactdownloaddir}/hcatsmoke.sh
    scp2host "${gwhost}" "${artifactdownloaddir}/hcatsmoke.sh" "${destdir}/hcatsmoke.sh"
    sshgwforsmoke "$SUDOUSERPREFIX ${hcatuser} $SUDOCMDOPTION ${destdir}/hcatsmoke.sh"
    export HCAT_EXIT_CODE=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${hcatuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} \
      fs -test -e /apps/hive/warehouse/hcatsmoke$$ > /dev/null 2>&1; echo \\\$?" | sed 's/[ \r]//g'`
    if [[ "$HCAT_EXIT_CODE" -ne "0" ]] ; then  echo0 "Hcat Smoke Test: Failed" ; \
      return 1 ; else echo0 "Hcat Smoke Test: Passed " ; fi
  fi
  }
  
  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON SQOOP
  ############################################################
  runSqoopSmokeTest() {
    #only run sqoop tests if sqoop is installed
    if [ "yes" != "$installsqoop" ]; then
      return 0
    fi

    echo0 "Sqoop smoke test - version"
    sqoop_smoke_cmd="${installdir}/sqoop/bin/sqoop version | grep 'Sqoop [0-9].*'"
    local cmd
    if [ 'yes' == "$security" ]; then
      cmd="$kinitcmd_smoke_test_user $sqoop_smoke_cmd"
    else
      cmd=$sqoop_smoke_cmd
    fi
    ssh2host "$gwhost" "$cmd"
    SQOOP_EXIT_CODE="$?" 
    #Sqoop
    displaySmokeTestResult "Sqoop" "$SQOOP_EXIT_CODE"
  }

  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON TEMPLETON
  ############################################################
  runTempletonSmokeTest() {
  if [[ "$installtempleton" == "yes" ]] ; then
      echo0 "Running templeton smoke tests"
      ttonhost=`echo $ttonhosts | cut -f1 -d ' '`
      ttonhost="${ttonhost%\\n}"
      ttonurl="http://${ttonhost}:50111/templeton/v1"

      export TEMPLETON_EXIT_CODE=0;

      #test status cmd
      local retVal=`ssh2hostwithreturnvalue $gwhost  "$SUDOUSERPREFIX  ${smoke_test_user} $SUDOCMDOPTION \
       curl -s -w %{http_code} -o /dev/null $ttonurl/status"`

      if [[ "$retVal" -ne "200" ]]; then  
          echo0 "Templeton Smoke Test (status cmd): Failed. : $retVal" 
          export TEMPLETON_EXIT_CODE=1
          return 1
      fi

      #try hcat ddl command
      echo "user.name=${smoke_test_user}&exec=show databases;" > ${artifactdownloaddir}/show_db.post.txt
      scp2host  "${gwhost}" "${artifactdownloaddir}/show_db.post.txt" "${destdir}"

      local retVal=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION \
       curl -s -w %{http_code} -o /dev/null -d \@${destdir}/show_db.post.txt $ttonurl/ddl"`

      if [[ "$retVal" -ne "200" ]]; then  
          echo0 "Templeton Smoke Test (ddl cmd): Failed. : $retVal" 
          export TEMPLETON_EXIT_CODE=1
          return 1
      fi
      
      #      #try pig query
      #      #create pig query first
      local outname=${smoke_test_user}.`date +"%M%d%y"`.$$;
      local ttonTestOutput="/tmp/idtest.${outname}.out";
      local ttonTestInput="/tmp/idtest.${outname}.in";
      local ttonTestScript="idtest.${outname}.pig"
      echo "A = load '$ttonTestInput' using PigStorage(':');"  > ${artifactdownloaddir}/$ttonTestScript
      echo "B = foreach A generate \$0 as id; " >> ${artifactdownloaddir}/$ttonTestScript
      echo "store B into '$ttonTestOutput';" >> ${artifactdownloaddir}/$ttonTestScript
      scp2host  "${gwhost}" "${artifactdownloaddir}/$ttonTestScript" "${destdir}/$ttonTestScript"
      #copy pig script to hdfs
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION ${hadoophome}/bin/hadoop dfs  -put ${destdir}/$ttonTestScript /tmp/$ttonTestScript"
      #copy input file to hdfs
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION ${hadoophome}/bin/hadoop dfs -put /etc/passwd $ttonTestInput"

      local tuser=${smoke_test_user}

      #create, copy post args file
      echo -n "user.name=${tuser}&file=/tmp/$ttonTestScript" > \
      ${artifactdownloaddir}/pig_post.txt
      scp2host  "${gwhost}" "${artifactdownloaddir}/pig_post.txt" "${destdir}"

      #submit pig query
      local retVal=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION \
       curl -s -w %{http_code} -o /dev/null -d \@${destdir}/pig_post.txt $ttonurl/pig"`

      if [[ "$retVal" -ne "200" ]]; then  
          echo0 "Templeton Smoke Test (pig cmd): Failed. : $retVal" 
          export TEMPLETON_EXIT_CODE=1
          return 1
      fi
      echo0 "Templeton Smoke Test: Passed" 
  fi
  }

  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON HIVE
  ############################################################
  runHiveSmokeTest() {
    if [ "$installhcat" == "yes" ] ; then
      hcathome="${installdir}/hcat"
      echo0 "Hive smoke test - create table and drop table"
      echo "export \"HADOOP_HOME=${hadoophome}\"" > ${artifactdownloaddir}/hivesmoke.sh
      echo "echo \"CREATE EXTERNAL TABLE IF NOT EXISTS hivesmoke$$ ( foo INT, bar STRING );\" \
       | ${hcathome}/bin/hive" >> ${artifactdownloaddir}/hivesmoke.sh
      echo "echo \"DESCRIBE hivesmoke$$;\" | ${hcathome}/bin/hive" >> ${artifactdownloaddir}/hivesmoke.sh
      [[ -f ${artifactdownloaddir}/hivesmoke.sh ]] && chmod 755 ${artifactdownloaddir}/hivesmoke.sh
      scp2host "${gwhost}" "${artifactdownloaddir}/hivesmoke.sh" "${destdir}/hivesmoke.sh"
      sshgwforsmoke "$SUDOUSERPREFIX ${hcatuser} $SUDOCMDOPTION sh ${destdir}/hivesmoke.sh"
      export HIVE_EXIT_CODE=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${hcatuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} \
      fs -test -e /apps/hive/warehouse/hivesmoke$$ > /dev/null 2>&1; echo \\\$?" | sed 's/[ \r]//g'`
    if [[ "$HIVE_EXIT_CODE" -ne "0" ]] ; then echo ; echo0 "Hive Smoke Test: Failed" ; \
      return 1 ; else echo0 "Hive Smoke Test: Passed " ; fi
    fi
  }

  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON PIG
  ############################################################
  runPigSmokeTest() {
    if [ $installpig == "yes" ] ; then
      echo0 "Pig smoke test - wordcount using /etc/passwd file"
      cat > ${artifactdownloaddir}/pigsmoke.sh <<PIGSMOKE
      A = load 'passwd' using PigStorage(':');
      B = foreach A generate \$0 as id;
      store B into 'pigsmoke.out';
PIGSMOKE
      scp2host "${gwhost}" "${artifactdownloaddir}/pigsmoke.sh" "${destdir}/pigsmoke.sh"
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION ${hadoophome}/bin/hadoop fs -rmr passwd pigsmoke.out"
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION ${hadoophome}/bin/hadoop fs -put /etc/passwd passwd"
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION ${deploypath}/pig/bin/pig ${destdir}/pigsmoke.sh"
      export PIG_EXIT_CODE=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} \
      fs -test -e pigsmoke.out > /dev/null 2>&1; echo \\\$?" | sed 's/[ \r]//g'`
      if [[ "$PIG_EXIT_CODE" -ne "0" ]] ; then  echo0 "Pig Smoke Test: Failed" ; \
        return 1 ; else echo0 "Pig Smoke Test: Passed" ; fi
    fi
  }

  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON HBASE
  ############################################################
  runHbaseSmokeTest() {
    if [ "$installhbase" == "yes" ] ; then
      hbasehome="${deploypath}/hbase"
      local hbaseweburl="http://$hbmhost:60010/master-status"
      echo0 "Hbase smoke test - check status, disable, drop , create\
       describe, disable and enable table"
      local outname=`date +"%M%d%y"`
      cat > ${artifactdownloaddir}/hbasesmoke.sh <<HBASESMOKE
      status
      disable 'hbasesmoke'
      drop 'hbasesmoke'
      create 'hbasesmoke', {NAME => 'f1', VERSIONS => 5}
      describe 'hbasesmoke'
      disable 'hbasesmoke'
      enable 'hbasesmoke'
      exit
HBASESMOKE
      scp2host "${gwhost}" "${artifactdownloaddir}/hbasesmoke.sh" "${destdir}/hbasesmoke.sh"

      output=`sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION ${hbasehome}/bin/hbase shell ${destdir}/hbasesmoke.sh"`
      (IFS='';echo $output)
      tmpOutput=$(echo $output | grep -v '^0 servers')
      HBASE_SMOKE_EXIT_CODE=$?
      ((HBASE_EXIT_CODE=$HBASE_EXIT_CODE+$HBASE_SMOKE_EXIT_CODE))
      export HBASE_SMOKE_EXIT_CODE=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${hbaseuser} $SUDOCMDOPTION ${hadoophome}/bin/hadoop --config ${hadoopconfdir} \
      fs -test -e ${hbase_dfs_dir}/hbasesmoke > /dev/null 2>&1; echo \\\$?" | sed 's/[ \r]//g'`
      ((HBASE_EXIT_CODE=$HBASE_EXIT_CODE+$HBASE_SMOKE_EXIT_CODE))
      if [[ "$HBASE_EXIT_CODE" -ne "0" ]] ; then  echo0 "Hbase Smoke Test: Failed" ; \
        return 1 ; else echo0 "Hbase Smoke Test: Passed " ; fi
      if [[ `checkurl "$hbaseweburl"` -eq 0 ]] ; then echo0 "Hbase Master url $hbaseweburl accessible";
        else echo0 "Hbase Master url $hbaseweburl not accessible"; fi
    fi
  }

  ############################################################
  # FUNCTION TO INITIATE SMOKE TEST ON ZOOKEEPER
  ############################################################
  runZkSmokeTest() {
    if [ "$installzk" == "yes" ] ; then
      export ZOOKEEPER_EXIT_CODE=0
      zkhome="${deploypath}/zookeeper"
      echo0 "Zookeeper smoke test - create root znode and verify data consistency across the quorum"
      zk_node1=`echo $zkhosts | tr ' ' '\n' | head -1`
      # Delete /zk_smoketest znode if exists
      sshgwforsmoke "$zkjdk32link ; $SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION echo delete /zk_smoketest | $zkhome/bin/zkCli.sh -server $zk_node1:2181 "
      # Create /zk_smoketest znode on one zookeeper server
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION echo create /zk_smoketest smoke_data | $zkhome/bin/zkCli.sh -server $zk_node1:2181 "

      for i in $zkhosts ; do
        # Verify the data associated with znode across all the nodes in the zookeeper quorum
        output=$(ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION echo get /zk_smoketest | $zkhome/bin/zkCli.sh -server $i:2181")
        echo $output | grep smoke_data 2>&1
        if [[ $? -ne 0 ]] ; then  echo "Data associated with znode /zk_smoketests is not consistent on host $i"
          ((ZOOKEEPER_EXIT_CODE=$ZOOKEEPER_EXIT_CODE+1))
        fi
      done
      ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION echo delete /zk_smoketest | $zkhome/bin/zkCli.sh -server $zk_node1:2181"
      if [[ "$ZOOKEEPER_EXIT_CODE" -ne "0" ]] ; then  echo0 "Zookeeper Smoke Test: Failed" ; exit 1 ;
        else echo0 "Zookeeper Smoke Test: Passed" ; fi
    fi
  }
