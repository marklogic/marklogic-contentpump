#! /bin/bash
#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

  clear
  basedir=`pwd`
  source ${basedir}/gsInstaller.properties
  source ${basedir}/gsCluster.properties
  source ${basedir}/gsLib.sh
  source ${basedir}/gsConfigLib.sh
  
  #set install dependencies like snappy, zookeeper etc
  setInstallDependencies

  echo0 "Grid Stack Smoke Tests"
  echo
  echo0 "Cluster Details"

  [ -f $outlog ] && rm -f $outlog
  [ -d $artifactdownloaddir ] && rm -rf $artifactdownloaddir ; mkdir -p $artifactdownloaddir

  if [[ `validatefalse $security` == "yes" ]]; then
    if [[ "$realm" != "" && "${hdfs_user_keytab}" != "" \
     && "${smoke_test_user_keytab}" != "" ]] ; then
      enablesecurity=yes
      kinitcmd="${kinitpath} -kt ${hdfs_user_keytab} ${hdfsuser};"
      kinitcmd_smoke_test_user="${kinitpath} -kt ${smoke_test_user_keytab} ${smoke_test_user};"
    else
      echo "Error: Security set to enabled but one of \"realm\", \
\"hdfs_user_keytab\" or \"smoke_test_user_keytab\" not defined "
      exit
    fi
  else
     enablesecurity=no
  fi

  [ `validate $installpig` == "yes" ] && installpig=yes
  [ `validate $installhbase` == "yes" ] && installhbase=yes
  [ `validate $installhcat` == "yes" ] && installhcat=yes
  [ `validate $enablemon` == "yes" ] && enablemon=yes
  [ `validatefalse $upgrade` == "yes" ] && upgrade=yes
  [[ -z "$hdfsuser" ]] && echo "Enter a valid hdfsuser" && exit
  [[ -z "$mapreduser" ]]  && echo "Enter a valid mapreduser" && exit
  [[ -z "$smoke_test_user" ]]  && echo "Enter a valid smoke_test_user" && exit
  [[ "$installhbase" == "yes" && "$hbaseuser" == "" ]] && echo "Enter a valid hbaseuser" && exit
  [[ "$installhbase" == "yes" && "$zkuser" == "" ]] && echo "Enter a valid zkuser" && exit
  [[ "$installhive" == "yes" && "$hiveuser" == "" ]] && echo "Enter a valid hiveuser" && exit
  [[ "$installtempleton" == "yes" && "$templetonuser" == "" ]] && echo "Enter a valid templeton user" && exit
  [[ "$installhive" == "yes" && "$mysqldbhost" == "" ]] && echo "Enter a valid mysql host" && exit

  [ "$nnhost" == "" ] && echo "Enter a valid Namenodehost" && exit
  [ "$gwhost" == "" ] && echo "Enter a valid Gatewayhost" && exit
  [ "$snhost" == "" ] && echo "Enter a valid Secondary Namenode host" && exit
  [ "$jthost" == "" ] && echo "Enter a valid Jobtracker" && exit
  [ "$slaves" == "" ] && echo "Enter a valid Slaves hostname list" && exit
  [[ "$hivehost" == "" && "$installhive" == "yes" ]] && echo "Enter a valid hostname for hivemetastore" && exit
  [[ "$hbmhost" == "" || "$rshosts" == "" || "$zkhosts" == "" ]] && [[ "$installhbase" == "yes" ]]  && \
    echo "Enter a valid hostname for hbasemaster, regionserver, zookeeper" && exit
  if [[ "$nnsafemodetimeout" == "" ]]; then
    nnsafemodetimeout=600
  fi

  [[ "$enablemon" == "yes" && "$gangliahost" == "" ]] && echo "Enter a valid ganglia host" && exit
  if [[ "${user_configs}" != "" ]]; then
    validateuserconfigs ${user_configs}
    usercfgret=$?
    if [[ "$usercfgret" != "0" ]]; then
      echo "Invalid configs provided in ${user_configs}"
      exit 1
    fi
    confRoot=${user_configs}
    echo "Using configs provided from ${confRoot}" | tee -a $outlog
  else
    if [[ "$upgrade" == "yes" ]]; then
      validateuserconfigs ${confRoot}
      usercfgret=$?
      if [[ "$usercfgret" != "0" ]]; then
        echo "Invalid configs provided in ${confRoot}" | tee -a $outlog
        exit 1
      fi
    fi
  fi

  case "$package" in
    rpm|RPM)
      installpkg=rpm
      source ${basedir}/rpmInstaller.sh
      ;;
    deb|DEB|Deb)
      installpkg=deb
      source ${basedir}/debInstaller.sh
      ;;
    tar|TAR|Tar)
      installpkg=tar
      hadoopconfdir="${deploypath}/hadoop-conf"
      hcatconfdir="${deploypath}/hcat-conf"
      zkconfdir="${deploypath}/zk-conf"
      hbaseconfdir="${deploypath}/hbase-conf"
      if [[ -z "$java64home" ]] ; then
         installjava="true"
         java64home="${installdir}/jdk64/jdk1.6.0_26"
      fi
      source ${basedir}/tarInstaller.sh
      [[ -z "$installdir" ]] && echo "Specify the installdir for the tarball installation" && exit
      ;;
     *)
       echo "Please provide the package type you want to install rpm | deb | tar"
      ;;
  esac

  displayselection
  clusterdetails
  echo0 "check your Install logs at : $outlog "
  mkdir -p $artifactdownloaddir
  runHadoopSmokeTest
  runPigSmokeTest
  runOozieSmokeTest
  runHcatSmokeTest
  runHiveSmokeTest
  runZkSmokeTest
  runHbaseSmokeTest
  runSqoopSmokeTest
  runTempletonSmokeTest
  displaySmokeTestSummary | tee -a $outlog
