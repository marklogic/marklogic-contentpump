#! /bin/bash
#
# monrpmInstaller.sh - RPM specific code for monInstaller

#/**
##* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

####################################################
# MONITORING VARIABLES  
#
mon_config_dir="${confRoot}/nagios-conf"

# Set the monitor_config_only option to no until we fix it 
if [ -z $monitor_config_only ]; then monitor_config_only=no; fi

# Handy constant used while installing and uninstalling Ganglia.
GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR="/usr/libexec/hdp/ganglia";
####################################################


############################################################
# FUNCTION TO INSTALL WGET
############################################################
installwget() {
        if [[ "$monitor_config_only" != "yes" ]]; then
                echo0 "Installing wget"
                monsshall "$installpkgcmd wget"
        fi
}

# Download the GPL Licensed Nagios plugins and config files
# Sets the mon_config_dir var as a side effect
install_monitor_config() {
        if [[  "$installsnmp" == "yes"          \
            || "$installnagios" == "yes"        \
            || "$installganglia" == "yes" ]] ; then
                mkdir -p "$mon_config_dir"
                cp -R ${basedir}/confSupport/templates/nagios-conf/* $mon_config_dir
        fi
}

############################################################
# FUNCTION TO INSTALL SNMP RPM 
############################################################
installnetsnmp() {
  if [[ "$installsnmp" == "yes" ]] ; then
    echo0 "Installing net-snmp"
    deployNetSnmpRpms
    deployNetSnmpConfigs
  fi
}

deployNetSnmpConfigs() {
  echo0 "Installing Net SNMP Configs"
  sed  "s/CLUSTERCOMMUNITY/$snmpcommunity/" \
      "$mon_config_dir/snmpd.conf-BASELINE" \
      > snmpd.conf
  sed -i -e "s/SNMPSOURCE/$snmpsource/" snmpd.conf
  monscpall "snmpd.conf" "/etc/snmp/snmpd.conf"
}


############################################################
# FUNCTION TO SET GANGLIA UP ON ALL BOXES
############################################################
installganglia() {
  if [[ "$installganglia" == "yes" ]] ; then
    echo0 "Installing ganglia";
    deployGangliaRpms
    deployGangliaConfigs
  fi
}

deployGangliaRpms() {
  if [[ "$monitor_config_only" != "yes" ]]; then
    echo0 "Installing Ganglia RPMs"
    # Client software install.
    sshgangliaclients "$installpkgcmd ganglia-gmond-3.2.0-99";
    # Server software install.
    sshgangliaserver "$installpkgcmd ganglia-gmond-3.2.0-99 ganglia-gmetad-3.2.0-99 rrdtool-1.4.5";
    xssh $gangliaweb "$installpkgcmd gweb-2.2.0-99";
  fi

  # Also, install the gweb addons that come with HDP.
  echo0 "Install GWeb AddOns"
  xssh $gangliaweb "$installpkgcmd hdp_mon_ganglia_addons";
  ensureJson ${gangliaweb}
}

deployGangliaConfigs() {
  echo0 "Installing Ganglia Configs"
  ganglia_runtime_components_dir="${confRoot}/ganglia";

  # Instantiate the necessary config templates into
  # ${ganglia_runtime_components_dir} for use in the next few steps.
  gangliaconfgen "${ganglia_runtime_components_dir}";

  # Bundle up all the Ganglia-related runtime components required on every box.
  tar czf "${artifactdownloaddir}/ganglia-runtime-components.tar.gz" -C `dirname ${ganglia_runtime_components_dir}` \
    `basename ${ganglia_runtime_components_dir}`;
  # Copy this bundle in to ${destdir} on every box.
  monscpall "${artifactdownloaddir}/ganglia-runtime-components.tar.gz" "${destdir}";
  # And unpack all its components into their correct final destinations.
  ganglia_runtime_components_install_cmd="rm -rf ${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}; \
    mkdir -p ${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}; \
    chmod a+x -R ${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}; \
    tar xzf ${destdir}/ganglia-runtime-components.tar.gz -C `dirname ${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}`; \
    cp ${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/gmond.init /etc/init.d/hdp-gmond";
  monsshall "${ganglia_runtime_components_install_cmd}";
  # Additionaly, ${gangliaserver} needs the hdp-gmetad service installed as well.
  sshgangliaserver "cp ${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/gmetad.init /etc/init.d/hdp-gmetad";


################################################################################
# Comment this block out till we find it's actually needed (in an ideal 
# world, this would be configurable at runtime).
################################################################################
#
#    # Additionally, perform a fixup that moves all the PHP graph definitions
#    # provided by gweb out of the way (the PHP ones take precedence over the
#    # JSON definitions if both exist) to avoid mysterious rrdtool failures
#    # (the PHP definitions are implemented in terms of raw RRDTOOL 
#    # instructions).
#    #
#    # The antidote is in gsUninstaller.sh, so remember to update them as a pair.   
#    xssh $gangliaweb "find /var/www/html/ganglia/graph.d -name '*_report.php' -type f -print0 | \
#      xargs -0 -I FILE mv FILE FILE.MOVED_BY_HDP";
#
################################################################################

  # Generate and install the actual Ganglia Cluster configs contextually on each category of host.

  # 1) The gmond emitters.
  sshhbm "${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/setupGanglia.sh -c HDPHBaseMaster";
  sshjt "${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/setupGanglia.sh -c HDPJobTracker";
  sshnn "${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/setupGanglia.sh -c HDPNameNode";
  sshsn "${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/setupGanglia.sh -c HDPNameNode";
  sshnodes "${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/setupGanglia.sh -c HDPSlaves";
  sshrsnodes "${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/setupGanglia.sh -c HDPSlaves";

  # 2) The gmond collector.
  sshgangliaserver \
    "${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/setupGanglia.sh -c HDPHBaseMaster -m ; \
     ${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/setupGanglia.sh -c HDPJobTracker -m ; \
     ${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/setupGanglia.sh -c HDPNameNode -m ; \
     ${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/setupGanglia.sh -c HDPSlaves -m ;";

  # 3) gmetad for the entire Grid.
  sshgangliaserver "${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/setupGanglia.sh -t" ;
}

############################################################
# FUNCTION TO START SNMP 
############################################################
startnetsnmp() {
        if [[ "$installsnmp" == "yes" ]] ; then
                echo0 "Starting net-snmp"
                monsshall "/etc/init.d/snmpd restart"
        fi
}
############################################################
# FUNCTION TO START NAGIOS 
############################################################
startnagios() {
        if [[ "$installnagios" == "yes" ]] ; then
                echo0 "Starting nagios"
                # In some cases, user nagios gets removed on an uninstall
                # creating problems when re-installing nagios due to file
                # permissions issues
                if [ "${SYSTEM_OS}" == "${OS_CENTOS}" ]; then
                  sshnagios "chown -R nagios:nagios /var/nagios;"
                fi
                if [ "${SYSTEM_OS}" == "${OS_SLES}" ]; then
                  sshnagios "chown -R nagios:nagios /var/lib/nagios;"
                  sshnagios "chown nagios:nagcmd /var/lib/nagios/retention.dat;"
                fi
                sshnagios "/etc/init.d/nagios restart"
                if [ "${SYSTEM_OS}" == "${OS_SLES}" ]; then
                  sshnagios "chown nagios:nagcmd /var/spool/nagios/nagios.cmd;"
                fi
                sshnagios "$HTTPD_CMD restart"
        fi
}
############################################################
# FUNCTION TO START GANGLIA 
############################################################
startganglia() {
        if [[ "$installganglia" == "yes" ]] ; then
                echo0 "Starting ganglia"
                monsshall "/etc/init.d/hdp-gmond restart"
                sshgangliaserver "/etc/init.d/hdp-gmetad restart"
                xssh $gangliaweb "$HTTPD_CMD restart"
        fi
}
############################################################
# FUNCTION TO STOP SNMP 
############################################################
stopnetsnmp() {
        if [[ "$installsnmp" == "yes" ]] ; then
                echo0 "Stopping net-snmp"
                monsshall "/etc/init.d/snmpd stop"
        fi
}
############################################################
# FUNCTION TO STOP NAGIOS 
############################################################
stopnagios() {
        if [[ "$installnagios" == "yes" ]] ; then
                echo0 "Stoping nagios"
                sshnagios "/etc/init.d/nagios stop"
        fi
}
############################################################
# FUNCTION TO STOP GANGLIA 
############################################################
stopganglia() {
        if [[ "$installganglia" == "yes" ]] ; then
                echo0 "Stopping ganglia"
                xssh $gangliaweb "$HTTPD_CMD stop"
                sshgangliaserver "/etc/init.d/hdp-gmetad stop"
                monsshall "/etc/init.d/hdp-gmond stop"
        fi
}

# Return the status of a simple init.d service status check
report_initd_service_status() {
        local host=$1
        local service=$2

        local status=`xssh_tee $host /etc/init.d/$service status \
                | grep "running"`
        if [[ -n "$status" ]]; then
                log0 "$host $service OK"
        else
                log0 "$host $service FAIL"
        fi
}

# Inspired by report_initd_service_status(), but specialized for the 
# Ganglia family of services. 
report_initd_ganglia_service_status() {
  local host=${1};
  local service=${2};

  # Check that this function is indeed being invoked on a known 
  # Ganglia-related service. 
  case ${service} in
    "hdp-gmond")
      ;;
    "hdp-gmetad")  
      ;;
    *)
      log0 "WARNING: report_initd_ganglia_service_status() invoked on a non-Ganglia service";
      return;
      ;;
  esac

  # And this is why we're a special snowflake - we consider Ganglia to be
  # healthy on a box as long as there are no explicit reports of failure. 
  # 
  # This helps take care of the case where we invoke this check on a host 
  # that may not even have any of our Ganglia configuration set up - our 
  # actual init.d status check is smart enough to handle that (it'll just  
  # print nothing), so why should we need to perform any sort of filtering 
  # at this higher level of invocation?   
  local status=`xssh_tee $host /etc/init.d/$service status \
    | grep -i "failed"`;

  if [[ -z "$status" ]]; then
    log0 "$host $service OK";
  else
    log0 "$host $service FAIL";
  fi
}

###################################################################
# FUNCTION TO VERIFY GANGLIA RUNNING  ALL HOSTS 
###################################################################
pingganglia() {
        for host in $(echo $montargets); do
                report_initd_ganglia_service_status "$host" "hdp-gmond"
        done
        report_initd_ganglia_service_status "$gangliahost" "hdp-gmond"
        report_initd_ganglia_service_status "$gangliahost" "hdp-gmetad"
        if [[ "${SYSTEM_OS}" == "${OS_SLES}" ]]; then
          report_initd_service_status "$gangliaweb" "apache2"
        else
          report_initd_service_status "$gangliaweb" "httpd"
        fi
}

###################################################################
# FUNCTION TO VERIFY NAGIOS RUNNING  ALL HOSTS 
###################################################################
pingnagios() {
        report_initd_service_status "$nagioshost" "nagios"
        if [[ "${SYSTEM_OS}" == "${OS_SLES}" ]]; then
          report_initd_service_status "$nagioshost" "apache2"
        else
          report_initd_service_status "$nagioshost" "httpd"
        fi
}

############################################################
# FUNCTION TO INSTALL NAGIOS SERVER RPM 
############################################################
installnagios() {
  if [[ "$installnagios" == "yes" ]] ; then
    echo0 "Installing nagios server"
    deployNagiosRpms
    deployNagiosConfigs
  fi
}

deployNagiosConfigs() {
  echo0 "Install Nagios Configs"
  nagios_cfg=/etc/nagios/nagios.cfg
  nagios_commands=/etc/nagios/objects/hadoop-commands.cfg
  nagios_contacts_cfg=/etc/nagios/objects/contacts.cfg
  nagios_hosts_cfg=/etc/nagios/objects/hadoop-hosts.cfg
  nagios_services_cfg=/etc/nagios/objects/hadoop-services.cfg
  nagios_servicegroups_cfg=/etc/nagios/objects/hadoop-servicegroups.cfg
  nagios_hostgroups_cfg=/etc/nagios/objects/hadoop-hostgroups.cfg
  nagios_resource_cfg=/etc/nagios/resource.cfg

  scp2nagios "${basedir}/nagios/check_aggregate.php" "/usr/lib64/nagios/plugins/"
  scp2nagios "${basedir}/nagios/check_cpu.pl" "/usr/lib64/nagios/plugins/"
  scp2nagios "${basedir}/nagios/check_datanode_storage.php" "/usr/lib64/nagios/plugins/"
  scp2nagios "${basedir}/nagios/check_hdfs_blocks.php" "/usr/lib64/nagios/plugins/"
  scp2nagios "${basedir}/nagios/check_hdfs_capacity.php" "/usr/lib64/nagios/plugins/"
  scp2nagios "${basedir}/nagios/check_hive_metastore_status.sh" "/usr/lib64/nagios/plugins/"
  scp2nagios "${basedir}/nagios/check_name_dir_status.php" "/usr/lib64/nagios/plugins/"
  scp2nagios "${basedir}/nagios/check_oozie_status.sh" "/usr/lib64/nagios/plugins/"
  scp2nagios "${basedir}/nagios/check_rpcq_latency.php" "/usr/lib64/nagios/plugins/"
  scp2nagios "${basedir}/nagios/check_templeton_status.sh" "/usr/lib64/nagios/plugins/"
  scp2nagios "${basedir}/nagios/check_webui.sh" "/usr/lib64/nagios/plugins/"

  # scp2nagios "$mon_config_dir/nagios-check_snmp_storage.pl" "/usr/lib64/nagios/plugins/check_snmp_storage.pl"
  # scp2nagios "$mon_config_dir/nagios-check_snmp_load.pl" "/usr/lib64/nagios/plugins/check_snmp_load.pl"
  # sshnagios "chmod 775 /usr/lib64/nagios/plugins/check_snmp_mem.pl /usr/lib64/nagios/plugins/check_snmp_storage.pl /usr/lib64/nagios/plugins/check_snmp_load.pl"
  sshnagios "$HTPASSWD_CMD -c -b /etc/nagios/htpasswd.users $nagios_web_login '$nagios_web_password'"
  sed \
          -e "s/NAGIOSCONTACT/$nagioscontact/"            \
          -e "s/@NAGIOS_WEB_LOGIN@/$nagios_web_login/"    \
          "$mon_config_dir/nagios-contacts.cfg-BASELINE"  \
          > nagios-contacts.cfg
  sed \
          -e "s!OOZIE_JAVA_HOME!${java64home}!"            \
          "$mon_config_dir/nagios-hadoop-services-oozie.cfg-BASELINE"  \
          > $mon_config_dir/nagios-hadoop-services-oozie.cfg

  sed \
          -e "s!HCAT_JAVA_HOME!${java64home}!"            \
          "$mon_config_dir/nagios-hadoop-services-hivemetastore.cfg-BASELINE"  \
          > $mon_config_dir/nagios-hadoop-services-hivemetastore.cfg

  # If SUSE change the status dat file path and nagios bin location
  nagios_status_file="/var/nagios/status.dat"
  nagios_bin="/usr/bin/nagios"
  if [[ "${SYSTEM_OS}" == "${OS_SLES}" ]]; then
    nagios_status_file="/var/lib/nagios/status.dat"
    nagios_bin="/usr/sbin/nagios"
  fi
  sed \
          -e "s%NAGIOS_STATUS_CHECK_ARGS%${nagios_status_file}!${nagios_bin}%"            \
          "$mon_config_dir/nagios-hadoop-services.cfg-BASELINE"  \
          > nagios-hadoop-services.cfg

  # run the sed on the hadoop-commands.cfg and update the location of the nagios status file
  sed -i "s|NAGIOS_STATUS_FILE|${nagios_status_file}|g" $mon_config_dir/nagios-hadoop-commands.cfg-BASELINE

  if [[ "-n $hbmhost" && "$installhbase" == "yes" ]]; then
    cat $mon_config_dir/nagios-hadoop-services-hbase.cfg-BASELINE >> nagios-hadoop-services.cfg
  fi
  if [[ "-n $zkhosts" && "$installhbase" == "yes" ]]; then
    cat $mon_config_dir/nagios-hadoop-services-zk.cfg-BASELINE >> nagios-hadoop-services.cfg
  fi
  if [[ "-n $hivehost" && "$installhive" == "yes" ]]; then
    cat $mon_config_dir/nagios-hadoop-services-hivemetastore.cfg >> nagios-hadoop-services.cfg
  fi
  if [[ "-n $oozieshost" && "$installoozie" == "yes" ]]; then
    cat $mon_config_dir/nagios-hadoop-services-oozie.cfg >> nagios-hadoop-services.cfg
  fi
  if [[ "-n $ttonhosts" && "$installtempleton" == "yes" ]]; then
    cat $mon_config_dir/nagios-hadoop-services-templeton.cfg-BASELINE >> nagios-hadoop-services.cfg
  fi
  cat $mon_config_dir/nagios-hadoop-services-ganglia.cfg-BASELINE >> nagios-hadoop-services.cfg

  scp2nagios "$mon_config_dir/nagios.cfg-${SYSTEM_OS}-BASELINE" "$nagios_cfg"
  scp2nagios "$mon_config_dir/nagios-hadoop-commands.cfg-BASELINE" \
          "$nagios_commands"
  scp2nagios "$mon_config_dir/nagios-hadoop-servicegroups.cfg-BASELINE" \
          "$nagios_servicegroups_cfg"
  scp2nagios "nagios-hadoop-services.cfg" "$nagios_services_cfg"
  scp2nagios "nagios-contacts.cfg" "$nagios_contacts_cfg"

  # Change the nagios resource cfg, if platform is 64bit SUSE
  os_arch=`uname -a | grep x86_64`
  if [[ -n $os_arch && "${SYSTEM_OS}" == "${OS_SLES}" ]]; then
    sshnagios "sed -i -e \"s/\$USER1\$=\/usr\/lib\/nagios\/plugins/\$USER1\$=\/usr\/lib64\/nagios\/plugins/\" $nagios_resource_cfg"
  fi

  rm -f hadoop-hosts.cfg
  local hosts=`uniq_list $montargets $gwhost`
  for host in $hosts; do
          #hservername=`echo $host | grep -v "^$" | cut -f 1 -d '.'`
          echo "define host {"            >> hadoop-hosts.cfg
          echo "    alias $host"          >> hadoop-hosts.cfg   
          echo "    host_name $host"      >> hadoop-hosts.cfg       
          echo "    use linux-server"     >> hadoop-hosts.cfg
          echo "    address $host"        >> hadoop-hosts.cfg
          echo "    check_interval         0.25" >> hadoop-hosts.cfg
          echo "    retry_interval         0.25" >> hadoop-hosts.cfg
          echo "    max_check_attempts     4" >> hadoop-hosts.cfg
          echo "    notifications_enabled     1" >> hadoop-hosts.cfg
          echo "    first_notification_delay  0" >> hadoop-hosts.cfg
          echo "    notification_interval     0" >> hadoop-hosts.cfg
          echo "    notification_options      d,u,r" >> hadoop-hosts.cfg
          echo "}"                        >> hadoop-hosts.cfg
          echo ""                         >> hadoop-hosts.cfg
  done
  scp2nagios "hadoop-hosts.cfg" "$nagios_hosts_cfg"
  print_nagios_hostgroups >nagios-hadoop-hostgroups.cfg
  scp2nagios "nagios-hadoop-hostgroups.cfg" "$nagios_hostgroups_cfg"
}


# Print a single hostgroup entry
print_nagios_hostgroup_entry() {
        local members=$1
        local name=$2
        local alias=$3

        if [[ -n "$members" ]]; then
                sed \
                        -e "s/@MEMBERS@/$members/"      \
                        -e "s/@NAME@/$name/"            \
                        -e "s/@ALIAS@/$alias/"          \
                        "$mon_config_dir/nagios-hostgroup-entry-BASELINE"
                echo
        fi
}

# Print the hostgroups file
print_nagios_hostgroups() {
        local lserverhosts=`join_comma $montargets`
        local slaveshosts=`join_comma $slaves`
        local regionhosts=`join_comma $rshosts`
        local zhosts="";
        if [[ -n "$zkhosts" ]]; then
          zhosts=`join_comma $zkhosts`
        fi

        print_nagios_hostgroup_entry "$lserverhosts" "all-servers" "All Servers"
        print_nagios_hostgroup_entry "$slaveshosts"  "slaves"      "slaves"
        print_nagios_hostgroup_entry "$nnhost"       "namenode"    "namenode"
        print_nagios_hostgroup_entry "$snhost"       "snamenode"   "snamenode"
        print_nagios_hostgroup_entry "$hbmhost"      "hbasemaster" "hbasemaster"
        print_nagios_hostgroup_entry "$hivehost"     "hiveserver"  "hiveserver"
        print_nagios_hostgroup_entry "$jthost"       "jobtracker"  "jobtracker"
        print_nagios_hostgroup_entry "$gwhost"       "gateway"     "gateway"
        print_nagios_hostgroup_entry "$nagioshost"   "nagios-server"     "nagios-server"
        print_nagios_hostgroup_entry "$gangliahost"  "ganglia-server"    "ganglia-server"
        print_nagios_hostgroup_entry "$zhosts"       "zookeeper-servers" "zookeeper-servers"
        print_nagios_hostgroup_entry "$regionhosts"  "region-servers" "region-servers"
        print_nagios_hostgroup_entry "$ttonhosts"    "templeton-server" "templeton-server"
        print_nagios_hostgroup_entry "$oozieshost"   "oozie-server" "oozie-server"

}

# Restart the Hadoop servers so they pick up the metrics properties file
restart_hadoop() {
        echo0 "Restarting Hadoop"
        sshnodes "/etc/init.d/hadoop-datanode restart"
        sshjt "/etc/init.d/hadoop-jobtracker restart"
        sshjt "/etc/init.d/hadoop-historyserver restart"
        sshsn "/etc/init.d/hadoop-secondarynamenode restart"
        sshnn "/etc/init.d/hadoop-namenode restart"
        sshnodes "/etc/init.d/hadoop-tasktracker restart"
}

is_json_enabled_on_host() {
  local json_enabled=0
  local chk_host=$1
  log0 "on $dashboardhost"
  ssh_cmd=""
  if [[ -z "$sshkey" ]]; then
    ssh_cmd="ssh root@${chk_host}"
  else
    ssh_cmd="ssh -i ${sshkey} root@${chk_host}"
  fi
  cmd="${ssh_cmd} /usr/bin/php -i | grep \"json support => enabled\" | wc -l"
  output=`eval $cmd`
  echo "Running json check on ${chk_host}: output of $cmd : $output" >> $outlog
  if [[ "$output" != "0" ]]; then
    json_enabled=1
  fi
  return ${json_enabled}
}

############################################################
# FUNCTION TO INSTALL DASHBOARD FRONTEND
############################################################
installdashboard() {
  if [[ "$installdashboard" != "yes" ]] ; then
    log0 "Dashboard does not need to be installed"
    return
  fi

  echo0 "Installing HDP Monitoring Dashboard"
  deployDashboardRpms
  deployDashboardConfigs
  echo "Done installing dashboard"
}

deployDashboardRpms() {
  echo0 "Installing HDP Monitoring Dashboard RPMs"
    # Install dashboard rpm on required host
  sshdashboard "$installpkgcmd hdp_mon_dashboard"

  ensureJson ${dashboardhost}
}

deployDashboardConfigs() {
  echo0 "Installing HDP Monitoring Dashboard Configs"
    # Push cluster configuration to required host
  hdpmonproperties="${artifactdownloaddir}/hdpmonitoring.properties"
  hdpmonconfgen
  scp2dashboard ${confRoot}/hdp-mon-conf/* /usr/share/hdp/dashboard/dataServices/conf/
}

############################################################
# FUNCTION TO START DASHBOARD FRONTEND
############################################################
startdashboard() {
  if [[ "$installdashboard" == "yes" ]] ; then
    echo0 "Starting Dashboard"
    sshdashboard "$HTTPD_CMD restart"
  fi
}

stopdashboard() {
  if [[ "$installdashboard" == "yes" ]] ; then
    echo0 "Stopping Dashboard"
    sshdashboard "$HTTPD_CMD stop"
  fi
}
