#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

source ${basedir}/gsLibCommon.sh

export outlog="/tmp/gsConfigGather-$$.out"

############################################################
# FUNCTION TO DOWNLOAD CONFIGS FROM PARTICULAR LOCATION
############################################################

function pull_config() {
  local node=$1
  local svc=$2
  local comp=$3
  local remoteconfdir=$4
  local destdir=$5
  local dest="${destdir}/${comp}/${node}/"

  mkdir -p "${dest}"

  echo "Downloading configs from host $node for $svc:$comp from \
${remoteconfdir} into ${destdir}" | tee -a $outlog

  if [ "$sshkey" == "" ]
  then
    scpcmd="scp "
  else
    scpcmd="scp -i ${sshkey} "
  fi
  cmd="${scpcmd} ${gatheruser}@${node}:${remoteconfdir}/* ${dest}"
  echo $cmd | tee -a $outlog
  eval $cmd >> $outlog 2>&1
  local retval=$?
  if [[ "$retval" != "0" ]]; then
    echo "Warn: error in running scp command, error=${retval}" | tee -a $outlog
    return 1
  fi
  return 0
}



############################################################
# CHECK REQUIRED CONF LOCATIONS SPECIFIED
############################################################

validatehadoopconfdir() {
  if [[ ! -z "${hadoop_conf_dir}" ]]; then
    return 0
  fi

  if [[ -z "${namenode_conf_dir}" \
        || -z "${snamenode_conf_dir}" \
        || -z "${datanode_conf_dir}" \
        || -z "${jobtracker_conf_dir}" \
        || -z "${tasktracker_conf_dir}" ]]; then
    echo "Error: hadoop_conf_dir not specified and one of \
namenode_conf_dir, snamenode_conf_dir \
datanode_conf_dir, jobtracker_conf_dir \
tasktracker_conf_dir is not specified"
    exit 1
  fi
  return 0
}

validatehbaseconfdir() {
  if [[ ! -z "${hbase_conf_dir}" ]]; then
    return 0
  fi

  if [[ -z "${hbasemaster_conf_dir}" \
        || -z "${hbaseregionserver_conf_dir}" ]]; then
    echo "Error: hbase_conf_dir not specified and one of \
hbasemaster_conf_dir, hbaseregionserver_conf_dir \
is not specified"
    exit 1
  fi
  return 0
}

validatezookeeperconfdir() {
  if [[ ! -z "${zookeeper_conf_dir}" ]]; then
    return 0
  fi
  echo "Error: zookeeper_conf_dir not specified"
  exit 1
}

validateoozieconfdir() {
  if [[ ! -z "${oozie_conf_dir}" ]]; then
    return 0
  fi
  echo "Error: oozie_conf_dir not specified"
  exit 1
}

validatehiveconfdir() {
  if [[ ! -z "${hive_conf_dir}" ]]; then
    return 0
  fi
  echo "Error: hive_conf_dir not specified"
  exit 1
}

validatepigconfdir() {
  if [[ ! -z "${pig_conf_dir}" ]]; then
    return 0
  fi
  echo "Error: pig_conf_dir not specified"
  exit 1
}

############################################################
#HOSTDETAILS
############################################################
if [[ -z ${hostfiledir} ]]; then
  hostfiledir="."
fi

gwhost=$(cat ${hostfiledir}/gateway)
nnhost=$(cat ${hostfiledir}/namenode)
snhost=$(cat ${hostfiledir}/snamenode)
jthost=$(cat ${hostfiledir}/jobtracker)
hbmhost=$(cat ${hostfiledir}/hbasemaster)
hcshost=$(cat ${hostfiledir}/hcatserver)
slaves=$(cat ${hostfiledir}/nodes)
rshosts=$(cat ${hostfiledir}/hbasenodes)
zkhosts=$(cat ${hostfiledir}/zknodes)
ooziehost=$(cat ${hostfiledir}/oozieserver)
pighost=$(cat ${hostfiledir}/gateway)
