#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#

  source ${basedir}/gsLibCommon.sh
  source ${basedir}/gsInstaller.properties
  source ${basedir}/hdpServiceUsers.properties
  
  if [[ "x" == "x${outputlogfile}" ]]; then
    outputlogfile="/tmp/gsinstaller-$$.out"
  fi
  export outlog="${outputlogfile}"

  export OS_SLES="suse"
  export OS_CENTOS="centos"
 
  ############################################################
  #FUNCTION TO DETERMINE THE OS DISTRIBUTION
  ############################################################
  setos() {
    if [ -f '/etc/redhat-release' ]; then
      #read the contents of the file
      local release_txt="`cat /etc/redhat-release`"
      #for rhel and centos use centos
      export SYSTEM_OS="${OS_CENTOS}"
    elif [ -f '/etc/SuSE-release' ]; then
      #read the contents of the file
      local release_txt="`cat /etc/SuSE-release`"
      export SYSTEM_OS="${OS_SLES}"
    else
      echo0 "Unsupported OS. Supported OS are SLES 11 , RHEL6, RHEL6, CentOS5, CentOS6"
      exit 1
    fi
      
    #Determine the OS based on the cotent of the release file
    #CentOS6
    local cmd="echo '$release_txt' | grep -q 'CentOS.*6.[0-9]*'"
    echo $cmd >> $outlog 2>&1
    eval $cmd
    if [ $? -eq 0 ]; then
      export OS_VERSION="6"
      return
    fi
    
    #CentOS5
    cmd="echo '$release_txt' | grep -q 'CentOS.*5.[0-9]*'"
    echo $cmd >> $outlog 2>&1
    eval $cmd
    if [ $? -eq 0 ]; then
      export OS_VERSION="5"
      return
    fi
    
    #RHEL5
    local cmd="echo '$release_txt' | grep -q 'Red Hat.*5.[0-9]*'"
    echo $cmd >> $outlog 2>&1
    eval $cmd
    if [ $? -eq 0 ]; then
      export OS_VERSION="5"
      return
    fi
    
    #RHEL6
    local cmd="echo '$release_txt' | grep -q 'Red Hat.*6.[0-9]*'"
    echo $cmd >> $outlog 2>&1
    eval $cmd
    if [ $? -eq 0 ]; then
      export OS_VERSION="6"
      return
    fi
    
    #SLES11
    local cmd="echo '$release_txt' | grep -q 'SUSE Linux.*11.*'"
    echo $cmd >> $outlog 2>&1
    eval $cmd
    if [ $? -eq 0 ]; then
      export OS_VERSION="11"
      return
    fi

    #if you are here that means you did not find any os
    echo0 "Unsupported OS. Supported OS are SLES 11 , RHEL6, RHEL6, CentOS5, CentOS6. Release text found is : $release_txt"
    exit 1
  }
  
  setos

  export WGET="/usr/bin/wget"
  ConnectTimeOut=${ConnectTimeOut:-3}
  usepdsh=${usepdsh:-"no"}
  export sshcmd="ssh -o ConnectTimeOut=$ConnectTimeOut"
  
  #The version of HDP to use
  BUILD_NUM=15
  HDPVersion=1.1.0.${BUILD_NUM}

  ### DOWNLOAD URL DETAILS
  export BASE_URL="http://public-repo-1.hortonworks.com"
  export BASE_URL_W_OS="${BASE_URL}/HDP-${HDPVersion}/repos/${SYSTEM_OS}${OS_VERSION}"
  export BASE_UTILS_URL_W_OS="${BASE_URL}/HDP-UTILS-${HDPVersion}/repos/${SYSTEM_OS}${OS_VERSION}"
  export BASE_URL_ARTIFACTS="${BASE_URL}/ARTIFACTS"
  export REPO_FILE="${BASE_URL_W_OS}/hdp.repo"
  #OS SPECIFIC REPO RPM
  if [ "${OS_CENTOS}5" == "${SYSTEM_OS}${OS_VERSION}" ]; then
    export REPO_RPM="${BASE_URL_W_OS}/hdp-release-${HDPVersion}-1.el5.noarch.rpm"
  elif [ "${OS_CENTOS}6" == "${SYSTEM_OS}${OS_VERSION}" ]; then
    export REPO_RPM="${BASE_URL_W_OS}/hdp-release-${HDPVersion}-1.el6.noarch.rpm"
  elif [ "${OS_SLES}11" == "${SYSTEM_OS}${OS_VERSION}" ]; then
    export REPO_RPM="${BASE_URL_W_OS}/hdp-release-${HDPVersion}-1.noarch.rpm"
  else
    echo "Unsupported OS ${SYSTEM_OS}${OS_VERSION}"
    exit 1
  fi

  #different hardcoded strings required for templeton and hcatalog
  export templeton_version="0.1.4.${BUILD_NUM}"
  export hcatalog_version="0.4.0.${BUILD_NUM}"
  export hivetarname="hive-0.9.0.${BUILD_NUM}.tar.gz"
  export hivetarprefix="`echo $hivetarname | sed "s/.tar.gz//"`"
  export pigtarname="pig-0.9.2.${BUILD_NUM}.tar.gz"
  export pigtarprefix="`echo $pigtarname | sed "s/.tar.gz//"`"

  #JAVA 1.6u31 urls
  export JDK_1_6_U31_64_URL="http://download.oracle.com/otn-pub/java/jdk/6u31-b04/jdk-6u31-linux-x64.bin"
  export JDK_1_6_U31_64_SIZE="82M"
  
  #set the java info to 1.6u26
  export JDK_VERSION="jdk1.6.0_31"
  export JDK_64_URL="$JDK_1_6_U31_64_URL"
  export JDK_64_SIZE="$JDK_1_6_U31_64_SIZE"

  export JCE_POLICY_URL="http://download.oracle.com/otn-pub/java/jce_policy/6/jce_policy-6.zip"
  export JCE_POLICY_SIZE="8.9K"
  
  
  export gcLogFileOption="loggc"


  if [[ "x" == "x${statusdumpfile}" ]]; then
    statusdumpfile="/tmp/gsinstaller-status-dump-$$.out"
  fi
  export gsStatusDumpFile="${statusdumpfile}"
  echo "" > ${gsStatusDumpFile}

  export hcatkeytab="${keytabdir}/hcat.service.keytab"
  export artifactdownloaddir="/tmp/HDP-artifacts-$$"
  #this is 34M on rhel and 32M of suse
  if [ "${SYSTEM_OS}" == "${OS_CENTOS}" ]; then
    export hivetarsize="29M"
  else
    export hivetarsize="29M"
  fi
  export pigtarsize="46M"
  export hadooplzosize="6.6M"
  export hadooplzotarname="hadoop-lzo-0.5.0.tar.gz"
  export hadooplzoname="hadoop-lzo-0.5.0"

  ###PACKAGE NAME DETAILS
  export deploypath="${installdir}"
  export jobdesc=""
  export destdir="/tmp/HDP"
  export killjavacmd="ps -ef | grep [j]ava | awk '{ print \$2 }' | xargs kill -9 || exit 0  2>&1 >> /dev/null"
  export hbase_dfs_dir="/apps/hbase/data"

  hcatclusterproperties="${artifactdownloaddir}/hcatcluster.properties"
  hiveclusterproperties="${artifactdownloaddir}/hivecluster.properties"
  templetonclusterproperties="${artifactdownloaddir}/templeton.properties"
  oozieclusterproperties="${artifactdownloaddir}/ooziecluster.properties"
  sqoopclusterproperties="${artifactdownloaddir}/sqoopcluster.properties"
  clusterproperties="${artifactdownloaddir}/cluster.properties"
  templates="${basedir}/confSupport/templates"
  confRoot="${artifactdownloaddir}/generated-confs"


  #============================================================#
  # UPGRADE MODE FLAGS AND SETTINGS
  #============================================================#

  #ENTER time to wait for namenode to leave safemode
  # Not needed here as gsInstaller sets a default if unset
  #nnsafemodetimeout=600

  #Enter location for user-defined configs
  #Can be used to override use of generated configs in normal or upgrade mode
  #Location is base dir under which hadoop-conf, zk-conf, hbase-conf, etc
  # config directories are expected to exist
  #Default is to look at ./generated-confs/ in upgrade mode.
  user_configs=

  pigclusterproperties="${artifactdownloaddir}/pig.properties"

# REZNOR: No idea where the 2nd and 3rd files come from - can they be removed? Do we need ${valueFiles} at all, or can we just
# make do with ${clusterproperties}?

  ### to support config generation for hadoop
  valueFiles="${clusterproperties} \
    confSupport/cluster-values/gridnode.properties \
    confSupport/cluster-values/base.properties"

# REZNOR: Are there any plans for future expansion, or can we do away with ${hbasevalueFiles}?
  hbaseproperties="${artifactdownloaddir}/hbase.properties"
  ### to support config generation for hbase
  hbasevalueFiles="${hbaseproperties}"

  ############################################################
  #FUNCTION TO DISPLAY USER SELECTION FOR GSINSTALLER
  ############################################################

  displayselection () {
    echo "hdfsuser         : $hdfsuser" | tee -a  $outlog
    echo "mapreduser       : $mapreduser" | tee -a  $outlog
    echo "installhbase     : $installhbase" | tee -a  $outlog
    [[ "$installhbase" == "yes" ]] &&  \
    echo "hbaseuser        : $hbaseuser" | tee -a $outlog &&  \
    echo "zkuser           : $zkuser "    | tee -a $outlog
    echo "installhive      : $installhive" | tee -a  $outlog
    [[ "$installhive" == "yes" ]] &&  \
    echo "hiveuser         : $hiveuser" | tee -a $outlog
    echo "installtempleton : $installtempleton" | tee -a  $outlog
    [[ "$installtempleton" == "yes" ]] &&  \
    echo "templetonuser    : $templetonuser" | tee -a $outlog
    echo "installoozie     : $installoozie" | tee -a  $outlog
    [[ "$installoozie" == "yes" ]] &&  \
    echo "oozieuser        : $oozieuser" | tee -a $outlog
    echo "installhcat      : $installhcat" | tee -a  $outlog
    echo "installpig       : $installpig" | tee -a  $outlog
    echo "installsqoop     : $installsqoop" | tee -a  $outlog
    echo "smoke_test_user  : $smoke_test_user" | tee -a $outlog
    echo "enablesecurity   : $enablesecurity" | tee -a  $outlog
    echo "enablemon        : $enablemon" | tee -a $outlog
  # echo "upgrade          : $upgrade" | tee -a  $outlog
    echo "package          : $installpkg" | tee -a  $outlog
   # echo "user_configs    : ${user_configs}" | tee -a $outlog
    echo "$line" | tee -a  $outlog
  }

  ############################################################
  #FUNCTION TO DISPLAY URL'S FOR GRID STACK DAEMONS
  ############################################################
  urldetails() {
    echo0 "Web Urls"
    echo  "Namenode URL   : http://$nnhost:50070" | tee -a  $outlog
    echo  "Jobtracker URL : http://$jthost:50030" | tee -a  $outlog
    echo  "JobHistory URL : http://$jthost:51111/jobhistoryhome.jsp" | tee -a  $outlog
    [ $installhbase="yes" ] && echo "HbaseMaster URL: http://$hbmhost:60010" | tee -a  $outlog
    echo "$line"
  }

  ############################################################
  #FUNCTION TO DISPLAY CLUSTER DETAILS
  ############################################################
  clusterdetails() {
    echo0 "Cluster Details"
    echo  "Namenode host         : $nnhost" | tee -a  $outlog
    echo  "Jobtracker host       : $jthost" | tee -a  $outlog
    echo  "SNamenode host        : $snhost" | tee -a  $outlog
    echo  "Gateway host          : $gwhost" | tee -a  $outlog
    [[ "-n $hbmhost"  &&  "$installhbase" == "yes" ]] && echo "Hbase Master          : $hbmhost" | tee -a  $outlog
    [[ "-n $hivehost" && "$installhive" == "yes" ]] && echo "Hive Metastore Server : $hivehost"  | tee -a  $outlog
    [[ "-n $ttonhosts" && "$installtempleton" == "yes" ]] && echo "Templeton  Servers    : `echo $ttonhosts | tr ' ' ','`"  | tee -a  $outlog
    [[ "-n $oozieshost" && "$installoozie" == "yes" ]] && echo "Oozie  Server         : $oozieshost"  | tee -a  $outlog
    [[ "$installpig" == "yes" ]] && echo "Pig  Client           : $gwhost"  | tee -a  $outlog
    [[ "$installsqoop" == "yes" ]] && echo "Sqoop  Client         : $gwhost"  | tee -a  $outlog
    echo "$line" | tee -a  $outlog
  }


  ############################################################
  #FUNCTION TO CHANGE VARS BASED ON OS DISTRIBUTION
  ############################################################
  modifyvarsforos() {
    export SUDOASROOT="sudo"
    export kinitpath=/usr/kerberos/bin/kinit

    #OS INDEPENDENT SETTINGS
    if [ 'rpm' == "$package" ]; then
      export SUDOUSERPREFIX="su -"
    else
      export SUDOUSERPREFIX="sudo -u"
    fi

    #OS DEPENDENT SETTINGS
    if [ $SYSTEM_OS == $OS_SLES ]; then
      export SUDOCMDOPTION="sh -c"
      export removepkgcmd="zypper -n remove"
      export installpkgcmd="zypper -n --no-gpg-checks install"
      export searchpkgcmd="zypper -n --no-gpg-checks search"
      export useraddcmd="useradd -m"
      export kinitpath=/usr/bin/kinit
      export cleanrepocmd="zypper clean"
      export usermodcmd="usermod"
      export groupaddcmd="groupadd"
    else
      if [ 'rpm' == "$package" ]; then
        export SUDOCMDOPTION="-c"
      else
        export SUDOCMDOPTION="-i"
      fi
      export removepkgcmd="yum -y remove"
      export installpkgcmd="yum -y install"
      export useraddcmd="useradd"
      export usermodcmd="usermod"
      export groupaddcmd="groupadd"
      export cleanrepocmd="yum clean all"
      if [ $OS_VERSION == "6" ]; then
        export kinitpath=/usr/bin/kinit
      fi
    fi
  }

#### PDSH Integration
  commaSeparatedHostList () {
    echo $* | sed -e 's/ /,/g'
  }

  pdshExec () {
    pdshHostlist=$1
    shift
    pdshUser=$1
    local err_file="/tmp/pdsh_err_$$.out"
    shift
#    echo "SSH CMD: pdsh -R exec -w $pdshHostlist $sshcmd -l $pdshUser %h $*"
    if [ "x${sshkey}x" == "xx" ]; then
      pdsh -R exec -w $pdshHostlist $sshcmd -q -t -l $pdshUser %h $* 2> $err_file
    else
      pdsh -R exec -w $pdshHostlist $sshcmd -q -t -i $sshkey -l $pdshUser %h $* 2> $err_file
    fi

    #check if ssh returned error or not
    local cmd="cat $err_file | grep -q 'ssh exited with exit code [1-9]*'"
    eval $cmd
    local ret=$?
    #remove the error file
    rm -f $err_file
    if [ "0" == "$ret" ]; then
      return 1
    else
      return 0
    fi
  }

  pdshScpExec () {
    pdshHostlist=$1
    shift
    pdshUser=$1
    shift

    Array=($*)
    length=${#Array[@]}
    finalDest=${Array[$(($length-1))]}
    #### Remove the destination
    unset Array[$(($length-1))]
    finalSource="${Array[*]}"

#    echo "SCP CMD: pdsh -R exec -w $pdshHostlist scp $finalSource $pdshUser@%h:$finalDest"
    if [ "x${sshkey}x" == "xx" ]; then
      pdsh -R exec -w $pdshHostlist scp $finalSource $pdshUser@%h:$finalDest
    else
      pdsh -R exec -w $pdshHostlist scp -i $sshkey $finalSource $pdshUser@%h:$finalDest
    fi

  }
  ############################################################
  #FUNCTION TO SSH RSNODES
  ############################################################
  sshrsnodes () {
    if [ "yes" == "$usepdsh" ]; then
       pdshExec `commaSeparatedHostList ${rshosts}` ${deployuser} $*
      return $?
    fi

    for node in ${rshosts}
      do
	[ "$jobdesc" != "" ] && echo "$jobdesc ${node}" && jobdesc=""
	echo "on $node" | tee -a $outlog
	[ "$sshkey" == "" ] && $sshcmd ${deployuser}@${node} $* >> $outlog 2>&1
	[ "$sshkey" != "" ] && $sshcmd -i ${sshkey} ${deployuser}@${node} $* >> $outlog 2>&1
    done
  }

  ############################################################
  #FUNCTION TO SSH NODES EXCLUDING NN, SN, AND JT
  ############################################################
  sshnodes () {

    if [ "yes" == "$usepdsh" ]; then
       pdshExec `commaSeparatedHostList ${slaves}` ${deployuser} $*
       return $?
    fi

    for node in ${slaves}
      do
	[ "$jobdesc" != "" ] && echo "$jobdesc ${node}" && jobdesc=""
	echo "on $node" | tee -a $outlog
	[ "$sshkey" == "" ] && $sshcmd ${deployuser}@${node} $* >> $outlog 2>&1
	[ "$sshkey" != "" ] && $sshcmd -i ${sshkey} ${deployuser}@${node} $* >> $outlog 2>&1
    done
  }

  ############################################################
  #FUNCTION TO SSH NN
  ############################################################
  sshnn () {
    echo "on $nnhost" | tee -a  $outlog
    [ "$jobdesc" != "" ] && echo "$jobdesc ${nnhost}" && jobdesc=""
    [ "$sshkey" == "" ] && $sshcmd ${deployuser}@${nnhost} $* >> $outlog 2>&1
    [ "$sshkey" != "" ] && $sshcmd -i ${sshkey} ${deployuser}@${nnhost} $* >> $outlog 2>&1
  }

  ############################################################
  #FUNCTION TO SSH SN
  ############################################################
  sshsn () {

    if [ "yes" == "$usepdsh" ]; then
       pdshExec `commaSeparatedHostList ${snhost}` ${deployuser} $*
       return $?
    fi

    for sn in ${snhost}
      do
        echo "on $sn " | tee -a $outlog
        [ "$jobdesc" != "" ] && echo "$jobdesc ${sn}" && jobdesc=""
	[ "$sshkey" == "" ] && $sshcmd ${deployuser}@${sn} $* >> $outlog 2>&1
        [ "$sshkey" != "" ] && $sshcmd -i ${sshkey} ${deployuser}@${sn} $* >> $outlog 2>&1
    done
  }

  ############################################################
  #FUNCTION TO SSH JT
  ############################################################
  sshjt () {
    [ "$jobdesc" != "" ] && echo "$jobdesc ${jthost}" && jobdesc=""
    echo "on $jthost" | tee -a $outlog
    [ "$sshkey" == "" ] && $sshcmd ${deployuser}@${jthost} $* >> $outlog 2>&1
    [ "$sshkey" != "" ] && $sshcmd -i ${sshkey} ${deployuser}@${jthost} $* >> $outlog 2>&1
  }

  ############################################################
  #FUNCTION TO SSH GATEWAY
  ############################################################
  sshgwforsmoke () {
    #echo "on $gwhost" | tee -a $outlog
    echo "on $gwhost" >> $outlog 2>&1
    [ "$sshkey" == "" ] && $sshcmd -q -t ${deployuser}@${gwhost} $@ 2>&1 | tee -a $outlog
    [ "$sshkey" != "" ] && $sshcmd -q -t -i ${sshkey} ${deployuser}@${gwhost} $@ 2>&1 | tee -a $outlog
  }

  ############################################################
  #FUNCTION TO SSH GATEWAY
  ############################################################
  sshgw () {
    [ "$jobdesc" != "" ] && echo "$jobdesc ${gwhost}" && jobdesc=""
    echo "on $gwhost" | tee -a $outlog
    [ "$sshkey" == "" ] && $sshcmd -q -t ${deployuser}@${gwhost} $* >> $outlog 2>&1
    [ "$sshkey" != "" ] && $sshcmd -q -t -i ${sshkey} ${deployuser}@${gwhost} $* >> $outlog 2>&1
  }

  ############################################################
  #FUNCTION TO SSH HBASE MASTER
  ############################################################
  sshhbm () {
    [ "$jobdesc" != "" ] && echo "$jobdesc ${hbmhost}" && jobdesc=""
    echo "on $hbmhost " | tee -a  $outlog
    [ "$sshkey" == "" ] && $sshcmd ${deployuser}@${hbmhost} $* >> $outlog 2>&1
    if [ "$sshkey" != "" ] ; then
      $sshcmd -i ${sshkey} ${deployuser}@${hbmhost} $*
    fi
  }

  ############################################################
  #FUNCTION TO SSH ZOOKEEPER NODES
  ############################################################
  sshzk () {
    if [ "yes" == "$usepdsh" ]; then
       pdshExec `commaSeparatedHostList $(echo $zkhosts)` ${deployuser} $*
       echo "PDSH Exec: pdshExec `commaSeparatedHostList $(echo $zkhosts)` ${deployuser} $* >> $outlog"
       return $?
    fi

    [ "$jobdesc" != "" ] && echo "$jobdesc ${zkhosts}" && jobdesc=""
    for zk in $(echo $zkhosts)
    do
      echo "on $zk " | tee -a  $outlog
      [ "$sshkey" == "" ] && $sshcmd ${deployuser}@${zk} $* >> $outlog 2>&1
      if [ "$sshkey" != "" ] ; then
        $sshcmd -i ${sshkey} ${deployuser}@${zk} $*
      fi
    done
  }

  ############################################################
  #FUNCTION TO SSH HCAT SERVER
  ############################################################
  sshhcs () {
    [ "$jobdesc" != "" ] && echo "$jobdesc ${hcshost}" && jobdesc=""
    echo "on $hcshost"  | tee -a $outlog
    [ "$sshkey" == "" ] && $sshcmd ${deployuser}@${hcshost} $* >> $outlog 2>&1
    if [ "$sshkey" != "" ] ; then
      $sshcmd -i ${sshkey} ${deployuser}@${hcshost} $*
    fi
  }

  ############################################################
  #FUNCTION TO SSH ALL HOSTS
  ############################################################
  sshall () {

    if [ "yes" == "$usepdsh" ]; then
       pdshAllhosts=`echo $slaves $jthost $nnhost $snhost $gwhost $hbmhost $hivehost $rshosts $zkhosts`
       pdshExec `commaSeparatedHostList ${pdshAllhosts}` ${deployuser} $*
       return $?
    fi

    for i in $(echo $slaves $jthost $nnhost $snhost $gwhost $hbmhost $hivehost $rshosts $zkhosts)
      do
        echo "on $i"  | tee -a $outlog
	[ "$sshkey" == "" ] && $sshcmd ${deployuser}@${i} $*  >> $outlog 2>&1
        [ "$sshkey" != "" ] && $sshcmd -i ${sshkey} ${deployuser}@${i} $* >> $outlog 2>&1
    done
  }

  ############################################################
  #FUNCTION TO DOWNLOAD AND VALIDATE
  ############################################################
  downloadstuff() {
    url2download=$1
    artifactsize=$2
    size=""
    tries=1
    nooftries=5
    artifactname=`echo $url2download | awk -F/ '{ print $NF }' | cut -d'?' -f1`
    echo "Downloading $artifactname from $url2download" | tee -a $outlog
    while [[ -z "$size" ]] || [[ "$size" != "$artifactsize" ]]
    do
        $WGET -q --tries=10 "${url2download}" \
          -O $artifactdownloaddir/$artifactname
        size=`ls -lh $artifactdownloaddir/$artifactname | cut -d" " -f5 `
        echo "tries:$tries of $nooftries" >> $outlog 2>&1
        (( tries ++ ))
        [[ $tries -ge ${nooftries} ]] && echo "tried ${tries}\
        times and failing; downloaded artifact size is $size \
        but was expecting $artifactsize" | tee -a $outlog && \
        dumpErrorExitStatus "SETUP" "Download failed - mismatch size" && exit 1
    done
    url2download=""
    artifactsize=""
  }

  ############################################################
  #FUNCTION TO SCP TO GWHOST
  ############################################################
  scp2gw () {

    if [ "yes" == "$usepdsh" ]; then
       pdshScpExec `commaSeparatedHostList ${gwhost}` ${deployuser} $1 $2
      return $?
    fi

    for i in $(echo $gwhost)
      do
        echo "to $i"  | tee -a $outlog
        [ "$sshkey" == "" ] && scp $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
        [ "$sshkey" != "" ] && scp -i ${sshkey} $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
    done
  }
  ############################################################
  #FUNCTION TO SCP TO ZKHOST
  ############################################################
  scp2zk () {

    if [ "yes" == "$usepdsh" ]; then
       pdshScpExec `commaSeparatedHostList $(echo $zkhosts)` ${deployuser} $1 $2
       echo "PDSH SCP: pdshScpExec `commaSeparatedHostList $(echo $zkhosts)` ${deployuser} $* >> $outlog"
      return $?
    fi

    for i in $(echo $zkhosts)
      do
        echo "to $i"  | tee -a $outlog
        [ "$sshkey" == "" ] && scp $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
        [ "$sshkey" != "" ] && scp -i ${sshkey} $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
    done
  }

  ############################################################
  #FUNCTION TO SCP TO ALL EXCEPT SLAVES
  ############################################################
  scp2slaves () {

    if [ "yes" == "$usepdsh" ]; then
       pdshScpExec `commaSeparatedHostList ${slaves}` ${deployuser} $1 $2
      return $?
    fi

    for i in $(echo $slaves)
      do
        echo "to $i"  | tee -a $outlog
        [ "$sshkey" == "" ] && scp $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
        [ "$sshkey" != "" ] && scp -i ${sshkey} $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
    done
  }

  ############################################################
  #FUNCTION TO SCP TO ALL EXCEPT SLAVES
  ############################################################
  scp2allexslaves () {

    if [ "yes" == "$usepdsh" ]; then
      pdshAllhosts=`echo $jthost $nnhost $snhost $gwhost $hbmhost $hivehost $rshosts $zkhosts`
      pdshScpExec `commaSeparatedHostList ${pdshAllHosts}` ${deployuser} $1 $2
      return $?
    fi

    for i in $(echo $jthost $nnhost $snhost $gwhost $hbmhost $rshosts $hivehost $zkhosts)
      do
        echo "to $i"  | tee -a $outlog
        [ "$sshkey" == "" ] && scp $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
        [ "$sshkey" != "" ] && scp -i ${sshkey} $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
    done
  }

  ############################################################
  #FUNCTION TO SCP TO ALL HOSTS
  ############################################################
  scp2host () {
    nodes=$(echo $1 | tr "," "\n" | sort | uniq | tr "\n" " ")
    artifacts=$(echo $2 | tr ',' ' ')
    destination=$3

    echo "SCP to nodes -> $nodes" >> $outlog 2>&1
    echo "Artifacts -> $artifacts" >> $outlog 2>&1
    echo "Destination -> $destdir" >> $outlog 2>&1
    if [ "yes" == "$usepdsh" ]; then
      pdshScpExec `commaSeparatedHostList ${nodes}` ${deployuser} $artifacts $destdir
      return $?
    fi

    for host in $(echo $nodes) ; do
      echo "to $host" >> $outlog 2>&1
      [ "$sshkey" == "" ] && scp $artifacts ${deployuser}@${host}:${destdir} >> $outlog 2>&1
      [ "$sshkey" != "" ] && scp -i ${sshkey} $artifacts ${deployuser}@${host}:${destdir} >> $outlog 2>&1
    done
  }

  ############################################################
  #FUNCTION TO SSH TO ANY HOSTS
  ############################################################
  ssh2host () {
    nodes=$(echo $1 | tr "," "\n" | sort | uniq | tr "\n" " ")
    command=$2
    echo "CMD -> $command" >> $outlog 2>&1

    if [ "yes" == "$usepdsh" ]; then
       echo "In nodes: `commaSeparatedHostList $(echo $nodes)`" >> $outlog 2>&1
       pdshExec `commaSeparatedHostList $(echo $nodes)` ${deployuser} $command >> $outlog 2>&1
       return $?
    fi

    for host in $(echo $nodes) ; do
      echo "in $host" >> $outlog 2>&1
      if [ "$sshkey" == "" ]; then
        $sshcmd -t -q ${deployuser}@${host} "${command}" >> $outlog 2>&1
      else
        $sshcmd -t -q -i ${sshkey} ${deployuser}@${host} "${command}" >> $outlog 2>&1
      fi
    done
  }

  ############################################################
  #FUNCTION TO SSH TO GW HOST
  ############################################################
  ssh2gwwithreturnvalue () {
      [ "$sshkey" == "" ] && $sshcmd -t -q ${deployuser}@${gwhost} "$*"
      [ "$sshkey" != "" ] && $sshcmd -t -q -i ${sshkey} ${deployuser}@${gwhost} "$*"
  }

  ############################################################
  #FUNCTION TO SSH TO ANY HOST
  ############################################################
  ssh2hostwithreturnvalue() {
    host=${1}
    cmd=${2}
    if [ "x${sshkey}x" == "xx" ]; then
      $sshcmd -t -q ${deployuser}@${host} "${cmd}"
      return $?
    else
      $sshcmd -t -q -i ${sshkey} ${deployuser}@${host} "${cmd}"
      return $?
    fi
  }

  ############################################################
  #FUNCTION TO SCP TO ALL HOSTS
  ############################################################
  scp2all () {

    if [ "yes" == "$usepdsh" ]; then
      pdshAllhosts=`echo $slaves $jthost $nnhost $snhost $gwhost $hbmhost $hivehost $rshosts $zkhosts`
      pdshScpExec `commaSeparatedHostList ${pdshAllHosts}` ${deployuser} $1 $2
      return $?
    fi

    for i in $(echo $slaves $jthost $nnhost $snhost $gwhost $hbmhost $rshosts $hivehost $zkhosts)
      do
        echo "to $i"  | tee -a $outlog
        [ "$sshkey" == "" ] && scp $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
        [ "$sshkey" != "" ] && scp -i ${sshkey} $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
    done
  }

  ############################################################
  #FUNCTION TO SCP TO HBASE HOSTS
  ############################################################
  scp2hbase () {

    if [ "yes" == "$usepdsh" ]; then
      pdshAllhosts=`echo $gwhost $hbmhost $rshosts`
      pdshScpExec `commaSeparatedHostList ${pdshAllHosts}` ${deployuser} $1 $2
      return $?
    fi

    for i in $(echo $hbmhost $gwhost $rshosts)
      do
        echo "to $i"  | tee -a $outlog
        [ "$sshkey" == "" ] && scp $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
        [ "$sshkey" != "" ] && scp -i ${sshkey} $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
    done
  }

  ############################################################
  #FUNCTION TO SCP TO HCATHOST
  ############################################################
  scp2hcat () {

    if [ "yes" == "$usepdsh" ]; then
      pdshAllhosts=`echo $gwhost $hcshost`
      pdshScpExec `commaSeparatedHostList ${pdshAllHosts}` ${deployuser} $1 $2
      return $?
    fi

    for i in $(echo $gwhost $hcshost)
      do
        echo "to $i"  | tee -a $outlog
        [ "$sshkey" == "" ] && scp $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
        [ "$sshkey" != "" ] && scp -i ${sshkey} $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
    done
  }

  ############################################################
  #FUNCTION TO SCP TO HOST
  ############################################################
  scp2any () {

    if [ "yes" == "$usepdsh" ]; then
      pdshAllhosts=`echo $slaves $jthost $nnhost $snhost $gwhost $hbmhost $hivehost $rshosts $zkhosts`
      pdshScpExec `commaSeparatedHostList ${pdshAllHosts}` ${deployuser} $1 $2
      return $?
    fi

    for i in $(echo $slaves $jthost $nnhost $snhost $gwhost $hbmhost $hivehost $rshosts $zkhosts)
      do
        echo "to $i"  | tee -a $outlog
        [ "$sshkey" == "" ] && scp $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
        [ "$sshkey" != "" ] && scp -i ${sshkey} $1 ${deployuser}@${i}:$2 >> $outlog 2>&1
    done
  }

  ############################################################
  #FUNCTION TO ADD HOST KEYS TO KNOWNHOSTS
  ############################################################
  add2knownhosts () {
    local ipcmd="/etc/init.d/iptables stop"
    if [[ "$SYSTEM_OS" == $OS_SLES ]]; then
      ipcmd=""
    fi
    for hst in $allhosts_with_mon
      do
        [[ "$sshkey" == "" && "${deployuser}" != "root" ]] && \
          $sshcmd -q -t -o StrictHostKeyChecking=no -f -Y ${deployuser}@${hst} "rm -rf ${destdir} ; mkdir -p ${destdir} "
        [[ "$sshkey" == "" && "${deployuser}" == "root" ]] && \
          $sshcmd -q -t -o StrictHostKeyChecking=no -f -Y ${deployuser}@${hst} "rm -rf ${destdir} ; mkdir -p ${destdir} "
        [[ "$sshkey" != "" && "${deployuser}" != "root" ]] && \
          $sshcmd -q -t -o StrictHostKeyChecking=no -f -i ${sshkey} ${deployuser}@${hst} "\
          $SUDOASROOT rm -rf ${destdir}; mkdir -p ${destdir};"
        [[ "$sshkey" != "" && "${deployuser}" == "root" ]] && \
          $sshcmd -q -t -o StrictHostKeyChecking=no -f -i ${sshkey} ${deployuser}@${hst} \
           "rm -rf ${destdir}; mkdir -p ${destdir}; chmod 777 $destdir; $ipcmd"
    done
  }

  ############################################################
  #FUNCTION TO SSH GATEWAY TO CHECK IF NN NOT IN SAFEMODE
  ############################################################
  sshgwfordfssafemode () {
    [ "$jobdesc" != "" ] && echo "$jobdesc ${nnhost}" && jobdesc=""
    echo "on $gwhost" | tee -a $outlog
    ssh_cmd=""
    if [ "$sshkey" == "" ]
    then
      ssh_cmd="$sshcmd -q -t ${deployuser}@${gwhost}"
    else
      ssh_cmd="$sshcmd -q -t -i ${sshkey} ${deployuser}@${gwhost}"
    fi
    cmd="${ssh_cmd} $*"
    echo "on $nnhost running $cmd" >> $outlog
    output=`eval $cmd`
    echo "Output from gwhost safe mode command: ${output}" >> $outlog
    if [[ $output =~ "Safe mode is OFF" ]]
    then
      echo "Found ${nnhost} with safe mode OFF" >> $outlog
      return 0
    fi
    echo "Found ${nnhost} with safe mode ON" >> $outlog
    return 1
  }

  ############################################################
  #FUNCTION TO VALIDATE USER PROVIDED CONFIGS
  ############################################################
  validateuserconfigs () {
    local confdir=$1
    echo0 "Validating user configs in dir: ${confdir}"
    if [ ! -d "${confdir}" ]; then
      echo "${confdir} does not exist" | tee -a $outlog
      return 1
    fi
    if [ ! -d "$confdir/hadoop-conf" ]; then
      echo "${confdir}/hadoop-conf does not exist" | tee -a $outlog
      return 1
    fi
    if [[ "installhbase" == "yes" && ! -d "$confdir/hbase-conf" ]]; then
      echo "hbase install enabled but ${confdir}/hbase-conf does not exist" | tee -a $outlog
      return 1
    fi
    if [[ "installhbase" == "yes" && ! -d "$confdir/zk-conf" ]]; then
      echo "hbase install enabled but ${confdir}/zk-conf does not exist" | tee -a $outlog
      return 1
    fi
    return 0
  }

  ############################################################
  #FUNCTION TO VALIDATE WEB URL PORTS
  ############################################################
  checkurl () {
    url=$1
    $WGET -q $url -O /dev/null
    echo $?
  }

  checkEmptyDir() {
    hosts=$1
    hosts="`echo $hosts | tr ',' '\n' | sort | uniq | tr '\n' ' '`"
    dirs=$2
    dirs=$(echo $dirs | tr "," " ")
    local i=0
    for host in $hosts
    do
      local j=0
      local existing_dirs=''
      #check each dir
      for dir in $dirs
      do
        local rc=0;
        #make an ls call to determine if dir exists or not
        ssh2host "$host" "ls $dir | wc -l | grep '^0$'"
        rc=$?
        #if dir has content then fail it
        if [ "$rc" != "0" ]; then
          existing_dirs="${existing_dirs}${dir}\n"
          ((j=$j+1))
        fi
      done
      if [ "$j" -ne "0" ]; then
        non_empty_dir_nodes="${non_empty_dir_nodes}Host: $host Non empty dirs->\n${existing_dirs}\n"
        ((i=$i+1))
      fi
    done
    if [ "$i" -ne "0" ]; then
      echo -e "$non_empty_dir_nodes"
      return 1
    else
      return 0
    fi
  }

  #function to check for the hdfs, mapred and zookeeper related dirs on local fs are empty or not. If not it will return non zero exit code
  checkDirAreEmpty()
  {
    #if the user wants us to clean up, then only for rpm's, tar balls we still want to fail
    if [ "true" == "$forceclean" ] && [ "rpm" == "$package" ]; then
      return 0
    fi

    echo0 "Checking for non empty directories"
    local rc=0
    local status

    #check to make sure the namenode dir is empty on the namenode
    checkEmptyDir "$nnhost" "$namenode_dir"

    status="$?"
    ((rc=$rc+$status))

    #check to make sure the secondary namenode dir is empty on the secondary namenode
    checkEmptyDir "$snhost" "$snamenode_dir"
    status="$?"
    ((rc=$rc+$status))

    #check for the data dirs and mapred dir on the slaves
    checkEmptyDir "$slaves" "$datanode_dir $mapred_dir"
    status="$?"
    ((rc=$rc+$status))

    #if installing zk data dir
    if [ 'yes' == "$installzk" ]; then
      checkEmptyDir "$zkhosts" "$zk_data_dir"
      status="$?"
      ((rc=$rc+$status))
    fi

    #if installing oozie check oozie dir
    if [ 'yes' == "$installoozie" ]; then
      checkEmptyDir "$oozieshost" "$oozie_db_dir"
      status="$?"
      ((rc=$rc+$status))
    fi

    #return the status
    return $rc
  }

  ############################################################
  # FUNCTION TO DISPLAY SMOKE TEST SUMMARY FOR ANY COMPOENT
  ############################################################
  displaySmokeTestResult() {
    local component=$1
    local result=$2

    if [[ "$result" == "" ]] ; then
      echo "$component Smoke Test    : Could not capture the exit code" | tee -a $outlog
      dumpStatus "SMOKE_TEST" "DONE" "$component" "$component smoke test result UNKNOWN"
      return 1
    elif [[ "$result" == "0" ]] ; then
      echo "$component Smoke Test    : Pass" | tee -a $outlog
      dumpStatus "SMOKE_TEST" "DONE" "$component" "$component smoke test result SUCCESS"
      return 0
    else
      echo "$component Smoke Test    : Fail" | tee -a $outlog
      dumpStatus "SMOKE_TEST" "DONE" "$component" "$component smoke test result FAILED"
      return 1
    fi
  }

  ############################################################
  # FUNCTION TO DUMP STATUS INTO STATUS FILE
  ############################################################
  # <stage> <state> <component> [<msg>]
  # EXIT ERROR <component>
  dumpStatus() {
    echo $* >> $gsStatusDumpFile
  }

  dumpErrorExitStatus() {
    dumpStatus "EXIT" "ERROR" "$*"
  }

  ############################################################
  # FUNCTION TO DISPLAY SMOKE TEST SUMMARY
  ############################################################
  displaySmokeTestSummary() {
    local smoke_test_result=0
    echo0 "Smoke Test Summmary" | tee -a $outlog

    #Hadoop
    displaySmokeTestResult "Hadoop" "$HADOOP_EXIT_CODE"
    dumpStatus "SMOKE_TEST" "END" "HADOOP" "Hadoop smoke test result ${HADOOP_EXIT_CODE}"
    ((smoke_test_result=$smoke_test_result + $?))

    if [[ "$installpig" == "yes" ]] ; then
      #Pig
      displaySmokeTestResult "Pig" "$PIG_EXIT_CODE"
      dumpStatus "SMOKE_TEST" "END" "PIG" "Pig smoke test result ${PIG_EXIT_CODE}"
      ((smoke_test_result=$smoke_test_result + $?))
    fi

    if [[ "$installzk" == "yes" ]] ; then
      #Zookeeper
      displaySmokeTestResult "Zookeeper" "$ZOOKEEPER_EXIT_CODE"
      dumpStatus "SMOKE_TEST" "END" "ZOOKEEPER" "Zookeeper smoke test result ${ZOOKEEPER_EXIT_CODE}"
      ((smoke_test_result=$smoke_test_result + $?))
    fi

    if [[ "$installhbase" == "yes" ]] ; then
      #Hbase
      displaySmokeTestResult "Hbase" "$HBASE_EXIT_CODE"
      dumpStatus "SMOKE_TEST" "END" "HBASE" "Hbase smoke test result ${HBASE_EXIT_CODE}"
      ((smoke_test_result=$smoke_test_result + $?))
    fi

    if [[ "$installhcat" == "yes" ]] ; then
      #Hcat
      displaySmokeTestResult "Hcat" "$HCAT_EXIT_CODE"
      dumpStatus "SMOKE_TEST" "END" "HCATALOG" "HCatalog smoke test result ${HCAT_EXIT_CODE}"
      ((smoke_test_result=$smoke_test_result + $?))
    fi
    if [[ "$installhive" == "yes" ]] ; then
      #Hive
      displaySmokeTestResult "Hive" "$HIVE_EXIT_CODE"
      dumpStatus "SMOKE_TEST" "END" "HIVE" "Hive smoke test result ${HIVE_EXIT_CODE}"
      ((smoke_test_result=$smoke_test_result + $?))
    fi

    if [[ "$installtempleton" == "yes" ]] ; then
      #Templeton
      displaySmokeTestResult "Templeton" "$TEMPLETON_EXIT_CODE"
      dumpStatus "SMOKE_TEST" "END" "TEMPLETON" "Templeton smoke test result ${TEMPLETON_EXIT_CODE}"
      ((smoke_test_result=$smoke_test_result + $?))
    fi

    if [[ "$installsqoop" == "yes" ]] ; then
      #Sqoop
      displaySmokeTestResult "Sqoop" "$SQOOP_EXIT_CODE"
      dumpStatus "SMOKE_TEST" "END" "SQOOP" "Sqoop smoke test result ${SQOOP_EXIT_CODE}"
      ((smoke_test_result=$smoke_test_result + $?))
    fi

    if [[ "$installoozie" == "yes" ]] ; then
      #Oozie
      displaySmokeTestResult "Oozie" "$OOZIE_EXIT_CODE"
      dumpStatus "SMOKE_TEST" "END" "OOZIE" "Oozie smoke test result ${OOZIE_EXIT_CODE}"
      ((smoke_test_result=$smoke_test_result + $?))
    fi

    return $smoke_test_result
  }

  ############################################################
  # FUNCTION TO Check Install Dependencies
  ############################################################
  checkInstallDependencies() {
## WE NEED TO SUPPPORT SECURE RHEL6
#    if [ "${SYSTEM_OS}${OS_VERSION}" == "${OS_CENTOS}6" ]; then
#      if [ 'yes' == "$security" ]; then
#        echo0 "Secure deploys on RHEL/CentOS 6 are not supported."
#        exit 1
#      fi
#    fi
    
    #if package is tar and security is on then quit
    if [ 'rpm' != "$package" ];  then
      echo0 "Only rpm deploys are supported. Invalid value $package sent for package."
      exit 1
    fi

# COMMENT IT OUT TEST SECURE OOZIE
#    #check oozie option
#    if [ 'yes' == "$installoozie" ]  && [ 'yes' == "$security" ]; then
#      echo0 "Oozie cannot be installed when secuity is on. Please set installoozie=no or security=no"
#      dumpErrorExitStatus "INIT" "Cannot install oozie with security=on"
#      exit 1
#    fi

    #check for templeton install
    if [ 'yes' == "$installtempleton" ]; then
# SUPPORTING SECURE DEPLOY FOR TEMPLETON
#      #if security is on then do not install
#      if [ 'yes' == "$security" ]; then
#        echo0 "Templeton cannot be installed when security is on. Please set installtempleton=no or security=no"
#        dumpErrorExitStatus "INIT" "Cannot install templeton with security=on"
#        exit 1
#      fi
      #if install hcat is not turned on then dont install it
      if [ 'yes' != "$installhcat" ]; then
        echo0 "Templeton install requires Hcatalog. Please set installhcat=yes or installtempleton=no"
        dumpErrorExitStatus "INIT" "Cannot install templeton without HCatalog"
        exit 1
      fi
      #if install hive is not turned on then dont install it
      if [ 'yes' != "$installhive" ]; then
        echo0 "Templeton install requires Hive. Please set installhive=yes or installtempleton=no"
        dumpErrorExitStatus "INIT" "Cannot install templeton without Hive"
        exit 1
      fi
      #check the zookeeper dependency
      checkZookeeperDependencies
      if [ "$?" -ne "0" ]; then
        echo0 "Templeton requires Zookeeper, please set appropriate settings."
        dumpErrorExitStatus "INIT" "Cannot install templeton without zookeeper"
        exit 1
      fi
    fi
    
    #Check for Hcat
    if [ 'yes' == "$installhcat" ]; then
      #if install hive is not turned on then dont install it
      if [ 'yes' != "$installhive" ]; then
        echo0 "Hcatalog install requires Hive. Please set installhive=yes or installhcat=no"
        dumpErrorExitStatus "INIT" "Cannot install hcatalog without Hive"
        exit 1
      fi
    fi
    
    #Check for Hcat
    if [ 'yes' == "$installhive" ]; then
      #if install hcat is not turned on then dont install it
      if [ 'yes' != "$installhcat" ]; then
        echo0 "Hive install requires Hcatalog. Please set installhcat=yes or installhive=no"
        dumpErrorExitStatus "INIT" "Cannot install Hive without Hcatalog"
        exit 1
      fi
    fi

    #Check for Hbase
    if [ 'yes' == "$installhbase" ]; then
      checkZookeeperDependencies
      if [ "$?" -ne "0" ]; then
        echo0 "Hbase requires Zookeeper, please set appropriate settings."
        dumpErrorExitStatus "INIT" "Cannot install hbase without zookeeper"
        exit 1
      fi
    fi

    #if we are doing an rpm install make sure hadoop is found before we procced
    if [ 'rpm' == "$package" ]; then
      #check if hadoop rpm's are found or not
      if [ $OS_SLES == "$SYSTEM_OS" ]; then
        local cmd="zypper search hadoop"
      else
        local cmd="yum search hadoop"
      fi

      #check if the gateway can find hadoop rpm
      ssh2host $gwhost "$cmd"
      if [ $? -ne 0 ]; then
        echo0 "hadoop packages were not found. Command -> $cmd on host $gwhost did not find hadoop."
        exit 1
      fi
    fi
  }

  ############################################################
  # FUNCTION TO set Install Dependencies
  ############################################################
  setInstallDependencies() {

    #only enable snappy for rpm
    if [ 'rpm' == "$package" ]; then
      enablesnappy=yes
    else
      enablesnappy=no
    fi

    #enable zookeeper if templeton or hbase are being installed
    if [ 'yes' == "$installhbase" ] || [ 'yes' == "$installtempleton" ]; then
      installzk=yes
    else
      installzk=no
    fi

    #install pdsh
    cmd="$installpkgcmd pdsh"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1

    # Check if pdsh is available
    pdsh_path=`which pdsh`
    ret=$?
    if [[ "$ret" == "0" ]]; then
      usepdsh=yes
      #use pdsh to ssh to the gateway and make sure you get a non zero
      #return code
      pdshExec $gwhost $deployuser "whoami" >> $outlog 2>&1
      if [ $? -ne 0 ]; then
        echo "pdsh command did not run successfully, setting use pdsh to no" >> $outlog 2>&1
        usepdsh=no
      else
        echo "using pdsh for deploy" >> $outlog 2>&1
      fi
    else
      usepdsh=no
    fi
  }

  ############################################################
  # FUNCTION TO Check Zookeeper dependencies
  ############################################################
  checkZookeeperDependencies() {
    #make sure the hosts are populated
    if [ "x${zkhosts}x" == "xx" ]; then
      echo0 "Zookeeper hosts must be defined in zknodes file."
      return 1
    fi

    #make sure all the zk properties are set
    if [ "x${zk_log_dir}x" == "xx" ] || [ "x${zk_pid_dir}x" == "xx" ] || [ "x${zk_data_dir}x" == "xx" ] || [ "x${zkuser}x" == "xx" ]; then
      echo0 "Zookeeper install properties missing: zk_log_dir or zk_pid_dir or zk_data_dir or zkuser is/are empty. Make sure they are set"
      return 1
    fi
    return 0
  }
  ###########################
  # Function to stop the iptables
  ###########################
  function stopIptables {
    #if on sles dont run it
    if [[ "$SYSTEM_OS" == "$OS_SLES" ]]; then
      return
    fi
    echo0 "Stop iptables"
    ssh2host "`echo $allhosts_with_mon | tr ' ' ','`" "/etc/init.d/iptables stop"
  }
  
  ###########################
  # Turn of selinux
  ###########################
  function turnOffSelinux {
    #if on sles dont run it
    if [[ "$SYSTEM_OS" == "$OS_SLES" ]]; then
      return
    fi
    echo0 "Turning off selinux"
    ssh2host "`echo $allhosts_with_mon | tr ' ' ','`" "sed -i 's|SELINUX=enforcing|SELINUX=disabled|g' /etc/selinux/config ; /usr/sbin/setenforce 0"
  }

  ######################################################
  # Function to set up the epel RPM repo (needed on AWS) 
  ######################################################
  function setupEpel {
    #if on sles dont run it
    if [[ "$SYSTEM_OS" == "$OS_SLES" ]]; then
      return
    fi
    local epel5_rpm="${BASE_UTILS_URL_W_OS}/epel-release-5-4.noarch.rpm"
    local epel6_rpm="${BASE_UTILS_URL_W_OS}/epel-release-6-7.noarch.rpm"
    local rpm_url
    case "${SYSTEM_OS}${OS_VERSION}" in
      ${OS_CENTOS}5)
        rpm_url=$epel5_rpm
      ;;
      ${OS_CENTOS}6)
        rpm_url=$epel6_rpm
      ;;
      *)
        echo "OS not supported for epel repo: ${SYSTEM_OS}${OS_VERSION} "
        return
      ;;
    esac
    echo0 "Setting up the epel RPM repo"
    ssh2host "`echo $allhosts_with_mon | tr ' ' ','`" "rpm -Uvh $rpm_url ; $cleanrepocmd"
  }

  ###########################
  # Install hortownworks repository
  ###########################
  function installHDPRepo {
    echo0 "Installing HDP repository"
    #install the repo file, via wget as hdp-release rpm will not work for local mirror repository.
    if [[ "$SYSTEM_OS" == "$OS_SLES" ]]; then
     cmd="wget -nv $REPO_FILE -O /etc/zypp/repos.d/hdp.repo; $cleanrepocmd"
     echo "$cmd"
   else
     cmd="wget -nv $REPO_FILE -O /etc/yum.repos.d/hdp.repo; $cleanrepocmd"
     echo "$cmd"
    fi
    ssh2host "`echo $allhosts_with_mon | tr ' ' ','`" "$cmd"
  }

  ###################################
  ### SETUP REPO FOR CENTOS
  ###################################
  setupRepo () {
    #add a little wait just to make sure yum is all ready to go
    sleep 5
    local PreReqMirrorHostname=`hostname -f`
    local outfile=/etc/yum.repos.d/hdp.repo
    local outdir=$PWD/preReqOutDir
    local hdp_repo_id="HDP-$HDPVersion"
    local hdp_util_repo_id="HDP-UTILS-${HDPVersion}"
    local baseurl="http://${PreReqMirrorHostname}/rpms"
    local repo_file="${outdir}/hdp.repo"
    local rpm_root="/var/www/html/rpms"

    local cmd="mkdir -p $rpm_root"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
  
    local cmd="rm -rf $outdir ; mkdir -p $outdir"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
  
    local cmd="yum install -y yum-utils createrepo wget httpd"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
  
    local cmd="/etc/init.d/httpd start"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
  
    local cmd="wget $REPO_FILE -O $outfile"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
  
    cd "$outdir"
    local cmd="reposync -r $hdp_repo_id"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
  
    local cmd="createrepo $hdp_repo_id"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
  
    local cmd="rm -rf ${rpm_root}/${hdp_repo_id};cp -r $hdp_repo_id ${rpm_root}/."
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    local cmd="reposync -r $hdp_util_repo_id"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
  
    local cmd="createrepo $hdp_util_repo_id"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
  
    local cmd="rm -rf ${rpm_root}/${hdp_util_repo_id};cp -r ${hdp_util_repo_id} ${rpm_root}/."
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
  
  
    cat $outfile > $repo_file
    #update base url
    sed -i "s|baseurl.*${hdp_repo_id}.*|baseurl=${baseurl}/${hdp_repo_id}|g" $repo_file
    sed -i "s|baseurl.*${hdp_util_repo_id}.*|baseurl=${baseurl}/${hdp_util_repo_id}|g"  $repo_file
  
    #turn of gpg check
    sed -i "s|gpgcheck.*=.*|gpgcheck=0|g" $repo_file
    
    local hosts=`echo $allhosts_with_mon | tr ' ' ','`
    scp2host $hosts $repo_file
    ssh2host $hosts "rm -f $outfile;cp ${destdir}/hdp.repo $outfile ; $cleanrepocmd"
  
    echo0 "Local repo setup at -> $baseurl"
    #add a little wait just to make sure yum is all ready to go
    sleep 5
  }

  ###################################
  ### SETUP REPO FOR SUSE
  ###################################
  setupRepoSuse () {
    #add a little wait just to make sure yum is all ready to go
    sleep 5
    
    #variables for local mirror repo creation
    local yum_client="/tmp/yum_client"  # for downloading the yum client rpm's
    local apache_doc_root="/srv/www/htdocs"   # apache doc root folder
    local rpm_root="${apache_doc_root}/rpms"
    local outdir=$PWD/preReqOutDir
    local PreReqMirrorHostname=`hostname -f`
    local yum_repo_file="/etc/yum/repos.d/hdp.repo"
    local outfile="/etc/zypp/repos.d/hdp.repo"
    local hdp_repo_id="HDP-$HDPVersion"
    local hdp_util_repo_id="HDP-UTILS-${HDPVersion}"
    local baseurl="http://${PreReqMirrorHostname}/rpms"
    local repo_file="${outdir}/hdp.repo"
    
    #install all the required package for yum repo creation.
    local cmd="$installpkgcmd apache2 apache2-prefork apache2-utils python-curl python-gobject2 python-gpgme python-urlgrabber python-iniparse wget curl yum-metadata-parser yum yum-updatesd yum-utils createrepo"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    # downloading the hdp.repo  from repo to local yum client location /etc/yum/repos.d/hdp.repo
    local cmd="wget -nv ${REPO_FILE} -O $yum_repo_file ; $cleanrepocmd"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    local cmd="mkdir -p $rpm_root"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
  
    local cmd="rm -rf $outdir ; mkdir -p $outdir"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    
    # modifying the  default-server.conf to enable the docs root folder listing. This has to be done once apache is installed.
    local cmd='sed -e "s/Options None/Options Indexes MultiViews/ig" /etc/apache2/default-server.conf > /tmp/tempfile.tmp'
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    local cmd="mv /tmp/tempfile.tmp /etc/apache2/default-server.conf"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    cd $outdir
    local cmd="reposync -r ${hdp_repo_id}"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    # local repo creation 
    local cmd="createrepo ${hdp_repo_id}"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    local cmd="rm -rf ${rpm_root}/${hdp_repo_id};cp -r $hdp_repo_id ${rpm_root}/."
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    local cmd="reposync -r ${hdp_util_repo_id}"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    # local repo creation 
    local cmd="createrepo ${hdp_util_repo_id}"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    local cmd="rm -rf ${rpm_root}/${hdp_util_repo_id};cp -r $hdp_util_repo_id ${rpm_root}/."
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    # starting the webserver
    local cmd="/etc/init.d/apache2 restart"
    echo0 $cmd
    eval $cmd >> $outlog 2>&1
    
    cat $yum_repo_file > $repo_file
    #update the base url
    sed -i "s|baseurl.*${hdp_repo_id}.*|baseurl=${baseurl}/${hdp_repo_id}|g" $repo_file
    sed -i "s|baseurl.*${hdp_util_repo_id}.*|baseurl=${baseurl}/${hdp_util_repo_id}|g"  $repo_file
    
    #turn of gpg check
    sed -i "s|gpgcheck.*=.*|gpgcheck=0|g" $repo_file
  
    local hosts=`echo $allhosts_with_mon | tr ' ' ','`
    scp2host $hosts $repo_file
    ssh2host $hosts "rm -f $outfile;cp ${destdir}/hdp.repo $outfile ; $cleanrepocmd"
  
    echo0 "Local repo setup at -> $baseurl"
  
    #delete the yum file
    rm -f $yum_repo_file
    #add a little wait just to make sure yum is all ready to go
    sleep 5
  }

  ############################################################
  #HOSTDETAILS
  ############################################################
  [[ -f "gateway" ]] && gwhost=$(cat gateway  | tr '[:upper:]' '[:lower:]')
  [[ -f "namenode" ]] && nnhost=$(cat namenode | tr '[:upper:]' '[:lower:]')
  [[ -f "snamenode" ]] && snhost=$(cat snamenode | tr '[:upper:]' '[:lower:]')
  [[ -f "jobtracker" ]] && jthost=$(cat jobtracker | tr '[:upper:]' '[:lower:]')
  [[ -f "hbasemaster" ]] && hbmhost=$(cat hbasemaster | tr '[:upper:]' '[:lower:]')
  [[ -f "hivemetastore" ]] && hivehost=$(cat hivemetastore | tr '[:upper:]' '[:lower:]')
  [[ -f "templetonnode" ]] && ttonhosts=$(cat templetonnode | tr '[:upper:]' '[:lower:]')
  [[ -f "oozieserver" ]] && oozieshost=$(cat oozieserver | tr '[:upper:]' '[:lower:]')
  [[ -f "nodes" ]] && slaves=$(cat nodes | tr '[:upper:]' '[:lower:]')
  [[ -f "hbasenodes" ]] && rshosts=$(cat hbasenodes | tr '[:upper:]' '[:lower:]')
  [[ -f "zknodes" ]] && zkhosts=$(cat zknodes | tr '[:upper:]' '[:lower:]')
  [[ -f "gangliaserver" ]] && gangliahost=$(cat gangliaserver | tr '[:upper:]' '[:lower:]')
  [[ -f "nagiosserver" ]] && nagioshost=$(cat nagiosserver | tr '[:upper:]' '[:lower:]')
  # Until Ganglia itself provides support to the contrary, ${gangliaweb} MUST be the same as ${gangliahost}
  gangliaweb=${gangliahost}
  [[ -f "dashboardhost" ]] && dashboardhost=$(cat dashboardhost | tr '[:upper:]' '[:lower:]')

  allhosts="gateway namenode snamenode jobtracker nodes"
  [[ "$installhbase" == "yes" ]] && allhosts="${allhosts} hbasemaster hbasenodes zknodes"
  [[ "$installhive" == "yes" ]] && allhosts="${allhosts} hivemetastore"
  [[ "$installtempleton" == "yes" ]] && allhosts="${allhosts} templetonnode zknodes"
  [[ "$installoozie" == "yes" ]] && allhosts="${allhosts} oozieserver"

  #all hosts with monitoring hosts
  allhosts_with_mon=$allhosts
  [[ "$enablemon" == "yes" ]] && allhosts_with_mon="${allhosts_with_mon} gangliaserver nagiosserver dashboardhost"

  #sort and get unique values
  allhosts="$(cat $allhosts | sort | uniq  | tr '[:upper:]' '[:lower:]')"
  allhosts_with_mon="$(cat $allhosts_with_mon | sort | uniq  | tr '[:upper:]' '[:lower:]')"

  datanodes_count=0
  tasktrackers_count=0
  hbaseregionservers_count=0
  if [[ "$slaves" != "" ]]; then
    tmp_nodes_array=( $slaves )
    datanodes_count=${#tmp_nodes_array[*]}
    tasktrackers_count=${#tmp_nodes_array[*]}
  fi
  if [[ "$rshosts" != "" ]]; then
    tmp_nodes_array=( $rshosts )
    hbaseregionservers_count=${#tmp_nodes_array[*]}
  fi

  modifyvarsforos
