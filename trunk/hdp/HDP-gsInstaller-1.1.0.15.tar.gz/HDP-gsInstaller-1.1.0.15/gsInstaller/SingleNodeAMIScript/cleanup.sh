LOCIP=` /sbin/ifconfig eth0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'`
hostname $LOCIP


matching_exp="hortonworks-sandbox.localdomain"
etc_hostname=`hostname -i`

LOCIP="11.38.109.172"


command="`echo "sed '/${matching_exp}/s/${etc_hostname}/${LOCIP}/g' /etc/hosts"`"
eval  ${command} |  tee /tmp/hosts_mod > /dev/null
cat /tmp/hosts_mod |  tee /etc/hosts > /dev/null
rm -rf /tmp/hosts_mod

cat /etc/hosts

umount /dev/sdb /dev/sdc

rm -rf /usr/jre32 /usr/jre64

rm -rf /usr/hadoop-jdk1.6.0_31
rm -rf /usr/zookeeper-jdk1.6.0_31
rm -rf /usr/hbase-jdk1.6.0_31
rm -rf /usr/oozie-jdk1.6.0_31

rm -rf /etc/ssh/ssh_host_*
rm -rf ~/.ssh
/etc/init.d/sshd restart
rm -rf ~/hdp-*
