#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

basedir=`dirname $0`;
if [ x$basedir = "x." ]
then
    basedir=`pwd`
fi

source ${basedir}/gsInstaller.properties

JAVA_HOME=${java64home}
PATH=${JAVA_HOME}/bin:$PATH:$HOME/bin
export PATH

sleep_value=20
line="500"
HOSTNAME=`hostname`

JavaProcess() {
	echo
	echo
	echo "****************          Java Process            ***************"
	ps auxwwwf | grep java | grep -v grep | awk '{print $2,$1,$12}' | sort
	echo
	echo
	#eval ${basedir}/JpsFormatedOutput.sh
	#echo "****************          JPS result            ***************"
	# /usr/hadoop-jdk1.6.0_26/bin/jps -m  | grep -v "Jps -m"
	#eval ${basedir}/JpsFormatedOutput.sh
}


echo "###############		STOPPING ALL THE SERVICES		##############"

StoppingHbaseRegionservers() {
	echo "###############           Stopping Hbase Regionservers               ##############"
	su -l hbase -c "/usr/lib/hbase/bin/hbase-daemon.sh --config  /etc/hbase/conf stop regionserver"
}

StoppingSingleDataNode() {
	echo "###############           Stopping hdfs Datanodes               ##############"
	su -l hdfs -c "/usr/lib/hadoop/bin/hadoop-daemon.sh --config /etc/hadoop/conf stop datanode"
}

StoppingTaskTrackers() {
	echo "###############           Stopping MapReduce Tasktracker               ##############"
	su -l mapred -c "/usr/lib/hadoop/bin/hadoop-daemon.sh --config /etc/hadoop/conf stop tasktracker"
}

StoppingZookeeperNodes() {
	echo "###############           Stopping Zookeeper Server               ##############"
	su -l zookeeper -c "source /etc/zookeeper/conf/zookeeper-env.sh; export ZOOCFGDIR=/etc/zookeeper/conf;/usr/lib/zookeeper/bin/zkServer.sh stop >> ${zk_log_dir}/zoo.out 2>&1"
}

StoppingSecondaryNameNode() {
	echo "###############           Stopping Secondary Name Node               ##############"
	su -l hdfs -c "/usr/lib/hadoop/bin/hadoop-daemon.sh --config /etc/hadoop/conf stop secondarynamenode"
}

StoppingNameNode() {
	echo "###############           Stop the name node               ##############"
	su -l hdfs -c "/usr/lib/hadoop/bin/hadoop-daemon.sh --config /etc/hadoop/conf stop namenode"
}


StoppingHistoryServer() {
	echo "###############           Stopping MapReduce HistoryServer Components               ##############"
	su -l mapred -c "/usr/lib/hadoop/bin/hadoop-daemon.sh --config /etc/hadoop/conf stop historyserver"
}

StoppingJobTracker() {
	echo "###############           Stopping MapReduce JobTracker Components               ##############"
	su -l mapred -c "/usr/lib/hadoop/bin/hadoop-daemon.sh --config /etc/hadoop/conf stop jobtracker"
}

StoppingHbaseMaster() {
	echo "###############           Stopping Hbase Master               ##############"
	su -l hbase -c "/usr/lib/hbase/bin/hbase-daemon.sh --config /etc/hbase/conf stop master"
	#tail -$line  ${hbase_log_dir}/hbase-hbase-master-${HOSTNAME}.log
}

StoppingHiveServer() {
	echo "###############           Stopping the Hive Server               ##############"
	su -l hive -c "kill -9 `ps aux | grep hive | grep hive_contrib.jar | grep -v grep | awk '{print $2}'`"
}

StoppingOozieServer() {
	echo "###############           Stopping the Oozie Server               ##############"
	su -l oozie -c "/usr/lib/oozie/bin/oozie-stop.sh"
}

StoppingTempeltonServer() {
	echo "###############           Stopping Tempelton Server               ##############"
	su -l templeton -c "env TEMPLETON_HOME=/etc/templeton/   /usr/sbin/templeton_server.sh stop"
}

StoppingNagiosandSnmpdServices() {
	#echo "Starting the nagios and snmpd"
	/etc/init.d/snmpd stop
	/etc/init.d/nagios stop
}

StoppingGangliaServices() {
	#echo "Starting the Ganglia Services"
	/etc/init.d/hdp-gmond stop
	/etc/init.d/hdp-gmetad stop
	/etc/init.d/httpd stop
}



JavaProcess
StoppingHbaseRegionservers
StoppingSingleDataNode
StoppingTaskTrackers
StoppingZookeeperNodes
StoppingSecondaryNameNode
StoppingNameNode
StoppingHistoryServer
StoppingJobTracker
StoppingHbaseMaster
StoppingHiveServer
StoppingOozieServer
StoppingTempeltonServer
StoppingNagiosandSnmpdServices
StoppingGangliaServices
JavaProcess
