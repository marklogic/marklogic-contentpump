#!/bin/bash

NOW=$(date +"%m-%d-%Y-%H-%M-%S")
LOGFILE="/root/hdp-mount-drive-$NOW.log"
exec 2>&1
{

mount_dir="/hdp"
count=0
hdp="HDP"
hdp_mount="data"
sd_block_files="/dev/sd*"
#xvd_block_files="/dev/xvd*"
directory=""
block_files="ls ${sd_block_files} ${xvd_block_files}"
echo "************************************************************************"
for var in $($block_files 2>/dev/null); do 
df -h | grep $var > /dev/null 2>&1
return_value=$?
if [ $return_value -eq 0 ]; then
   echo "$var block is mounted"
else
   echo
   echo
   echo "$var block is not mounted"
   directory="$mount_dir/disk${count}/${hdp_mount}"
      echo "$var block is not mounted ===>  Creating the directory $directory"
      if [ -d ${directory} ]; then 
      	cd ${directory}; tar zcpf /tmp/${hdp}_disk${count}.tar.gz ${hdp};cd -
      	mkdir -p $directory
      	echo "mounting the directory $var on $directory"
      	mount $var $directory 
      	rm -rf ${directory}/${hdp}
      	tar zpxf /tmp/${hdp}_disk${count}.tar.gz -C ${directory}
      	rm -rf /tmp/${hdp}_disk${count}.tar.gz
      	((count=count+1))
      fi
fi
echo "#######################################################################################################################"
done

echo "==========================================================="
df -h
echo "Script executed, check the log file ${LOGFILE}  for details and exceptions, if any."
} | tee -a ${LOGFILE}
