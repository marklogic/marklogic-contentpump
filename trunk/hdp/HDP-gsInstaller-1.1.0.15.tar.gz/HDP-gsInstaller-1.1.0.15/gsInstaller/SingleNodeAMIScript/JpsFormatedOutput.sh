#! /bin/bash
#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

basedir=`dirname $0`;
if [ x$basedir = "x." ];then
    basedir=`pwd`
fi

HADOOP_PROCESS="NameNode SecondaryNameNode DataNode JobTracker JobHistoryServer TaskTracker RunJar Bootstrap QuorumPeerMain HRegionServer HMaster"
# ps auxwwwf | grep java | grep -v grep | awk '{print $2,$1,$12}' | sort ;echo ; jps -m | sort| grep -v Jps
#jps_command="jps -m | sort | grep -v 'Jps -m'"
#rm -rf ${basedir}/jps_output
#eval  ${jps_command} |  tee ${basedir}/jps_output > /dev/null
#cat ${basedir}/jps_output
#echo "**************************************"

check_process()
{
	PROCESS=$1
        process_details=`eval  jps -m | sort | grep -v 'Jps -m' | grep -w ${PROCESS}`
	if [ "x$process_details" != "x" ] ; then
		echo "$process_details" | while IFS= read -r line
		do	
		process_id=`echo ${line} | cut -d" " -f1`
        	process_name=`echo ${line} | cut -d" " -f2`
                if [ "${process_name}" == "RunJar" ] ;then
			process_details=`echo ${line} | cut -d" " -f3`
                        echo ${process_details} | grep "templeton" > /dev/null
                        if [ $? -eq 0 ]; then
                                echo -e "Process ID = ${process_id}\tUser = ` ps auxwwwf | grep ${process_id} | grep -v grep | awk '{print $1}'`\tProcess Name = ${process_name}              Process Description = It's Templeton process ${process_details}"
                        fi
                        echo ${process_details} | grep "hcatalog" > /dev/null
                        if [ $? -eq 0 ]; then
                                echo -e "Process ID = ${process_id}\tUser = ` ps auxwwwf | grep ${process_id} | grep -v grep | awk '{print $1}'`\tProcess Name = ${process_name}              Process Description = It's Hacatalog process ${process_details}"
                        fi
                elif [ "${process_name}" == "QuorumPeerMain" ] ;then
                        process_details=`echo ${line}  | cut -d" " -f3`
                        echo ${process_details} | grep "zookeeper" > /dev/null
                        if [ $? -eq 0 ]; then
                                echo -e "Process ID = ${process_id}\tUser = ` ps auxwwwf | grep ${process_id} | grep -v grep | awk '{print $1}'`\tProcess Name = ${process_name}      Process Description = It's Zookeeper process ${process_details}"
		fi

                else
                        echo -e "Process ID = $process_id\tUser = ` ps auxwwwf | grep ${process_id} | grep -v grep | awk '{print $1}'`\tProcess_Name = ${process_name}"
                fi

	done
	else
		if [ "${PROCESS}" == "QuorumPeerMain"  ];then
			echo "Zookeeper  Process has not been started"
		elif [ "${PROCESS}" == "RunJar" ] ;then
			echo "Either Templeton or Hcatlaog has not been started"
		else
			echo "$PROCESS ====>  Process has not been started"
		fi
	fi
}


for processlist in $HADOOP_PROCESS
        do
        check_process $processlist
        if [ $? != 0 ]; then
                echo "*******$processlist =====>  Process has not been started"
        fi
done

