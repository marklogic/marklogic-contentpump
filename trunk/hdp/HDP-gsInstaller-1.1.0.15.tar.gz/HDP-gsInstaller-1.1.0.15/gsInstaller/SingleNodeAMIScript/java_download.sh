#! /bin/bash
#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

basedir=`dirname $0`;
if [ x$basedir = "x." ];then
    basedir=`pwd`
fi

NOW=$(date +"%m-%d-%Y-%H-%M-%S")
LOGFILE="/root/hdp-java-download-$NOW.log"
#exec 1>>${LOGFILE} 2>&1
exec 2>&1
{
  usr_folder="/usr"
  jre_folder_name="jre1.6.0_31"
  jdk_folder_name="jdk1.6.0_31"
  java32="/usr/jre32"
  java64="/usr/jre64"

  java32_url="http://javadl.sun.com/webapps/download/AutoDL?BundleId=59621"
  java32_jre_name="jre-6u31-linux-i586.bin"

  java64_url="http://javadl.sun.com/webapps/download/AutoDL?BundleId=59623"
  java64_jre_name="jre-6u31-linux-x64.bin"

  java32home=${java32}/${jre_folder_name}
  java64home=${java64}/${jre_folder_name}

  soft_link_hcat="hcat-${jdk_folder_name}"
  soft_link_hadoop="hadoop-${jdk_folder_name}"
  soft_link_zookeeper="zookeeper-${jdk_folder_name}"
  soft_link_hbase="hbase-${jdk_folder_name}"
  soft_link_templeton="templeton-${jdk_folder_name}"
  soft_link_oozie="oozie-${jdk_folder_name}"
  
  #hadoop-jdk1.6.0_26 -> /usr/jre64/jre1.6.0_31
  #zookeeper-jdk1.6.0_26 -> /usr/jre32/jre1.6.0_31
  #hbase-jdk1.6.0_26 -> /usr/jre64/jre1.6.0_31
  #hcat-jdk1.6.0_26 -> /usr/jre64/jre1.6.0_31
  #templeton-jdk1.6.0_26 -> /usr/jre32/jre1.6.0_31
  #oozie-jdk1.6.0_26 -> /usr/jre32/jre1.6.0_31
  
  #hadoop-jdk1.6.0_31 -> /usr/jre64/jre1.6.0_31
  #zookeeper-jdk1.6.0_31 -> /usr/jre32/jre1.6.0_31
  #hbase-jdk1.6.0_31 -> /usr/jre64/jre1.6.0_31
  #oozie-jdk1.6.0_31 -> /usr/jre32/jre1.6.0_31
   
  if [ ! -d ${java32} ] || [ ! -d ${java64} ]; then

    if [ ! -d ${java32} ]; then
       echo "***** ${java32} does not exist, hence downloading the jre and configuring accordingly."
       mkdir -p ${java32}
       cd ${java32}
       echo "Downloading the ${java32_jre_name} from ${java32_url}"
       sleep 3
       echo
       echo
       wget ${java32_url} -O ${java32}/${java32_jre_name}; 
       echo;echo
       echo "Installing the ${java32_jre_name}"
       echo
       echo
       sh ${java32_jre_name} > /dev/null 
       rm -rf ${java32_jre_name}

       cd ${usr_folder}
       rm -rf ${soft_link_zookeeper} ${soft_link_templeton} ${soft_link_oozie}

       echo "Creating the Soft Links for the required components"
       echo
       echo
       #ln -sv ${java32home} ${usr_folder}/${soft_link_templeton}
       ln -sv ${java32home} ${usr_folder}/${soft_link_oozie}
       ln -sv ${java32home} ${usr_folder}/${soft_link_zookeeper}
       echo
       echo
    fi

    if [ ! -d ${java64} ]; then
       echo "***** ${java64} does not exist, hence downloading the jre and configuring accordingly."
       mkdir -p ${java64}
       cd ${java64}
       echo "Downloading the ${java64_jre_name} from ${java64_url}"
       sleep 3
       wget ${java64_url} -O ${java64}/${java64_jre_name}; 
       echo "Installing the ${java64_jre_name}"
       echo
       echo
       sh ${java64_jre_name} > /dev/null
       rm -rf ${java64_jre_name}

       cd ${usr_folder}
       rm -rf ${soft_link_hcat} ${soft_link_hadoop} ${soft_link_hbase}

       echo "Creating the Soft Links for the required components"
       echo
       echo
       #ln -sv ${java64home} ${usr_folder}/${soft_link_hcat}
       ln -sv ${java64home} ${usr_folder}/${soft_link_hadoop}
       ln -sv ${java64home} ${usr_folder}/${soft_link_hbase}

    fi
    echo
    echo
    echo "Script executed, check the log file ${LOGFILE}  for details and exceptions, if any."
 else
    echo "${java32} and ${java64} exist, so no jre download has been performed"
 fi
} | tee -a ${LOGFILE}

