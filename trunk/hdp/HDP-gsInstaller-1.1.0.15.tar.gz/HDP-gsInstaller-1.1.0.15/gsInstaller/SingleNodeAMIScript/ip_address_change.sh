#! /bin/bash
#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

basedir=`dirname $0`;
if [ x$basedir = "x." ]
then
    basedir=`pwd`
fi
source ${basedir}/gsInstaller.properties

matching_exp="hortonworks-sandbox.localdomain"

cmd="/usr/bin/curl -m 5 -s http://169.254.169.254/latest/meta-data/local-ipv4"
local_private_ip=`eval $cmd`
ret=$?
if [[ "$ret" == "0" ]]; then
  
	echo "It's Amazon instance"
  	if [ `hostname` != ${matching_exp} ]; then
     		echo "Setting Hostname As hortonworks-sandbox.localdomain for the HDP Stack"
     		hostname hortonworks-sandbox.localdomain
		echo "Hostname === `hostname`"
     		etc_hostname=`hostname -i`  ## This will return the ip address for the set hostname from the /etc/hosts file.
  		LOCIP=` /sbin/ifconfig eth0 | grep 'inet addr:' | cut -d: -f2 | awk '{ print $1}'`   ## This will return the actual dhcp ip address of the machine.
  		PUBIP=`/usr/bin/curl -s http://169.254.169.254/latest/meta-data/public-ipv4`
  		#LOCIP=`/usr/bin/curl -s http://169.254.169.254/latest/meta-data/local-ipv4`
  		if [ "${etc_hostname}" == "${LOCIP}" ]; then
        		echo "ip address matches, no need to modify the /etc/hosts file with the new Private Ip for the hostname ${matching_exp}"
  		else
			echo "ip address does not matches as per the /etc/hosts and local-ipv4, hence modifying the /etc/hosts with new local-ipv4"
        		command="`echo "sed '/${matching_exp}/s/${etc_hostname}/${LOCIP}/g' /etc/hosts"`"
        		eval  ${command} |  tee /tmp/hosts_mod > /dev/null
        		cat /tmp/hosts_mod |  tee /etc/hosts > /dev/null
        		rm -rf /tmp/hosts_mod
  		fi
		cat /etc/hosts
		echo "Private Local IP = ${LOCIP}"
 		echo "Public IP = ${PUBIP}"
		if [ ! -f /root/.ssh/id_rsa ]; then
			ssh-keygen -q -N '' -t rsa -f /root/.ssh/id_rsa
                	cat /root/.ssh/id_rsa.pub >> /root/.ssh/authorized_keys
			ssh-keyscan -t rsa `hostname`,`hostname -i` >> /root/.ssh/known_hosts
			ssh-keyscan -t rsa localhost.localdomain,127.0.0.1 >> /root/.ssh/known_hosts
		else
			echo "ssh keys are present, not regenerating it"
		fi
	else
		echo " HostName is correct, hence no modification required."
  	fi
else
  echo "it's Virtual Instance"
fi

