#! /bin/bash
#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

#JAVA_HOME="/usr/jdk64/jdk1.6.0_26"

basedir=`dirname $0`;
if [ x$basedir = "x." ]
then
    basedir=`pwd`
fi
source ${basedir}/gsInstaller.properties

JAVA_HOME=${java64home}
PATH=${JAVA_HOME}/bin:$PATH:$HOME/bin
export PATH

sleep_value=30
line="500"
HOSTNAME=`hostname`

StartingNameNode() {
	echo
	echo
	echo "****************		Starting Hdfs Components Like Namenode, Secondary Namenode and Data nodes		***************"
	echo "****************          Starting Name Node            ***************"
	su -l hdfs -c "rm -rf ${log_dir}/hdfs/hadoop-hdfs-namenode-*"
	su -l hdfs -c "/usr/lib/hadoop/bin/hadoop-daemon.sh --config /etc/hadoop/conf start namenode"
	sleep ${sleep_value}
	su -l hdfs -c "tail -$line  ${log_dir}/hdfs/hadoop-hdfs-namenode-${HOSTNAME}.log"
}

StartingSecondaryNameNode() {
	echo
	echo
	echo "****************          Starting Secondary Name Node            ***************"
	su -l hdfs -c "rm -rf ${log_dir}/hdfs/hadoop-hdfs-secondarynamenode-*"
	su -l hdfs -c "/usr/lib/hadoop/bin/hadoop-daemon.sh --config /etc/hadoop/conf start secondarynamenode"
	sleep ${sleep_value}
	su -l hdfs -c "tail -$line  ${log_dir}/hdfs/hadoop-hdfs-secondarynamenode-${HOSTNAME}.log"
	echo
	echo
}

StartingSingleDataNode() {
	echo "****************          Starting Single Data Node            ***************"
	su -l hdfs -c "rm -rf ${log_dir}/hdfs/hadoop-hdfs-datanode-*"
	su -l hdfs -c "/usr/lib/hadoop/bin/hadoop-daemon.sh --config /etc/hadoop/conf start datanode"
	sleep ${sleep_value}
	su -l hdfs -c "tail -$line  ${log_dir}/hdfs/hadoop-hdfs-datanode-${HOSTNAME}.log"
	echo
	echo
	echo "###########################################################################################################################################################"
	echo "Putting the sleep of Approx 5 min, as namenode might be in safe mode. Safe mode will get over provided it has recieved the block information from datanodes"
	Color2=`tput setab 6`        # Cyan  background color for date
	tput init
	LIMIT=0
	var=300
	COUNT=$var
	until (( var < LIMIT ))
	do
        #tput clear
        #tput sc
        #echo -en "$(tput clear)$Color2${bold}$var sec completed  `sudo su -l hdfs -c "/usr/bin/hadoop --config /etc/hadoop dfsadmin -safemode get"`"
        value=`su -l hdfs -c "/usr/bin/hadoop --config /etc/hadoop/conf dfsadmin -safemode get"`
        ret=$?
        #echo $ret
        #echo $value
        if [ "$value" == "Safe mode is OFF" ]
        then
        tput sc
        echo -en "Namenode has come out of safe mode in `expr $COUNT - $var` seconds"
        tput rc
        sleep 2
        echo
        echo
        break
        fi
        tput sc
        #echo -en "$(tput clear)$Color2${bold}$var${offbold} sec left"
        #echo -en "${value} Still Checking the status $Color2${bold}$var${offbold} sec left."
        echo -en "${value} Still Checking the status ${bold}$var${offbold} sec left."
        tput rc
        sleep 1
        ((var--))
	done
}

StartingJobTracker() {
	echo
	echo
	echo "****************          Starting MapReduce Components Like Jobtracker Historyserver And Tasktracker            ***************"
	echo
	echo
	echo "****************          Starting Job Tracker            ***************"
	su -l mapred -c "rm -rf ${log_dir}/mapred/hadoop-mapred-jobtracker-*"
	su -l mapred -c "/usr/lib/hadoop/bin/hadoop-daemon.sh --config /etc/hadoop/conf start jobtracker"
	sleep ${sleep_value}
	su -l mapred -c "tail -$line  ${log_dir}/mapred/hadoop-mapred-jobtracker-${HOSTNAME}.log"
}

StartingHistoryServer() {
	echo
	echo
	echo "****************          Starting History Server            ***************"
	su -l mapred -c "rm -rf ${log_dir}/mapred/hadoop-mapred-historyserver-*"
	su -l mapred -c "/usr/lib/hadoop/bin/hadoop-daemon.sh --config /etc/hadoop/conf start historyserver"
	sleep ${sleep_value}
	su -l mapred -c "tail -$line  ${log_dir}/mapred/hadoop-mapred-historyserver-${HOSTNAME}.log"
}

StartingTaskTrackers() {
	echo
	echo
	echo "****************          Starting Task Trackers            ***************"
	su -l mapred -c "rm -rf ${log_dir}/mapred/hadoop-mapred-tasktracker-*"
	su -l mapred -c "/usr/lib/hadoop/bin/hadoop-daemon.sh --config /etc/hadoop/conf start tasktracker"
	sleep ${sleep_value}
	su -l mapred -c "tail -$line  ${log_dir}/mapred/hadoop-mapred-tasktracker-${HOSTNAME}.log"
	echo
	echo
}

StartingHiveServer() {
	echo "****************          Starting Hive Server            ***************"
	su -l  hive -c "nohup hive --service metastore >${hive_log_dir}/hive.out 2> ${hive_log_dir}/hive.log &"
	sleep ${sleep_value}
	su -l  hive -c "tail -$line ${hive_log_dir}/hive.log"
	su -l  hive -c "tail -$line ${hive_log_dir}/hive.out"
	echo "Hive Process `ps aux | grep hive | grep hive_contrib.jar | grep -v grep | awk '{print $2,$1,$12}'`"
	echo
	echo
}

StartingOozieServer() {
	echo "****************          Starting Oozie Server            ***************"
	su -l oozie -c "rm -rf ${oozie_log_dir}/*"
	su -l oozie -c "/usr/lib/oozie/bin/oozie-start.sh"
	echo
	echo
}

StartingZookeeperNodes() {
	echo "****************          Starting Zookeeper Nodes            ***************"
	su -l zookeeper -c "rm -rf ${zk_log_dir}/zoo.out" 
	su -l zookeeper -c "source /etc/zookeeper/conf/zookeeper-env.sh; export ZOOCFGDIR=/etc/zookeeper/conf; /usr/lib/zookeeper/bin/zkServer.sh start >> ${zk_log_dir}/zoo.out 2>&1"
	su -l zookeeper -c "cat ${zk_log_dir}/zoo.out"
}

StartingHbaseRegionservers() {
	echo
	echo
	echo "****************          Starting Hbase Components            ***************"
	echo
	echo
	echo "****************          Starting Hbase Regionservers            ***************"
	su -l hbase -c "rm -rf ${hbase_log_dir}/hbase-hbase-regionserver-*"
	su -l hbase -c "/usr/lib/hbase/bin/hbase-daemon.sh --config /etc/hbase/conf start regionserver"	
	sleep ${sleep_value}
	su -l hbase -c "tail -$line  ${hbase_log_dir}/hbase-hbase-regionserver-${HOSTNAME}.log"
}

StartingHbaseMaster() {
	echo
	echo
	echo "****************          Starting Hbase Master            ***************"
	su -l hbase -c "rm -rf ${hbase_log_dir}/hbase-hbase-master-*"
	su -l hbase -c "/usr/lib/hbase/bin/hbase-daemon.sh --config /etc/hbase/conf start master"
	sleep ${sleep_value}
	su -l hbase -c "tail -$line  ${hbase_log_dir}/hbase-hbase-master-${HOSTNAME}.log"
	echo
	echo
}

StartingTempeltonServer() {
	echo "****************          Starting Tempelton server            ***************"
	echo "templeton working directory `pwd`"
	su -l  templeton -c "rm -rf ${templeton_log_dir}/*"
	su -l  templeton -c "env TEMPLETON_HOME=/etc/templeton/   /usr/sbin/templeton_server.sh start"
	echo
	echo
}

StartingNagiosandSnmpdServices() {
	echo "****************          Starting Nagios and Snmpd Services           ***************"
	/etc/init.d/snmpd restart
	/etc/init.d/nagios restart
}

StartingGangliaServices() {
	echo
	echo
	echo "****************          Starting the Ganglia Services            ***************"
	#rm -rf /var/run/ganglia/hdp/gmetad.pid
	/etc/init.d/hdp-gmond restart
	/etc/init.d/hdp-gmetad restart
	/etc/init.d/httpd restart
	echo
	echo
}

ServiceAssociatedWithIpPorts() {
	echo "****************          Service Associated With Ip Ports            ***************"
	netstat -nltp
	echo
	echo
}

JavaProcess() {
	echo "****************          Java Process            ***************"
	ps auxwwwf | grep java | grep -v grep | awk '{print $2,$1,$12}' | sort 
	echo
	echo
	#echo "****************          JPS result            ***************"
	# jps -m | sort| grep -v Jps
	#eval ${basedir}/JpsFormatedOutput.sh
}


StartingNameNode
StartingSecondaryNameNode
StartingSingleDataNode
StartingJobTracker
StartingHistoryServer
StartingTaskTrackers
StartingHiveServer
StartingOozieServer
StartingZookeeperNodes
StartingHbaseRegionservers
StartingHbaseMaster
StartingTempeltonServer
StartingNagiosandSnmpdServices 
StartingGangliaServices
ServiceAssociatedWithIpPorts
JavaProcess

