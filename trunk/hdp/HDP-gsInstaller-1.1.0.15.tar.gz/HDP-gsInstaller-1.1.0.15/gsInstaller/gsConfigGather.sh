#!/bin/bash

#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

basedir=`pwd`
source ${basedir}/gsConfigGather.properties
source ${basedir}/gsConfigGatherLib.sh

tput clear
echo0 "Config Gather Script"
echo $line

case "$package" in
  rpm|RPM)
    installpkg=rpm
    ;;
  deb|DEB|Deb)
    installpkg=deb
    ;;
  tar|TAR|Tar)
    installpkg=tar
    ;;
  *)
  echo "Please provide the package type you want to install rpm | deb | tar"
  exit 1
  ;;
esac

[ `validate $gethadoopconf` == "yes" ] && gethadoopconf=yes
[ `validate $gethbaseconf` == "yes" ] && gethbaseconf=yes
[ `validate $getzookeeperconf` == "yes" ] && getzookeeperconf=yes
[ `validate $getoozieconf` == "yes" ] && getoozieconf=yes
[ `validate $gethiveconf` == "yes" ] && gethiveconf=yes
[ `validate $getpigconf` == "yes" ] && getpigconf=yes

if [[ -z "$outputdir" ]]; then
  outputdir="/tmp/$0-$$/"
fi

if [[ "$gethadoopconf" == "yes" ]]; then
  [ "$nnhost" == "" ] && echo "Enter a valid Namenodehost" && exit
  [ "$jthost" == "" ] && echo "Enter a valid Jobtracker" && exit
  [ "$slaves" == "" ] && echo "Enter a valid Slaves hostname list" && exit
  if [[ "${installpkg}" == "tar" ]]; then
    validatehadoopconfdir
  fi
fi

if [[ "$gethbaseconf" == "yes" ]]; then
  [ "$hbmhost" == "" ] && echo "Enter a valid Hbase master host" && exit
  [ "$rshosts" == "" ] && echo "Enter a valid Hbase regionservers list" && exit
  if [[ "${installpkg}" == "tar" ]]; then
    validatehbaseconfdir
  fi
fi

if [[ "$getzookeeperconf" == "yes" ]]; then
  [ "$zkhosts" == "" ] && echo "Enter a valid Zookeeper servers list" && exit
  if [[ "${installpkg}" == "tar" ]]; then
    validatezookeeperconfdir
  fi
fi

if [[ "$getoozieconf" == "yes" ]]; then
  [ "$ooziehost" == "" ] && echo "Enter a valid oozie server" && exit
  if [[ "${installpkg}" == "tar" ]]; then
    validateoozieconfdir
  fi
fi

if [[ "$gethiveconf" == "yes" ]]; then
  [ "$hcshost" == "" ] && echo "Enter a valid hive/hcat server" && exit
  if [[ "${installpkg}" == "tar" ]]; then
    validatehiveconfdir
  fi
fi

if [[ "$getpigconf" == "yes" ]]; then
  [ "$pighost" == "" ] && echo "Enter a valid gateway to pull pig configs from" && exit
  if [[ "${installpkg}" == "tar" ]]; then
    validatepigconfdir
  fi
fi

# create/check for output dir existence
mkdir -p ${outputdir}
if [[ ! -d ${outputdir} ]]; then
  echo "Error: ${outputdir} does not exist or not created"
  exit 1
fi

touchfile="${outputdir}/test_touch_file"
echo "test" > ${touchfile}
if [[ ! -e ${touchfile} ]]; then
  echo "Error: could not write to ${outputdir}"
  exit 1
fi
rm -f ${touchfile}

default_hadoop_conf_dir="/etc/hadoop/"
default_hbase_conf_dir="/etc/hbase/conf/"
default_zookeeper_conf_dir="/etc/zookeeper/"
default_oozie_conf_dir="/etc/oozie/"
default_hive_conf_dir="/etc/hive/conf/"
default_pig_conf_dir="/etc/pig/conf/"

founderror=0

if [[ "$gethadoopconf" == "yes" ]]; then
  dloaddir="${outputdir}/hadoop-conf/"
  rm -rf ${dloaddir}
  mkdir -p ${dloaddir}

  if [[ -z "${hadoop_conf_dir}" ]]; then
    hadoop_conf_dir=${default_hadoop_conf_dir}
  fi

  # get nn configs
  nnconfdir=${namenode_conf_dir}
  if [[ -z "${nnconfdir}" ]]; then
    nnconfdir="${hadoop_conf_dir}"
  fi

  echo0 "Configs: hadoop-conf/namenode/${nnhost} from ${nnconfdir}"
  pull_config "${nnhost}" "hadoop-conf" "namenode" "${nnconfdir}" "${dloaddir}"
  if [[ "$?" != "0" ]]; then
    founderror=1
  fi

  #get snn configs
  if [[ ! -z ${snhost} ]]; then
    snnconfdir=${snamenode_conf_dir}
    if [[ -z "${snnconfdir}" ]]; then
      snnconfdir="${hadoop_conf_dir}"
    fi
    for sn in ${snhost}
    do
      echo0 "Configs: hadoop-conf/snamenode/${sn} from ${snnconfdir}"
      pull_config ${sn} "hadoop-conf" "snamenode" "${snnconfdir}" "${dloaddir}"
      if [[ "$?" != "0" ]]; then
        founderror=1
      fi
    done
  fi

  #get datanode configs
  dnconfdir=${datanode_conf_dir}
  if [[ -z "${dnconfdir}" ]]; then
    dnconfdir="${hadoop_conf_dir}"
  fi
  for dn in ${slaves}
  do
    echo0 "Configs: hadoop-conf/datanode/${dn} from ${dnconfdir}"
    pull_config ${dn} "hadoop-conf" "datanode" "${dnconfdir}" "${dloaddir}"
    if [[ "$?" != "0" ]]; then
      founderror=1
    fi
  done

  # get jobtracker configs
  jtconfdir=${jobtracker_conf_dir}
  if [[ -z "${jtconfdir}" ]]; then
    jtconfdir="${hadoop_conf_dir}"
  fi
  echo0 "Configs: hadoop-conf/jobtracker/${jthost} from ${jtconfdir}"
  pull_config "${jthost}" "hadoop-conf" "jobtracker" "${jtconfdir}" "${dloaddir}"
  if [[ "$?" != "0" ]]; then
    founderror=1
  fi

  # get tasktracker configs
  ttconfdir=${tasktracker_conf_dir}
  if [[ -z "${ttconfdir}" ]]; then
    ttconfdir="${hadoop_conf_dir}"
  fi
  for tt in ${slaves}
  do
    echo0 "Configs: hadoop-conf/tasktracker/${tt} from ${ttconfdir}"
    pull_config ${tt} "hadoop-conf" "tasktracker" "${ttconfdir}" "${dloaddir}"
    if [[ "$?" != "0" ]]; then
      founderror=1
    fi
  done
fi

if [[ "$gethbaseconf" == "yes" ]]; then
  dloaddir="${outputdir}/hbase-conf/"
  rm -rf ${dloaddir}
  mkdir -p ${dloaddir}

  if [[ -z "${hbase_conf_dir}" ]]; then
    hbase_conf_dir=${default_hbase_conf_dir}
  fi

  # get hbase master configs
  hbmconfdir="${hbasemaster_conf_dir}"
  if [[ -z ${hbmconfdir} ]]; then
    hbmconfdir="${hbase_conf_dir}"
  fi
  echo0 "Configs: hbase-conf/master/${hbmhost} from ${hbmconfdir}"
  pull_config "${hbmhost}" "hbase-conf" "master" "${hbmconfdir}" "${dloaddir}"
  if [[ "$?" != "0" ]]; then
    founderror=1
  fi

  # get hbase region server configs
  hrsconfdir="${hbaseregionserver_conf_dir}"
  if [[ -z ${hrsconfdir} ]]; then
    hrsconfdir="${hbase_conf_dir}"
  fi
  for rs in ${rshosts}
  do
    echo0 "Configs: hbase-conf/regionserver/${rs} from ${hrsconfdir}"
    pull_config "${rs}" "hbase-conf" "regionserver" "${hrsconfdir}" "${dloaddir}"
    if [[ "$?" != "0" ]]; then
      founderror=1
    fi
  done
fi

if [[ "$getzookeeperconf" == "yes" ]]; then
  dloaddir="${outputdir}/zk-conf/"
  rm -rf ${dloaddir}
  mkdir -p ${dloaddir}

  #get zookeeper confs
  zkconfdir="${zookeeper_conf_dir}"
  if [[ -z "${zkconfdir}" ]]; then
    zkconfdir=${default_zookeeper_conf_dir}
  fi
  for zk in ${zkhosts}
  do
    echo0 "Configs: zk-conf/server/${zk} from ${zkconfdir}"
    pull_config "${zk}" "zk-conf" "server" "${zkconfdir}" "${dloaddir}"
    if [[ "$?" != "0" ]]; then
      founderror=1
    fi
  done
fi

if [[ "$getoozieconf" == "yes" ]]; then
  dloaddir="${outputdir}/oozie-conf/"
  rm -rf ${dloaddir}
  mkdir -p ${dloaddir}

  #get oozie confs
  oozieconfdir="${oozie_conf_dir}"
  if [[ -z "${oozieconfdir}" ]]; then
    oozieconfdir=${default_oozie_conf_dir}
  fi
  for oh in ${ooziehost}
  do
    echo0 "Configs: oozie-conf/oozie_server/${oozie} from ${oozieconfdir}"
    pull_config "${oh}" "oozie-conf" "oozie_server" "${oozieconfdir}" "${dloaddir}"
    if [[ "$?" != "0" ]]; then
      founderror=1
    fi
  done
fi

if [[ "$gethiveconf" == "yes" ]]; then
  dloaddir="${outputdir}/hcat-conf/"
  rm -rf ${dloaddir}
  mkdir -p ${dloaddir}

  #get hive confs
  hiveconfdir="${hive_conf_dir}"
  if [[ -z "${hiveconfdir}" ]]; then
    hiveconfdir=${default_hive_conf_dir}
  fi
  for hn in ${hcshost}
  do
    echo0 "Configs: hcat-conf/hive/${hn} from ${hiveconfdir}"
    pull_config "${hn}" "hcat-conf" "hive" "${hiveconfdir}" "${dloaddir}"
    if [[ "$?" != "0" ]]; then
      founderror=1
    fi
  done
fi

if [[ "$getpigconf" == "yes" ]]; then
  dloaddir="${outputdir}/pig-conf/"
  rm -rf ${dloaddir}
  mkdir -p ${dloaddir}

  #get pig confs
  pigconfdir="${pig_conf_dir}"
  if [[ -z "${pigconfdir}" ]]; then
    pigconfdir=${default_pig_conf_dir}
  fi
  for pn in ${pighost}
  do
    echo0 "Configs: pig-conf/pig/${pn} from ${pigconfdir}"
    pull_config "${pn}" "pig-conf" "pig" "${pigconfdir}" "${dloaddir}"
    if [[ "$?" != "0" ]]; then
      founderror=1
    fi
  done
fi


### Verification steps

hadoop_conf_file_list=" \
capacity-scheduler.xml \
commons-logging.properties \
configuration.xsl \
core-site.xml \
dfs.exclude \
dfs.include \
fair-scheduler.xml \
hadoop-env.sh \
hadoop-metrics2.properties \
hadoop-policy.xml \
hdfs-site.xml \
log4j.properties \
mapred.exclude \
mapred.include \
mapred-queue-acls.xml \
mapred-site.xml \
masters \
slaves \
taskcontroller.cfg "

dloaddir="${outputdir}/hadoop-conf/"
echo0 "hadoop-conf: gathered config files in ${dloaddir}"
for fname in ${hadoop_conf_file_list}
do
  cmd="find ${dloaddir} -name ${fname} | wc -l"
  cnt=`eval $cmd`
  echo "Found $cnt instances of ${fname} in ${dloaddir}" | tee -a $outlog
done

hbase_conf_file_list=" \
hadoop-metrics.properties \
hbase-env.sh \
hbase-policy.xml \
hbase-site.xml \
log4j.properties \
regionservers "

dloaddir="${outputdir}/hbase-conf/"
echo0 "hbase-conf: gathered config files in ${dloaddir}"
for fname in ${hbase_conf_file_list}
do
  cmd="find ${dloaddir} -name ${fname} | wc -l"
  cnt=`eval $cmd`
  echo "Found $cnt instances of ${fname} in ${dloaddir}" | tee -a $outlog
done

zk_conf_file_list=" \
log4j.properties \
zoo.cfg "

dloaddir="${outputdir}/zk-conf/"
echo0 "zk-conf: gathered config files in ${dloaddir}"
for fname in ${zk_conf_file_list}
do
  cmd="find ${dloaddir} -name ${fname} | wc -l"
  cnt=`eval $cmd`
  echo "Found $cnt instances of ${fname} in ${dloaddir}" | tee -a $outlog
done

oozie_conf_file_list=" \
log4j.properties \
oozie-site.xml "

dloaddir="${outputdir}/oozie-conf/"
echo0 "oozie-conf: gathered config files in ${dloaddir}"
for fname in ${oozie_conf_file_list}
do
  cmd="find ${dloaddir} -name ${fname} | wc -l"
  cnt=`eval $cmd`
  echo "Found $cnt instances of ${fname} in ${dloaddir}" | tee -a $outlog
done

hive_conf_file_list=" \
hive-site.xml \
log4j.properties "

dloaddir="${outputdir}/hcat-conf/"
echo0 "hive-conf: gathered config files in ${dloaddir}"
for fname in ${hive_conf_file_list}
do
  cmd="find ${dloaddir} -name ${fname} | wc -l"
  cnt=`eval $cmd`
  echo "Found $cnt instances of ${fname} in ${dloaddir}" | tee -a $outlog
done

pig_conf_file_list=" \
log4j.properties \
pig.properties \
pig-env.sh "

dloaddir="${outputdir}/pig-conf/"
echo0 "pig-conf: gathered config files in ${dloaddir}"
for fname in ${pig_conf_file_list}
do
  cmd="find ${dloaddir} -name ${fname} | wc -l"
  cnt=`eval $cmd`
  echo "Found $cnt instances of ${fname} in ${dloaddir}" | tee -a $outlog
done

echo0 "Output logs are available at ${outlog}"
if [[ "${founderror}" != "0" ]]; then
  echo "Found errors in scp commands. Please check logs"
fi

exit ${founderror}
