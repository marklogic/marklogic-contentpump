#!/bin/sh

#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

  # Expected to be called via gsUninstaller and not directly.

  basedir=`pwd`
  source ${basedir}/gsInstaller.properties
  source ${basedir}/monInstaller.properties
  # This pulls in gsLibCommon.sh for us, and is needed to get ${installganglia} 
  # (and family) correctly initialized. 
  source ${basedir}/gsLib.sh
  # monrpmInstaller.sh expects for this to be within scope at the time of its sourcing. 
  source ${basedir}/monLib.sh
  # To reuse the handy stop scripts inside.    
  source ${basedir}/rpmInstaller.sh
  source ${basedir}/monrpmInstaller.sh
 
  setInstallDependencies 

  # Set the monitor_config_only option to no until we fix it
  if [ -z $monitor_config_only ]; then monitor_config_only=no; fi

  if [ "$#" -eq "0" ] ; then
    echo "usage: $0 pack | conf "
    echo "       pack - to remove packages"
    echo "       conf - to remove conf dir"
    exit
  fi

  [ -n "$sshkey" ] && usesshkey="-i $sshkey"

  # Sigh. This is so very broken. 
  #
  # We need to call this function before using any of the functions within 
  # monLib.sh because this sets up ${montargets} which is used internally 
  # by all said functions. 
  if [[ "$enablemon" == "yes" ]]; then
    moncollectserverlist;
  fi

  ############################################################
  # FUNCTION TO STOP ALL SERVICES
  ############################################################
  stopallservices() {
    stopTempleton
    stopOozie
    stopHive
    stopHbase
    stopZk
    stopMapReduce
    stopHdfs
  }

  ############################################################
  # FUNCTION TO REMOVE GRID STACK RPMS
  ############################################################
  pack() {
    stopallservices
    local cmd1="rm -f /usr/share/hbase/lib/zookeeper-3.3.2.jar; \
            rm -rf ${pid_dir}/*.pid; rm -rf ${hbase_pid_dir}/*.pid ; \
            unlink /usr/share/templeton/templeton.jar; unlink ${sqoophome}/lib/mysql-connector-java.jar ; unlink ${hivehome}/lib/mysql-connector-java.jar"
    local cmd2="$removepkgcmd hcatalog\*; \
            $removepkgcmd hive\*; \
            $removepkgcmd sqoop\*; \
            $removepkgcmd hbase\*; \
            $removepkgcmd templeton\*; \
            $removepkgcmd zookeeper\*; \
            $removepkgcmd oozie\*; \
            $removepkgcmd pig\*;\
            $removepkgcmd snappy\*; \
            $removepkgcmd hadoop-lzo\*; \
            $removepkgcmd hadoop\*; \
            $removepkgcmd extjs-2.2-1 mysql-connector-java-5.0.8-1"
    #THIS SHOULD ONLY BE RUN WITH BIGTOP_RPMS
    local cmd3="rm -rf $hadoophome" 
    ssh2host "$allhosts" "$cmd1 ; $cmd2; $cmd3"

    if [[ "$enablemon" != "yes" ]]; then
      return 0
    fi

    if [[ "${installdashboard}" == "yes" ]]; then
      echo0 "Uninstalling HDP Dashboard"
      sshdashboard "$removepkgcmd hdp_mon_dashboard"
    fi
    if [[ "${installganglia}" == "yes" ]]; then
      # First, make sure we don't pull the rug out from anyone's feet.  
      stopganglia;

      # Next (now that they're of no use to us anymore), remove the 
      # init.d scripts that we added by hand. 
      #  
      # Note that we don't wipe out ${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR} 
      # because parts of that are needed for removing both, the packages and
      # the configuration, so that's really at a more foundational level.
      # 
      # Thus, as long as an uninstall is not a single, atomic operation,
      # we're going to leave ${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR} hanging
      # around on the boxes - it'll get wiped out (and overwritten) at the 
      # time of the next install. 
      echo0 "Removing HDP Ganglia-related init.d scripts"
      sshgangliaserver "rm -f /etc/init.d/hdp-gmetad";
      monsshall "rm -f /etc/init.d/hdp-gmond;";

################################################################################
# Comment this block out till we find it's actually needed (in an ideal 
# world, this would be configurable at runtime).
################################################################################
#
#      # Then, undo the fixup we performed at the time of installation - 
#      # essentially, just strip the .MOVED_BY_HDP suffix we tacked on. 
#      xssh $gangliaweb "find /var/www/html/ganglia/graph.d -name '*_report.php.MOVED_BY_HDP' -type f -print | \
#        sed 's!\(.*\)\.MOVED_BY_HDP! & \1!g' | xargs -L1 mv";
#
################################################################################

      # And finally, uninstall the RPMs (modulo ${monitor_config_only}, of course).
      if [[ "$monitor_config_only" != "yes" ]]; then
        echo0 "Uninstalling Ganglia-related RPMs"
        gangliarmcmd="$removepkgcmd ganglia-gmond; \
            $removepkgcmd libganglia; \
            $removepkgcmd ganglia-gmetad; \
            $removepkgcmd perl-rrdtool; \
            $removepkgcmd rrdtool; \
            $removepkgcmd hdp_mon_ganglia_addons; \
            $removepkgcmd gweb"
        sshgangliaclients "${gangliarmcmd}"
        sshgangliaserver "${gangliarmcmd}"
        xssh $gangliaweb "${gangliarmcmd}"
      fi
    fi
    if [[ "${installnagios}" == "yes" ]]; then
      if [[ "$monitor_config_only" != "yes" ]]; then
        sshnagios "$removepkgcmd nagios; \
           $removepkgcmd nagios-plugins; \
           $removepkgcmd hdp_mon_nagios_addons; "
      fi
    fi
  }

  ############################################################
  # FUNCTION TO REMOVE GRID STACK CONFIGS
  ############################################################
  conf() {
    # clean up the alternatives dirs also
    local dirs="${ALTERNATIVE_DIR}/{hadoop,hbase,zookeeper,hive,hcatalog,oozie,pig,sqoop,templeton}-conf"
    local cmd1="rm --preserve-root -rf ${hadoopconfdir} ${hbaseconfdir} ${oozieconfdir} ${zkconfdir} ${hcatconfdir} ${hiveconfdir} ${templetonconfdir} /etc/default/zookeeper-env.sh $dirs"
    ssh2host "$allhosts" "$cmd1"
    if [[ "$enablemon" != "yes" ]]; then
      return 0
    fi
    if [[ "${installdashboard}" == "yes" ]]; then
      sshdashboard "rm -f /usr/share/hdp/dataServices/conf/cluster_configuration.json"
    fi
    if [[ "${installganglia}" == "yes" ]]; then
      echo0 "Tearing down Ganglia configs"
      monsshall "${GANGLIA_RUNTIME_COMPONENTS_UNPACK_DIR}/teardownGanglia.sh"
    fi
  }

  $1
