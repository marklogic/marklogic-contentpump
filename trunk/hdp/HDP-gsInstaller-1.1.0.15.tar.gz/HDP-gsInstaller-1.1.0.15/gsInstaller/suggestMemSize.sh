inputDir=$1
outputFile=$2
inputFile=$inputDir/data.txt
maxMapsPerNode=4
maxRedsPerNode=2
check=$3
source $inputFile

echo $HDPClusterDeployUserIdentityFile
echo $HDPClusterDeployUser

cd $inputDir
[[ -f "gateway" ]] && gwhost=$(cat gateway)
[[ -f "namenode" ]] && nnhost=$(cat namenode)
[[ -f "snamenode" ]] && snhost=$(cat snamenode)
[[ -f "jobtracker" ]] && jthost=$(cat jobtracker)
[[ -f "hbasemaster" ]] && hbmhost=$(cat hbasemaster)
[[ -f "hcatserver" ]] && hcshost=$(cat hcatserver)
[[ -f "templetonnode" ]] && ttonhosts=$(cat templetonnode)
[[ -f "oozieserver" ]] && oozieshost=$(cat oozieserver)
[[ -f "nodes" ]] && slaves=$(cat nodes)
[[ -f "hbasenodes" ]] && rshosts=$(cat hbasenodes)
[[ -f "zknodes" ]] && zkhosts=$(cat zknodes)
[[ -f "gangliaserver" ]] && gangliahost=$(cat gangliaserver)
[[ -f "nagiosserver" ]] && nagioshost=$(cat nagiosserver)

maxMem=
heapSizeSuggest=

sshCmdOnHost ()
{
  echo "I AM IN HERE **************"
  echo "$1 $2 $3"
  local cmd="ssh -i $HDPClusterDeployUserIdentityFile $HDPClusterDeployUser@$1 \"$2\" > $3"
  echo $cmd
  eval $cmd
}

findMaxMemOnHost ()
{
  #  echo "SSHCMD: ssh -i /var/db/hdp/easyInstaller/MyHDPCluster/files/clusterDeployUserIdentity root@$1 \"free -m | sed \\\"1 d\\\" | awk '{print \\\$4}' | sed -n 1p\""
  sshCmdOnHost $1 "free -m" "${PWD}/tmpMem.out"
#  ssh -i $HDPClusterDeployUserIdentityFile $HDPClusterDeployUser@$1 "free -m" > tmpMem.out
  memOut=`cat $PWD/tmpMem.out | sed "1 d" | awk '{print $4}' | sed -n 1p`
  `echo $memOut > tmp.out`
}

scaleByThreads=2
scaleRelativeMapsReds=3
findMaxCoresOnHost ()
{
  sshCmdOnHost $1 "grep -c processor /proc/cpuinfo" tmpCpu.out
  cpuCount=`cat tmpCpu.out`
  maxMapsPerNode=`expr $cpuCount \* $scaleByThreads \* 2 / $scaleRelativeMapsReds`
  maxRedsPerNode=`expr $cpuCount \* $scaleByThreads - $maxMapsPerNode`
  totalProcessesPerSlave=`expr $maxMapsPerNode + $maxRedsPerNode`

  if [ $maxMapsPerNode -lt 1 ]; then 
    maxMapsPerNode=1
  fi

  if [ $maxRedsPerNode -lt 1 ]; then
    maxRedsPerNode=1
  fi
}

list=
for slave in $(echo $slaves)
do
  findMaxCoresOnHost $slave
  #### -2 because -1 for count to go to 0 and -1 for allHosts
  totalProcessesPerSlave=`expr $maxMapsPerNode + $maxRedsPerNode - 2`
  list=$slaves
  while [ $totalProcessesPerSlave -ne 0 ];
  do
    totalProcessesPerSlave=`expr $totalProcessesPerSlave - 1`
    list="$list $slaves"
  done
  break
done

allHosts=`echo $slaves $jthost $nnhost $snhost $gwhost $hbmhost $hcshost $rshosts $zkhosts $nagioshost $gangliahost $list`
# echo ALLHOSTS: $allHosts

findForNodeType ()
{
  echo Hostname: $1
  procCount=`grep -o $1 <<< "$allHosts" | wc -l`
  echo PROCCOUNT: $procCount
  findMaxMemOnHost $1
#  findMaxCoresOnHost $1
  maxMem=`cat tmp.out`
  echo MAXMEM: $maxMem
  heapSizeSuggest=`expr $maxMem / $procCount`
}

echo NAMENODE $nnhost
findForNodeType $nnhost
nameNodeHeapSizeSuggest=$heapSizeSuggest
`echo HDPNameNodeHeapSize $heapSizeSuggest > $outputFile`

echo JOBTRACKER $jthost
findForNodeType $jthost
jobTrackerHeapSizeSuggest=$heapSizeSuggest
`echo HDPJobTrackerHeapSize $heapSizeSuggest >> $outputFile`

echo HBASEMASTER $hbmhost
findForNodeType $hbmhost
hbmHeapSizeSuggest=$heapSizeSuggest
`echo HDPHBaseMasterHeapSize $heapSizeSuggest >> $outputFile`

# for now max value assumed to be 100G 
minSuggest=100000000000
for node in $(echo $slaves)
do
  findForNodeType $node
  if [ "$minSuggest" -gt "$heapSizeSuggest" ]; then
    minSuggest=$heapSizeSuggest
  fi
done

echo DATANODE
dataNodeHeapSizeSuggest=$minSuggest
`echo HDPDataNodeHeapSize $minSuggest >> $outputFile`
echo HADOOPHEAP
hadoopHeapSizeSuggest=$minSuggest
`echo HDPHadoopHeapSize $minSuggest >> $outputFile`
echo CHILDOPTS
childJavaOptsSize=$minSuggest
`echo HDPMapRedChildJavaOptsSize $minSuggest >> $outputFile`

rm -f tmpCpu.out tmpMem.out

checkConfig ()
{
  if [ $HDPNameNodeHeapSize -gt $nameNodeHeapSizeSuggest ]; then
    echo ERROR: Insufficient heap size for Name Node.
  fi

  if [ $HDPJobTrackerHeapSize -gt $jobTrackerHeapSizeSuggest ]; then
    echo ERROR: Insufficient heap size for JobTracker.
  fi

  if [ $HDPHBaseMasterHeapSize -gt $hbmHeapSizeSuggest ]; then
    echo ERROR: Insufficient heap size for HBase Master.
  fi

  if [ $HDPDataNodeHeapSize -gt $dataNodeHeapSizeSuggest ]; then
    echo ERROR: Insufficient heap size for Data Node.
  fi

  ## May not be checked. If the user does not want to use the 
  ## above conservative method, this can be masked
  if [ $HDPHadoopHeapSize -gt $hadoopHeapSizeSuggest ]; then
    echo ERROR: Insufficient heap size for Hadoop Heap.
  fi

  if [ $HDPMapRedChildJavaOptsSize -gt $childJavaOptsSize ]; then
    echo ERROR: Insufficient heap size for Child Java Opts.
  fi
}

if [ $check -eq 1 ]; then
  checkConfig
fi
