#!/bin/sh

#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

##############################################################
# This script is used to start mysql server on the host where the script is being run.
# The script has to be executed as user root
# Make sure gsInstaller.properties has correct values for mysqldbuser and mysqldbpasswd  
##############################################################
basedir=`pwd`
source ${basedir}/gsInstaller.properties
source ${basedir}/gsLib.sh

if [[ "$SYSTEM_OS" == "$OS_SLES" ]]; then
  pkgs='mysql'
  startCmd='/etc/init.d/mysql start'
  checkCmd='chkconfig mysql on'
else
  pkgs='mysql-server'
  startCmd='/etc/init.d/mysqld start'
  checkCmd='chkconfig mysqld on'
fi

# check if all approprite vars are set
if [ 'xx' == "x${mysqldbhost}x" ]; then
  echo "Fatal: No value set for mysqldbhost in gsInstaller.properties"
fi
if [ 'xx' == "x${databasename}x" ]; then
  echo "Fatal: No value set for databasename in gsInstaller.properties"
fi
if [ 'xx' == "x${mysqldbuser}x" ]; then
  echo "Fatal: No value set for mysqldbuser in gsInstaller.properties"
fi
if [ 'xx' == "x${mysqldbpasswd}x" ]; then
  echo "Fatal: No value set for mysqldbpasswd in gsInstaller.properties"
fi

echo "============="
echo "Installing MYSQL"
echo "============="
ssh2host "$mysqldbhost" "$installpkgcmd $pkgs"

echo "============="
echo "Starting MYSQL server"
echo "============="
ssh2host "$mysqldbhost" "$startCmd"
ssh2host "$mysqldbhost" "mysqladmin -u root 2>&1 >/dev/null"


if [[ "$mysqldbhost" =~ "localhost" ]] ; then
  privHost="localhost"
else
  # else grant from any host to that user and db
  privHost=$hivehost
fi

ssh2host "$mysqldbhost" "echo \"CREATE USER '$mysqldbuser'@'$privHost' IDENTIFIED BY '$mysqldbpasswd';\" | mysql -u root"
ssh2host "$mysqldbhost" "echo \"GRANT ALL PRIVILEGES ON $databasename.* TO '$mysqldbuser'@'$privHost';\" | mysql -u root"
ssh2host "$mysqldbhost" "echo 'flush privileges;' | mysql -u root"

# check the service
ssh2host "$mysqldbhost" "$checkCmd"
