#! /bin/bash


#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/
  #SET ALL PROPERTIES REQUIRED BY RPMINSTALLER
  
  #java related vars
  jdkinstallpath=${jdkinstallpath:-/usr}
  java64home=${java64home:-${jdkinstallpath}/jdk64/${JDK_VERSION}}
  java64parent="`dirname $java64home`"
  
  hadoopjavahome="${jdkinstallpath}/hadoop-${JDK_VERSION}"
  zkjavahome="${jdkinstallpath}/zookeeper-${JDK_VERSION}"
  hbasejavahome="${jdkinstallpath}/hbase-${JDK_VERSION}"
  ooziejavahome="${jdkinstallpath}/oozie-${JDK_VERSION}"
  
  hadoopjdklink="rm -f $hadoopjavahome; ln -fs ${java64home} $hadoopjavahome"
  zkjdklink="rm -f $zkjavahome; ln -fs ${java64home} $zkjavahome"
  hbasejdklink="rm -f $hbasejavahome; ln -fs ${java64home} $hbasejavahome"
  ooziejdklink="rm -f $ooziejavahome; ln -s ${java64home} $ooziejavahome"
   
  #different home properties
  hadoophome="/usr/lib/hadoop"
  pighome="/usr/lib/pig"
  hbasehome="/usr/lib/hbase"
  zkhome="/usr/lib/zookeeper" 
  hivehome="/usr/lib/hive"
  hcathome="/usr/lib/hcatalog"
  ooziehome="/usr/lib/oozie"
  templetonhome="/usr"
  sqoophome="/usr/lib/sqoop"

  #various config directories
  #this should change to /etc/hadoop/conf once sim link is fixed
  hadoopconfdir="/etc/hadoop/conf"
  hcatconfdir="/etc/hcatalog/conf"
  hiveconfdir="/etc/hive/conf"
  zkconfdir="/etc/zookeeper/conf"
  hbaseconfdir="/etc/hbase/conf"
  pigconfdir="/etc/pig/conf"
  oozieconfdir="/etc/oozie/conf"
  sqoopconfdir="/etc/sqoop/conf"
  templetonconfdir="/etc/templeton"
  
  # dir for alerternatives this is where the configs are stored and need to be removed
  export ALTERNATIVE_DIR="/etc/alternatives"

  #various daemon scripts
  hadoop_daemon="${hadoophome}/bin/hadoop-daemon.sh --config $hadoopconfdir"
  
  jdk32name=`echo $JDK_32_URL | awk -F/ '{ print $NF }' | cut -d'?' -f1`
  jdk64name=`echo $JDK_64_URL | awk -F/ '{ print $NF }' | cut -d'?' -f1`
  jcepolicyname=`echo $JCE_POLICY_URL | awk -F/ '{ print $NF }' | cut -d'?' -f1`
   
  # putting the java32install_cmd in if condition as glibc.i686 is not present on SUSE platform.
  if [ "${SYSTEM_OS}" == "${OS_SLES}" ]; then
    java32install_cmd="$installpkgcmd glibc glibc-32bit ;mkdir -p $java32parent ; chmod +x ${destdir}/$jdk32name; \
      cd $java32parent ; echo A | ${destdir}/./$jdk32name -noregister > /dev/null 2>&1"
  else
    java32install_cmd="$installpkgcmd glibc.i686 ;mkdir -p $java32parent ; chmod +x ${destdir}/$jdk32name; \
      cd $java32parent ; echo A | ${destdir}/./$jdk32name -noregister > /dev/null 2>&1"
  fi
  
  java64install_cmd="mkdir -p $java64parent ; chmod +x ${destdir}/$jdk64name ; \
    cd $java64parent ; echo A | ${destdir}/./$jdk64name -noregister > /dev/null 2>&1"
  jceinstall64_cmd="cd ${java64home}/jre/lib/security ; rm -f local_policy.jar ; \
    rm -f US_export_policy.jar; unzip -o -j -q ${destdir}/$jcepolicyname"
  hadoopmasternodes="$nnhost $snhost $jthost"
  hadoopslavenodes="`echo $slaves | tr ' ' ','`"
  

  ############################################################
  #FUNCTION TO download all artifacts
  ############################################################
  setup() {
    echo0 "Download all necessary Artifacts"
    if [ "$installjava" == "true" ]; then
      #download the 64 bit java
      downloadstuff $JDK_64_URL $JDK_64_SIZE
      #download security policy if enabled
      if [ "yes" == "$enablesecurity" ]; then
        downloadstuff $JCE_POLICY_URL $JCE_POLICY_SIZE
      fi
    fi
  
    #insall yum-priorities wget curl on rhel
    local pkg="wget curl"
    #TODO find a similar solution for zypper
    if [ "$OS_CENTOS" == "$SYSTEM_OS" ]; then
      if [ "6" == "$OS_VERSION" ]; then
        local pkg="$pkg yum-plugin-priorities"
      else
        local pkg="$pkg yum-priorities"
      fi
      ssh2host "$allhosts_with_mon" "${installpkgcmd} $pkg"
    fi
  }

  ###############################################################
  #FUNCTION TO INITIALIZE NN, DATA & MR DIR'S AND SET APPROPRIATE PERMISSIONS
  ###############################################################
  initialize() {
    datanodedirs=`echo $datanode_dir | tr "," " "`
    namenodedirs=`echo $namenode_dir | tr "," " "`
    snamenodedirs=`echo $snamenode_dir | tr "," " "`
    mapreddirs=`echo $mapred_dir | tr "," " " `
    mapredtmpdir=`echo ${mapred_tmp_dir} | tr "," " "`

    zkdirs="${zk_log_dir} ${zk_pid_dir}"
    setupzkdirs=" mkdir -p ${zkdirs};  chmod 775 -R ${zkdirs} ; chown -R ${zkuser} ${zkdirs}"
    setupzkdatadir=" mkdir -p ${zk_data_dir}; \
       chmod 755 -R ${zk_data_dir};  chown -R ${zkuser}:hadoop ${zk_data_dir}"
    setuphbasedir=" mkdir -p ${hbase_log_dir} ${hbase_pid_dir} ;  chown -R ${hbaseuser}:hadoop ${hbase_log_dir} ${hbase_pid_dir} ; \
       chmod 775 -R ${hbase_log_dir} ${hbase_pid_dir}"
    if [[ $installhbase == "yes" ]] ; then
      ssh2host "$(echo ${zkhosts} | tr "\n " " ")" "${setupzkdirs}; ${setupzkdatadir}"
      ssh2host "$(echo $hbmhost $rshosts | tr "\n" " ")" "${setuphbasedir}"
    fi

    rmcmd=" rm -rf"
      if [[ "$upgrade" == "yes" ]] ; then
        rmcmd="echo"
      fi
    setuplogdir=" mkdir -p $log_dir/$mapreduser;  mkdir -p $log_dir/$hdfsuser; \
    chown -R ${mapreduser}:hadoop $log_dir/$mapreduser; chown -R ${hdfsuser}:hadoop $log_dir/$hdfsuser; \
    chmod 755 -R $log_dir"
    setuppiddir=" mkdir -p $pid_dir/$mapreduser ;  mkdir -p $pid_dir/$hdfsuser ; \
    chown -R ${mapreduser}:hadoop $pid_dir/$mapreduser; chown -R ${hdfsuser}:hadoop $pid_dir/$hdfsuser; \
    chmod 755 -R $pid_dir;"
    setupdatanodedirs="${rmcmd} ${datanodedirs} ;  mkdir -p ${datanodedirs} ; \
       chown -R ${hdfsuser}:hadoop ${datanodedirs};  chmod -R 755 ${datanodedirs}"
    setupnamenodedirs="${rmcmd} ${namenodedirs} ;  mkdir -p ${namenodedirs} ; \
       chown -R ${hdfsuser}:hadoop ${namenodedirs};  chmod -R 755 ${namenodedirs}"
    setupsnamenodedirs="${rmcmd} ${snamenodedirs} ;  mkdir -p ${snamenodedirs} ; \
       chown -R ${hdfsuser}:hadoop ${snamenodedirs};  chmod -R 755 ${snamenodedirs}"
    setupmrdirs=" mkdir -p $mapreddirs;  chown -R ${mapreduser}:hadoop ${mapreddirs}; \
       chmod -R 755 ${mapreddirs}"
    setmapredtmpdir=" mkdir -p ${mapredtmpdir} ;  chown -R ${mapreduser}:hadoop ${mapredtmpdir}"
    ssh2host "${allhosts}" "${setuplogdir}"
    ssh2host "${allhosts}" "${setuppiddir}"
    ssh2host "${nnhost}" "${setupnamenodedirs}"
    ssh2host "${snhost}" "${setupsnamenodedirs}"
    ssh2host "$(echo ${slaves} | tr "\n" " ")" "${setupdatanodedirs}; ${setupmrdirs}; ${setmapredtmpdir}"
    ssh2host "${jthost}" "${setupmrdirs}; ${setmapredtmpdir}"

    setuphivedir=" mkdir -p ${hive_log_dir}; \
       chown -R ${hiveuser} ${hive_log_dir} ; \
       chmod 775 -R ${hive_log_dir}"
    if [[ $installhive == "yes" ]] ; then
      ssh2host "${hivehost}" "${setuphivedir}"
    fi

   }

  ###############################################################
  #FUNCTION TO SETUP HADOOP DIRS
  ###############################################################
  hadoopDirSetup() {
    echo0 "Setting up various directories required by hadoop"
    datanodedirs=`echo $datanode_dir | tr "," " "`
    namenodedirs=`echo $namenode_dir | tr "," " "`
    snamenodedirs=`echo $snamenode_dir | tr "," " "`
    mapreddirs=`echo $mapred_dir | tr "," " " `

    rmcmd=" rm -rf"
      if [[ "$upgrade" == "yes" ]] ; then
        rmcmd="echo"
      fi
    setuplogdir=" mkdir -p $log_dir/$mapreduser;  mkdir -p $log_dir/$hdfsuser; \
    chown -R ${mapreduser}:hadoop $log_dir/$mapreduser; chown -R ${hdfsuser}:hadoop $log_dir/$hdfsuser; \
    chmod 775 -R $log_dir"
    setuppiddir=" mkdir -p $pid_dir/$mapreduser ;  mkdir -p $pid_dir/$hdfsuser ; \
    chown -R ${mapreduser}:hadoop $pid_dir/$mapreduser; chown -R ${hdfsuser}:hadoop $pid_dir/$hdfsuser; \
    chmod 775 -R $pid_dir"
    if [[ "true" == "$enableshortcircuit" ]] ; then
      setupdatanodedirs="${rmcmd} ${datanodedirs};  mkdir -p ${datanodedirs} ; \
         chown -R ${hdfsuser}:hadoop ${datanodedirs};  chmod -R 750 ${datanodedirs}"
    else
      setupdatanodedirs="${rmcmd} ${datanodedirs};  mkdir -p ${datanodedirs} ; \
         chown -R ${hdfsuser}:hadoop ${datanodedirs};  chmod -R 700 ${datanodedirs}"
    fi
    setupnamenodedirs="${rmcmd} ${namenodedirs};  mkdir -p ${namenodedirs} ; \
       chown -R ${hdfsuser}:hadoop ${namenodedirs};  chmod -R 755 ${namenodedirs}"
    setupsnamenodedirs="${rmcmd} ${snamenodedirs};  mkdir -p ${snamenodedirs} ; \
       chown -R ${hdfsuser}:hadoop ${snamenodedirs};  chmod -R 755 ${snamenodedirs}"
    setupmrdirs=" mkdir -p $mapreddirs;  chown -R ${mapreduser}:hadoop ${mapreddirs}; \
       chmod -R 755 ${mapreddirs}"
    ssh2host "${allhosts}" "${setuplogdir}; ${setuppiddir}"
    ssh2host "${nnhost}" "${setupnamenodedirs}"
    ssh2host "${snhost}" "${setupsnamenodedirs}"
    ssh2host "$(echo ${slaves} | tr "\n" ",")" "${setupdatanodedirs}; ${setupmrdirs}"
    ssh2host "${jthost}" "${setupmrdirs}"
    }

  ###############################################################
  #FUNCTION TO SETUP HIVE DIRS
  ###############################################################
  hiveDirSetup() {
    setuphivedir=" mkdir -p ${hive_log_dir} ; \
       chown -R ${hiveuser} ${hive_log_dir} ; \
       chmod 775 -R ${hive_log_dir} "
    if [[ $installhive == "yes" ]] ; then
      echo0 "Setting up various directories required by hive"
      ssh2host "${hivehost}" "${setuphivedir}"
    fi
  }

  ###############################################################
  #FUNCTION TO SETUP TEMPLETON DIRS
  ###############################################################
  templetonDirSetup() {
    setuptempletondir=" mkdir -p $templeton_log_dir;  chown -R ${templetonuser}:hadoop $templeton_log_dir; \
       mkdir  -p $templeton_pid_dir;  chown -R ${templetonuser}:hadoop $templeton_pid_dir; \
       chmod 775 -R $templeton_log_dir $templeton_pid_dir;  "

    if [[ $installtempleton == "yes" ]] ; then
        echo0 "Setting up various directories required by templeton"
        for i in $ttonhosts
          do
            ssh2host "${i}" "${setuptempletondir}"
          done
    fi
  }

  ###############################################################
  #FUNCTION TO SETUP Oozie DIRS
  ###############################################################
  oozieDirSetup() {
    rmcmd=" rm -rf"
    if [[ "$upgrade" == "yes" ]] ; then
      rmcmd="echo"
    fi
    local oozie_dirs="$oozie_log_dir $oozie_pid_dir $oozie_db_dir"
    setupooziedir="$rmcmd $oozie_db_dir ; mkdir -p $oozie_dirs; \
       chown -R ${oozieuser}:hadoop $oozie_dirs; \
       chmod 755 -R $oozie_dirs"
    if [[ $installoozie == "yes" ]] ; then
      echo0 "Setting up various directories required by Oozie"
      ssh2host "${oozieshost}" "${setupooziedir}"
      setupoozieserver="${ooziehome}/bin/oozie-setup.sh"
      setupooziedb="${ooziehome}/bin/ooziedb.sh"
      setupOozieDbCmd="$setupooziedb -sqlfile oozie.sql -run Validate DB Connection"
      ssh2host "${oozieshost}" "mkdir -p /var/tmp/oozie"
      ssh2host "${oozieshost}" "chown -R ${oozieuser}:hadoop /var/tmp/oozie"
      # dont run ooziedb.sh as 3.2.0 is not working yet
      #ssh2host "${oozieshost}" "$SUDOUSERPREFIX ${oozieuser} $SUDOCMDOPTION \"cd /var/tmp/oozie; ${setupoozieserver} -hadoop 0.20.200 $hadoophome -extjs /usr/share/HDP-oozie/ext-2.2.zip; $setupOozieDbCmd\""
      ssh2host "${oozieshost}" "$SUDOUSERPREFIX ${oozieuser} $SUDOCMDOPTION \"cd /var/tmp/oozie; ${setupoozieserver} -hadoop 0.20.200 $hadoophome -extjs /usr/share/HDP-oozie/ext-2.2.zip\""
    fi
  }

  ###############################################################
  #FUNCTION TO SETUP HBASE DIRS
  ###############################################################
  hbaseDirSetup() {
    setuphbasedir=" mkdir -p ${hbase_log_dir} ${hbase_pid_dir} ;  chown -R ${hbaseuser}:hadoop ${hbase_log_dir} ${hbase_pid_dir} ; \
        chmod 775 -R ${hbase_log_dir} ${hbase_pid_dir}"
    if [[ $installhbase == "yes" ]] ; then
      echo0 "Setting up various directories required by Hbase"
      ssh2host "$(echo $hbmhost $rshosts | tr "\n" " ")" "${setuphbasedir}"
    fi
  }

  ###############################################################
  #FUNCTION TO SETUP Zookeeper DIRS
  ###############################################################
  zkDirSetup() {
    rmcmd=" rm -rf"
    if [[ "$upgrade" == "yes" ]] ; then
      rmcmd="echo"
    fi
    zkdirs="${zk_log_dir} ${zk_pid_dir}"
    setupzkdirs=" mkdir -p ${zkdirs};  chmod 775 -R ${zkdirs} ;\
      chown -R ${zkuser} ${zkdirs}"
    setupzkdatadir="$rmcmd $zk_data_dir ;  mkdir -p ${zk_data_dir}; \
       chmod 755 -R ${zk_data_dir};  chown -R ${zkuser}:hadoop ${zk_data_dir}"
    if [[ $installzk == "yes" ]] ; then
      echo0 "Setting up various directories required by zookeeper"
      ssh2host "$(echo ${zkhosts} | tr "\n " " ")" "${setupzkdirs}; ${setupzkdatadir}"
    fi
  }

  ############################################################
  #FUNCTION TO INSTALL 64 BIT HADOOP JVM
  ############################################################
  installHadoop() {
    local pkgs="hadoop hadoop-libhdfs hadoop-native hadoop-pipes hadoop-sbin openssl"
    ssh2host "${1}" "${installpkgcmd} $pkgs ; [[ ! -f $hadoopjavahome || -L $hadoopjavahome ]] && ${hadoopjdklink}"
  }

  ############################################################
  #FUNCTION TO INSTALL Hadoop Lzo
  ############################################################
  installHadoopLzo() {
    if [ 'yes' != "$enablelzo" ]; then
      return
    fi
    local all_nodes="$1"
    echo0 "Deploying LZO"
    #command to install lzo
    local lzo_pkgs="lzo lzo-devel hadoop-lzo hadoop-lzo-native"
    local cmd="$installpkgcmd $lzo_pkgs"
    ssh2host "$all_nodes" "$cmd"
  }

  ############################################################
  #FUNCTION TO INSTALL JDK
  ############################################################
  installJdk() {
    if [[ "$installjava" == "true" && "$enablesecurity" == "yes" ]] ; then
      scp2host "${1}" \
        "$artifactdownloaddir/$jdk64name,\
        $artifactdownloaddir/$jcepolicyname" "${destdir}"
      ssh2host "${1}" \
            "${java64install_cmd};${jceinstall64_cmd}"
    elif [[ "$installjava" == "true" && "$enablesecurity" == "no" ]] ; then
      scp2host "${1}" \
        "$artifactdownloaddir/$jdk64name" "${destdir}"
      ssh2host "${1}" \
            "${java64install_cmd}" \
            "${destdir}"
    fi
  }

  ############################################################
  #FUNCTION TO INSTALL HADOOP CONFIGS
  ############################################################
  installHadoopConfigs() {
    echo0 "Installing Hadoop Configs"
    if [[ "${user_configs}" == "" ]] ; then
      hadoopconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/hadoop-conf.tar.gz hadoop-conf
    scp2host "${1}" "${artifactdownloaddir}/hadoop-conf.tar.gz" "${destdir}"
    conf_cmd="rm -rf ${hadoopconfdir}/* ; mkdir -p $hadoopconfdir ; \
      tar xvzf ${destdir}/hadoop-conf.tar.gz --strip-components 1 -C $hadoopconfdir ; chmod a+x ${hadoopconfdir}/health_check"
      ssh2host "${1}" "${conf_cmd}"
  }

  ############################################################
  #FUNCTION TO DEPLOY SNAPPY
  ############################################################
  deploySnappy() {

    if [ 'yes' != "$enablesnappy" ]; then
      return
    fi

    echo0 "Installing Snappy"
    #add links to the hadoop native code for snappy
    local cmd="ln -sf /usr/lib64/libsnappy.so ${hadoophome}/lib/native/Linux-amd64-64/."
    local nodes=$allhosts
    # if installing monitoring install hadoop on nagios server
    if [ 'yes' == "$enablemon" ]; then
      nodes="${nodes},${nagioshost}"
    fi
    local snappy_pkgs="snappy snappy-devel"
    ssh2host "$nodes" "$installpkgcmd $snappy_pkgs; $cmd"
  }

  ############################################################
  #FUNCTION TO DEPLOY HADOOP AND JDK
  ############################################################
  deployHadoop() {
    deployJdk
    echo0 "Deploying Hadoop"
    deployHadoopRpms
    deployHadoopConfigs
  }

  deployJdk() {
    echo0 "Installing JDK"
    installJdk "$(echo $allhosts_with_mon | tr " " ",")"
  }

  deployHadoopRpms() {
    echo0 "Deploying Hadoop RPMs"
    local nodes=$allhosts
    # if installing monitoring install hadoop on nagios server
    if [ 'yes' == "$enablemon" ]; then
      nodes="${nodes},${nagioshost}"
    fi

    installHadoop "$nodes"
    #install Lzo on all nodes
    installHadoopLzo "$nodes"

    if [[ "$enablesecurity" == "yes" ]] ; then
      local setupltc="chown root:hadoop ${hadoopconfdir}/taskcontroller.cfg ;\
        chmod 400 ${hadoopconfdir}/taskcontroller.cfg ;\
        chown root:hadoop ${hadoophome}/bin/task-controller ;\
        chmod 6050 ${hadoophome}/bin/task-controller;"
      ssh2host "${hadoopslavenodes}" "${setupltc}"
    fi
  }

  deployHadoopConfigs() {
    echo0 "Deploying Hadoop Configs"
    local nodes=$allhosts
    # if installing monitoring install hadoop on nagios server
    if [ 'yes' == "$enablemon" ]; then
      nodes="${nodes},${nagioshost}"
    fi
    installHadoopConfigs "$(echo $nodes | tr " " ",")"
  }

  ############################################################
  #FUNCTION TO START HADOOP SERVICES
  ############################################################
  startHadoop() {
    echo0 "Starting All Hadoop Services"
    formatHdfs
    startHdfs
    setupHdfsDirs
    startMapReduce
    echo "StartHadoop completed"
  }

  formatHdfs() {
    formatnamenode="yes Y | hadoop \
      --config ${hadoopconfdir} namenode -format"
    ssh2host "${nnhost}" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '$formatnamenode';"
  }

  startHdfs() {
    if [[ "$enablesecurity" == "yes" ]] ; then
      hdfssudoprefix="$SUDOUSERPREFIX root $SUDOCMDOPTION"
    else
      hdfssudoprefix="$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION"
    fi
    upgradeflag=""
    if [[ "$upgrade" == "yes" ]]; then
      upgradeflag="-upgrade"
    fi
    startnamenode="$hadoop_daemon start namenode ${upgradeflag}"
    startsnamenode="$hadoop_daemon start secondarynamenode ${upgradeflag}"
    startdn="$hadoop_daemon start datanode"

    ssh2host "${nnhost}" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '$startnamenode' "
    ssh2host "${snhost}" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '$startsnamenode' "
    ssh2host "${hadoopslavenodes}" "${hdfssudoprefix} '${startdn}'"

    # always wait for nn to leave safemode
    hadoopnnwaitforsafemodeoff
    local ret=$?
    if [[ "$ret" != "0" ]]; then
      echo "Namenode ${nnhost} failed to come out of safemode"
      dumpErrorExitStatus "HADOOP" "Hadoop Namenode failed to come out of safemode";
      exit 1
    fi
  }

  setupHdfsDirs() {
    setdfstmpperm="hadoop --config ${hadoopconfdir} fs -chmod 777 /tmp"
    createdfstmpdir="hadoop --config ${hadoopconfdir} fs -mkdir /tmp"
    createdfsdirs="hadoop --config ${hadoopconfdir} fs -mkdir /mapred/system"
    setdfsperms="hadoop --config ${hadoopconfdir} fs -chown ${mapreduser}:${mapreduser} /mapred /mapred/system"
    createsmoketestuserdir="hadoop --config ${hadoopconfdir} fs -mkdir /user/${smoke_test_user}"
    setsmoketestuserdirperms="hadoop --config ${hadoopconfdir} \
      fs -chown $smoke_test_user:$smoke_test_user /user/${smoke_test_user} "
    ssh2host "${gwhost}" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${kinitcmd} ${createdfsdirs}'; \
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${setdfsperms}'; \
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${createdfstmpdir}'; \
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${setdfstmpperm}';\
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${createsmoketestuserdir}';\
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${setsmoketestuserdirperms}'"
    if [[ "$installhbase" == "yes" ]] ; then
      ssh2host "${gwhost}" " \
          $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${kinitcmd} hadoop --config ${hadoopconfdir} fs -mkdir ${hbase_dfs_dir}'; \
          $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION 'hadoop --config ${hadoopconfdir} fs -chown ${hbaseuser}:${hbaseuser} ${hbase_dfs_dir}' ; \
          $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION 'hadoop --config ${hadoopconfdir} fs -chown ${hbaseuser}:${hbaseuser} ${hbase_dfs_dir}/..' ; \
          $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION 'hadoop --config ${hadoopconfdir} fs -mkdir /user/${hbaseuser}'; \
          $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION 'hadoop --config ${hadoopconfdir} fs -chown ${hbaseuser}:${hbaseuser} /user/${hbaseuser}' "
    fi
    if [[ "$installhive" == "yes" ]] ; then
      ssh2host "${gwhost}" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${kinitcmd} \
          hadoop --config ${hadoopconfdir} fs -mkdir /user/${hiveuser} /apps/hive/warehouse '; \
          $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION 'hadoop --config ${hadoopconfdir} fs -chown ${hiveuser}:${hiveuser} /user/${hiveuser}' ; \
          $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION 'hadoop --config ${hadoopconfdir} fs -chown -R ${hiveuser}:users  /apps/hive/warehouse '; \
          $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION 'hadoop --config ${hadoopconfdir} fs -chmod -R 775 /apps/hive/warehouse'"
    fi
    if [[ "$installoozie" == "yes" ]] ; then
      ssh2host "${gwhost}" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${kinitcmd} \
        hadoop --config ${hadoopconfdir} fs -mkdir /user/${oozieuser}'; \
        $SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION 'hadoop --config ${hadoopconfdir} fs -chown ${oozieuser}:hadoop /user/${oozieuser}'"
    fi
    if [[ "$installtempleton" == "yes" ]] ; then
      ssh2host "${gwhost}" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${kinitcmd} hadoop --config ${hadoopconfdir} fs -mkdir /user/templeton ; \
          hadoop --config ${hadoopconfdir} fs -chown -R ${templetonuser}:${templetonuser} /user/templeton ; \
          hadoop --config ${hadoopconfdir} fs -mkdir /apps/templeton ;  \
          hadoop --config ${hadoopconfdir} fs -copyFromLocal  /usr/share/HDP-templeton/${pigtarname} /apps/templeton/ ; \
          hadoop --config ${hadoopconfdir} fs -copyFromLocal  /usr/share/HDP-templeton/${hivetarname} /apps/templeton/ ; \
          hadoop --config ${hadoopconfdir} fs -copyFromLocal  ${hadoophome}/contrib/streaming/hadoop-streaming*.jar /apps/templeton/hadoop-streaming.jar ; \
          hadoop --config ${hadoopconfdir} fs -chown -R ${templetonuser}:users /apps/templeton ; \
          hadoop --config ${hadoopconfdir} fs -chmod -R 755 /apps/templeton'"
    fi
  }

  startMapReduce() {
    startjt="$hadoop_daemon start jobtracker"
    starttt="$hadoop_daemon start tasktracker"
    starths="$hadoop_daemon start historyserver"
    ssh2host "${jthost}" "$SUDOUSERPREFIX ${mapreduser} $SUDOCMDOPTION '${startjt}; ${starths}'"
    ssh2host "${hadoopslavenodes}" "$SUDOUSERPREFIX ${mapreduser} $SUDOCMDOPTION '${starttt}'"
  }

  ############################################################
  #FUNCTION TO WAIT FOR NAMENODE TO COME OUT OF SAFEMODE
  ############################################################
  hadoopnnwaitforsafemodeoff(){
    echo0 "Waiting ${nnsafemodetimeout} seconds for namenode to come out of safe mode"
    wait_count=0
    safemodecmd="hadoop --config ${hadoopconfdir} dfsadmin -safemode get"
    while (( "${wait_count}" < "${nnsafemodetimeout}" ))
    do
      sshgwfordfssafemode "\"$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${kinitcmd} ${safemodecmd}'\""
      ret=$?
      if [ "$ret" == "0" ]
      then
        return 0
      fi
      (( wait_count+=5 ))
      sleep 5s
    done
    echo "Namenode failed to come out of safe mode in ${nnsafemodetimeout} seconds"
    return 1
  }

  ############################################################
  #FUNCTION TO START ZOOKEEPER SERVER
  ############################################################
  startZk() {
    if [[ "$installzk" == "yes" ]] ; then
      echo0 "Starting Zookeeper Server"
      startzkServer="${zkhome}/bin/zkServer.sh start >> ${zk_log_dir}/zoo.out 2>&1"
        myid=1
        for i in $zkhosts
          do
            ssh2host "${i}" "$SUDOUSERPREFIX ${zkuser} $SUDOCMDOPTION 'echo ${myid} > ${zk_data_dir}/myid'"
            # since ZOOKEEPER-999 is not there, as a workaround source zookeeper-env.sh before startig
            ssh2host "${i}" "$SUDOUSERPREFIX ${zkuser} $SUDOCMDOPTION 'source ${zkconfdir}/zookeeper-env.sh ; export ZOOCFGDIR=$zkconfdir;${startzkServer}'"
            ((myid++))
            sleep 30
        done
      fi
  }


  #########################################################
  #FUNCTION TO STOP ALL GRID STACK DAEMONS
  #########################################################
  killAllJava() {
    echo0 "Stop all Java Process"
    sshall "ps -ef | grep [j]ava | awk '{ print \$2 }' | xargs  kill -9 "
  }


  #############################################################
  #FUNCTION TO INSTALL HBASE
  ############################################################
  installHbase() {
    echo0 "Deploying Hbase"
    hbase_cmd="${installpkgcmd} hbase"
    ssh2host "${1}" "${hbase_cmd}"
    ssh2host "${1}" "[[ ! -f $hbasejavahome || -L $hbasejavahome ]] && ${hbasejdklink};"
  }

  ############################################################
  #FUNCTION TO INSTALL HBASE CONFIGS
  ############################################################
  installHbaseConfigs() {
    relevant_hbase_metrics_conf=""

    case "${2}" in
      'M')
        echo0 "Installing Hbase Configs for Master"
        relevant_hbase_metrics_conf="hadoop-metrics.properties.master-GANGLIA"
        ;;
      'R')
        echo0 "Installing Hbase Configs for RegionServers"
        relevant_hbase_metrics_conf="hadoop-metrics.properties.regionservers-GANGLIA"
        ;;
      *)
        echo0 "Installing Hbase Configs"
        relevant_hbase_metrics_conf="hadoop-metrics.properties"
        ;;
    esac

    # When monitoring is enabled, this will end up getting called twice, but I
    # don't see anything really bad resulting from that (other than wasted effort).
    if [[ "${user_configs}" == "" ]] ; then
      hbaseconfgen
    fi

    cd ${confRoot};
    # There can be only one (hadoop-metrics.properties)!
    # Redirect stderr to /dev/null in case we fell into the *) bucket above
    # and end up copying hadoop-metrics.properties to itself.
    cp hbase-conf/${relevant_hbase_metrics_conf} hbase-conf/hadoop-metrics.properties 2>/dev/null
    # By this point, we have the one true hadoop-metrics.properties, so exclude
    # any of the raw Ganglia-specific config files from being a part of the
    # tarball that lands up on ${1}.
    tar czf ${artifactdownloaddir}/hbase-conf.tar.gz --exclude='*GANGLIA*' hbase-conf
    scp2host "${1}" "${artifactdownloaddir}/hbase-conf.tar.gz" "${destdir}"
    conf_cmd="rm -rf ${hbaseconfdir}/*; mkdir -p ${hbaseconfdir}; \
      tar xvzf ${destdir}/hbase-conf.tar.gz --strip-components 1 -C ${hbaseconfdir}; "
    ssh2host "${1}" "${conf_cmd}"
  }

  ############################################################
  #FUNCTION TO START HBASE SERVICES
  ############################################################
  startHbase() {
    if [[ "$installhbase" == "yes" ]] ; then
      echo0 "Starting Hbase Server"
      starthbasemaster="${hbasehome}/bin/hbase-daemon.sh --config ${hbaseconfdir} start master"
      starthbasers="${hbasehome}/bin/hbase-daemon.sh --config ${hbaseconfdir} start regionserver"
      ssh2host "${hbmhost}" "$SUDOUSERPREFIX ${hbaseuser} $SUDOCMDOPTION '${starthbasemaster}'"
      #add a sleep
      #unilt we have HBASE-5849
      #sleep 20
      ssh2host "$(echo $rshosts | tr " " ",")" "$SUDOUSERPREFIX ${hbaseuser} $SUDOCMDOPTION '${starthbasers}'"
      #sleep 20
    fi
  }

  ############################################################
  #FUNCTION TO INSTALL PIG RPM
  ############################################################
  deployPig() {
    if [[ "$installpig" == "yes" ]] ; then
      deployPigRpms
      deployPigConfigs
    fi
  }

  deployPigRpms() {
    local nodes=$gwhost
    # if installing monitoring install hadoop on nagios server
    if [ 'yes' == "$enablemon" ]; then
      nodes="${nodes},${nagioshost}"
    fi
    installPig "$nodes"
  }

  deployPigConfigs() {
    local nodes=$gwhost
    # if installing monitoring install hadoop on nagios server
    if [ 'yes' == "$enablemon" ]; then
      nodes="${nodes},${nagioshost}"
    fi
    installPigConfigs "$nodes"
  }

  ############################################################
  #FUNCTION TO INSTALL PIG
  ############################################################
  installPig() {
    echo0 "Deploying Pig"
    pig_cmd="${installpkgcmd} pig"
    ssh2host "$1" "${pig_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL PIG CONFIGS
  ############################################################
  installPigConfigs() {
    echo0 "Installing Pig Configs"
    if [[ "${user_configs}" == "" ]] ; then
      pigconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/pig-conf.tar.gz pig-conf
    scp2host "${1}" "${artifactdownloaddir}/pig-conf.tar.gz" "${destdir}"
    conf_cmd="rm -rf ${pigconfdir}/* ; mkdir -p ${pigconfdir} ; \
        tar xzf ${destdir}/pig-conf.tar.gz --strip-components 1 -C ${pigconfdir};"
    ssh2host "${1}" "${conf_cmd}"
  }


  ############################################################
  #FUNCTION TO DEPLOY HIVE
  ############################################################
  deployHive() {
    if [[ "$installhive" == "yes" ]] ; then
      deployHiveRpms
      deployHiveConfigs
    fi
  }
  
  ############################################################
  #FUNCTION TO DEPLOY HCAT
  ############################################################
  deployHcat() {
    if [[ "$installhcat" == "yes" ]] ; then
      deployHcatRpms
    fi
  }

  ############################################################
  #FUNCTION TO INSTALL HCAT
  ############################################################
  deployHcatRpms() {
    echo0 "Deploying Hcat"
    local nodes="$gwhost"
    # if installing monitoring install hadoop on nagios server
    if [ 'yes' == "$enablemon" ]; then
      nodes="${nodes},${nagioshost}"
    fi
    if [ 'yes' == "$installtempleton" ]; then
      nodes="$nodes,$ttonhosts"
    fi
    if [ 'yes' == "$enablemon" ]; then
      nodes="$nodes,$nagioshost"
    fi
    ssh2host "$nodes" "$installpkgcmd hcatalog"
  }


  ############################################################
  #FUNCTION TO INSTALL HIVE
  ############################################################
  deployHiveRpms() {
    echo0 "Deploying Hive"
    local nodes="$gwhost"
    # if installing monitoring install hadoop on nagios server
    if [ 'yes' == "$enablemon" ]; then
      nodes="${nodes},${nagioshost}"
    fi
    #need to install hive and hcatalog on the same box
    ssh2host "$nodes" "$installpkgcmd hive hcatalog"
    

    #cmd to copy over the mysql jar
    mysql_connector_path="${hivehome}/lib"
    local cmd="ln -sf /usr/share/java/mysql-connector-java.jar ${mysql_connector_path}/."
    ssh2host "$hivehost" "$installpkgcmd hive hcatalog mysql-connector-java-5.0.8-1; $cmd"
  }

  ############################################################
  #FUNCTION TO INSTALL HIVE CONFIGS
  ############################################################
  deployHiveConfigs() {
    echo0 "Installing Hive Configs"
    if [[ "${user_configs}" == "" ]] ; then
      hiveconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/hive-conf.tar.gz hive-conf;

    local clientnodes="${hivehost},$gwhost";

    if [[ "$installtempleton" == "yes" ]] ; then
      clientnodes="$(echo $ttonhosts | tr " " ","),${clientnodes}"
    fi
    if [ 'yes' == "$enablemon" ]; then
      clientnodes="$clientnodes,$nagioshost"
    fi

    scp2host "${clientnodes}" "${artifactdownloaddir}/hive-conf.tar.gz" "${destdir}"

    conf_cmd="rm -rf ${hiveconfdir}/* ; mkdir -p ${hiveconfdir} ; \
    tar xzf ${destdir}/hive-conf.tar.gz --strip-components 1 -C ${hiveconfdir} "
    ssh2host "${clientnodes}" "${conf_cmd}"
  }

  ############################################################
  #FUNCTION TO START HIVE SERVER
  ############################################################
  startHive() {
    if [[ "$installhive" == "yes" ]] ; then
      echo0 "Starting Hive Metastore Server"
      starthive="nohup hive --service metastore > ${hive_log_dir}/hive.out 2> ${hive_log_dir}/hive.log &"
      ssh2host "${hivehost}" "$SUDOUSERPREFIX ${hiveuser} $SUDOCMDOPTION '${starthive}'"
    fi
  }

  ############################################################
  #FUNCTION TO DEPLOY TEMPLETON
  ############################################################
  deployTempleton() {
    if [[ "$installtempleton" == "yes" ]] ; then
      deployTempletonRpms
      deployTempletonConfigs
    fi
  }

  deployTempletonRpms() {
    installTempleton  "$(echo $ttonhosts | tr " " ",")"
  }

  deployTempletonConfigs() {
    installTempletonConfigs  "$ttonhosts,$gwhost"
  }

  ############################################################
  #FUNCTION TO INSTALL TEMPLETON
  ############################################################
  installTempleton() {
    echo0 "Deploying Templeton"
    #command to create the templeton jar link
    #unfortunately this a version specific link :(
    templeton_jar_link="ln -s /usr/share/templeton/templeton-${templeton_version}.jar /usr/share/templeton/templeton.jar"
    templeton_cmd="${installpkgcmd} templeton ; $templeton_jar_link"
    ssh2host "${1}" "${templeton_cmd}"
    
    #install hive and pig tar balls to the gateway
    templeton_gwy_cmd="${installpkgcmd} templeton-tar-hive templeton-tar-pig"
    ssh2host "$gwhost" "${templeton_gwy_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL TEMPLETON CONFIGS
  ############################################################
  installTempletonConfigs() {
    echo0 "Installing Templeton Configs"
    if [[ "${user_configs}" == "" ]] ; then
      templetonconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/templeton-conf.tar.gz templeton-conf;
    scp2host "${1}" "${artifactdownloaddir}/templeton-conf.tar.gz" "${destdir}"
    conf_cmd="rm -rf ${templetonconfdir}/*  ; mkdir -p $templetonconfdir; \
        tar xzf ${destdir}/templeton-conf.tar.gz  --strip-components 1 -C $templetonconfdir "
    ssh2host "${1}" "${conf_cmd}"
  }
  ############################################################
  #FUNCTION TO START TEMPLETON SERVER
  ############################################################
  startTempleton() {
    if [[ "$installtempleton" == "yes" ]] ; then
      echo0 "Starting Templeton Server"
      #setup,start each templeton server
      for i in $ttonhosts
      do
        ssh2host "${i}" "$SUDOUSERPREFIX ${templetonuser} $SUDOCMDOPTION '/usr/sbin/templeton_server.sh start' "
      done
    fi
  }


  ############################################################
  #FUNCTION TO DEPLOY OOZIE
  ############################################################
  deployOozie() {
    if [[ "$installoozie" == "yes" ]] ; then
      deployOozieRpms
      deployOozieConfigs
    fi
  }

  deployOozieRpms() {
    local nodes="$oozieshost"
    if [ 'yes' == "$enablemon" ]; then
       nodes="$nodes,$nagioshost" 
    fi
    installOozie "$(echo $nodes | tr " " ","),$gwhost"
  }

  deployOozieConfigs() {
    local nodes="$oozieshost"
    if [ 'yes' == "$enablemon" ]; then
      nodes="$nodes,$nagioshost"
    fi
    installOozieConfigs "$(echo $nodes | tr " " ","),$gwhost"
  }

  ############################################################
  #FUNCTION TO INSTALL OOZIE
  ############################################################
  installOozie() {
    echo0 "Deploying Oozie"
    oozie_server_cmd="${installpkgcmd} oozie extjs-2.2-1"
    oozie_client_cmd="${installpkgcmd} oozie-client"
    ssh2host "${oozieshost}" "${oozie_server_cmd}; ${ooziejdklink}"
    ssh2host "${gwhost}" "${oozie_client_cmd}; [[ ! -f $ooziejavahome || -L $ooziejavahome ]] && ${ooziejdklink}"
    ssh2host "${nagioshost}" "${oozie_client_cmd}; [[ ! -f $ooziejavahome || -L $ooziejavahome ]] && ${ooziejdklink}"
  }

  ############################################################
  #FUNCTION TO INSTALL OOZIE CONFIGS
  ############################################################
  installOozieConfigs() {
    echo0 "Installing Oozie Configs"
    if [[ "${user_configs}" == "" ]] ; then
      oozieconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/oozie-conf.tar.gz oozie-conf;
    scp2host "${1}" "${artifactdownloaddir}/oozie-conf.tar.gz" "${destdir}"
    conf_cmd="rm -rf ${oozieconfdir}/* ; mkdir -p ${oozieconfdir} ; \
        tar xzf ${destdir}/oozie-conf.tar.gz --strip-components 1 -C ${oozieconfdir} "
    ssh2host "${1}" "${conf_cmd}"

    #clean up any old links
    ssh2host "${oozieshost}" "rm -f ${ooziehome}/oozie-server/lib/{core,hdfs,mapred}-site.xml"
    #create new links
    ssh2host "${oozieshost}" "ln -s  ${hadoopconfdir}/mapred-site.xml ${ooziehome}/oozie-server/lib/mapred-site.xml ; ln -s ${oozieconfdir}/core-site.xml ${ooziehome}/oozie-server/lib/core-site.xml"
  }

  ############################################################
  #FUNCTION TO START Oozie SERVER
  ############################################################
  startOozie() {
    if [[ "$installoozie" == "yes" ]] ; then
      echo0 "Starting Oozie Server"
      startoozieserver="${ooziehome}/bin/oozie-start.sh"
      ssh2host "${oozieshost}" "$SUDOUSERPREFIX ${oozieuser} $SUDOCMDOPTION \"cd ${oozie_log_dir}; ${startoozieserver}\""
    fi
  }

  ############################################################
  #FUNCTION TO DEPLOY ZOOKEEPER
  ############################################################
  deployZookeeper() {
    if [[ "$installzk" == "yes" ]] ; then
      local all_nodes="$(echo $zkhosts | tr " " ","),$gwhost"
      #add templeton nodes if templeton is being installed
      if [ 'yes' == "$installtempleton" ]; then
        all_nodes="${all_nodes},$(echo $ttonhosts | tr " " ",")"
      fi
      # if installing monitoring install hadoop on nagios server
      if [ 'yes' == "$enablemon" ]; then
        all_nodes="${all_nodes},${nagioshost}"
      fi
      deployZkRpms "$all_nodes"
      deployZkConfigs "$all_nodes"
    fi
  }

  ############################################################
  #FUNCTION TO DEPLOY HBASE
  ############################################################
  deployHbase() {
    if [[ "$installhbase" == "yes" ]] ; then
      deployHbaseRpms
      deployHbaseConfigs
    fi
  }

  deployZkRpms() {
    echo0 "Deploying Zookeeper RPMs"
    installZk "$1"
  }

  deployHbaseRpms() {
    echo0 "Deploying HBase RPMs"
    local nodes="${hbmhost},${rshosts},${gwhost}"
    # if installing monitoring install hadoop on nagios server
    if [ 'yes' == "$enablemon" ]; then
      nodes="${nodes},${nagioshost}"
    fi
    installHbase "$(echo $nodes | tr " " ",")"
  }

  deployZkConfigs() {
    echo0 "Deploying Zookeeper Configs"
    installZkConfigs "$1"
  }

  deployHbaseConfigs() {
    echo0 "Deploying HBase Configs"
    # If monitoring is enabled, invoke installHbaseConfigs() separately for
    # the HBase Master and the RegionServers because they both require slightly
    # different configurations, but look for the same filename
    # (hadoop-metrics.properties), so we need to be a wee bit context-sensitive
    # when performing the install.
    #
    # XXX: What happens to the state on $gwhost in this case? What version of
    #      the truth should it be aware of?
    if [[ "$enablemon" == "yes" ]] ; then
      installHbaseConfigs "$(echo $hbmhost | tr " " ","),$gwhost" "M" # M-> Master
      installHbaseConfigs "$(echo $rshosts | tr " " ","),$gwhost,$nagioshost" "R" # R-> RegionServers
    else
      installHbaseConfigs "$(echo $hbmhost | tr " " ","),$(echo $rshosts | tr " " ","),$gwhost" "X" # X-> Don't Care
    fi
  }

  ############################################################
  #FUNCTION TO INSTALL ZOOKEEPER RPM
  ############################################################
  installZk() {
    zk_cmd="${installpkgcmd} zookeeper"
    ssh2host "${1}" "${zk_cmd} ; [[ ! -f $zkjavahome || -L $zkjavahome ]] && ${zkjdklink}"
  }

  ############################################################
  #FUNCTION TO INSTALL ZOOKEEPER CONFIGS
  ############################################################
  installZkConfigs() {
    echo0 "Installing Zookeeper Configs"
    if [[ "${user_configs}" == "" ]] ; then
      zkconfgen
    fi
    cd ${confRoot}; tar czf ${artifactdownloaddir}/zk-conf.tar.gz zk-conf
    scp2host "${1}" "${artifactdownloaddir}/zk-conf.tar.gz" "${destdir}"
    conf_cmd="rm -rf ${zkconfdir}/* ; mkdir -p ${zkconfdir} ; \
    tar xvzf ${destdir}/zk-conf.tar.gz --strip-components 1 -C ${zkconfdir} ; "
    ssh2host "${1}" "${conf_cmd}"
  }

  ############################################################
  #FUNCTION TO INSTALL SQOOP RPM
  ############################################################
  deploySqoop() {
    if [[ "$installsqoop" == "yes" ]] ; then
      deploySqoopRpms
      deploySqoopConfigs
    fi
  }

  deploySqoopRpms() {
    installSqoop "$gwhost"
  }

  deploySqoopConfigs() {
    installSqoopConfigs "$gwhost"
  }

  ############################################################
  #FUNCTION TO INSTALL SQOOP
  ############################################################
  installSqoop() {
    echo0 "Deploying Sqoop"
    
    sqoop_cmd="${installpkgcmd} sqoop mysql-connector-java-5.0.8-1"
    local cmd="ln -sf /usr/share/java/mysql-connector-java.jar ${sqoophome}/lib/."
  
    ssh2host "$gwhost" "${sqoop_cmd} ; $cmd"
  }

  ############################################################
  #FUNCTION TO INSTALL SQOOP CONFIGS
  ############################################################
  installSqoopConfigs() {
    echo0 "Installing Sqoop Configs"
    sqoopconfgen
    cd ${confRoot}; tar czf ${artifactdownloaddir}/sqoop-conf.tar.gz sqoop-conf
    scp2host "${1}" "${artifactdownloaddir}/sqoop-conf.tar.gz" "${destdir}"
    conf_cmd="rm -rf ${sqoopconfdir}/* ; mkdir -p ${sqoopconfdir}; \
      tar xvzf ${destdir}/sqoop-conf.tar.gz --strip-components 1 -C ${sqoopconfdir}"
      ssh2host "${1}" "${conf_cmd}"
  }

  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON OOZIE
  ############################################################
  checkOozieJobStatus() {
    local job_id=$1
    local num_of_tries=$2
    #default num_of_tries to 10 if not present
    num_of_tries=${num_of_tries:-10}
    local i=0
    local rc=1
    local cmd="$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION \"/usr/bin/oozie job --oozie http://${oozieshost}:11000/oozie -info $job_id | grep '^Status'\""
    while [ $i -lt $num_of_tries ]
    do
      cmd_output=`ssh2hostwithreturnvalue "$gwhost" "$cmd" | sed 's/[ \r]//g'`
      act_status="`echo $cmd_output | cut -d':' -f2`"
      if [ "RUNNING" == "$act_status" ]; then
       #increment the couner and get the status again after waiting for 15 secs
       sleep 15
       (( i++ ))
      elif [ "SUCCEEDED" == "$act_status" ]; then
        rc=0;
        break;
      else
        rc=1
        break;
      fi
    done
    return $rc
  }

  runOozieSmokeTest() {
    if [[ "$installoozie" == "yes" ]] ; then
      JOB_SCRIPTS_DIR_NAME=${destdir}/oozie-examples
      JT=${jthost}:50300
      FS=hdfs://${nnhost}:8020
      echo0 "Initiate oozie smoke tests 1"
      local job_prop_file="examples/apps/map-reduce/job.properties"
      local test_setup_cmd="mkdir -p $JOB_SCRIPTS_DIR_NAME; \
      cd $JOB_SCRIPTS_DIR_NAME; \
      rpm -ql oozie-client | grep 'oozie-examples.tar.gz$' | head -n1 | xargs tar -xzf; \
      sed -i 's|nameNode=.*|nameNode=$FS|g'  $job_prop_file; \
      sed -i 's|jobTracker=.*|jobTracker=$JT|g' $job_prop_file; \
      sed -i 's|oozie.wf.application.path=hdfs://localhost:9000|oozie.wf.application.path=$FS|g' $job_prop_file"
      
      if [ 'yes' == "$security" ]; then
        test_setup_cmd="$test_setup_cmd ; echo 'dfs.namenode.kerberos.principal=nn/${nnhost}@${realm}' >> $job_prop_file ; echo 'mapreduce.jobtracker.kerberos.principal=jt/${jthost}@${realm}' >> $job_prop_file " 
      fi

      ssh2host $gwhost "$test_setup_cmd" 
      ssh2host $gwhost "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION 'hadoop dfs -copyFromLocal ${JOB_SCRIPTS_DIR_NAME}/examples examples'"
      ssh2host $gwhost "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION 'hadoop dfs -copyFromLocal ${JOB_SCRIPTS_DIR_NAME}/examples/input-data input-data'"

      local cmd="/usr/bin/oozie job -oozie http://$oozieshost:11000/oozie -config $JOB_SCRIPTS_DIR_NAME/$job_prop_file  -run"
      if [ 'yes' == "$security" ]; then
        cmd="$kinitcmd_smoke_test_user $cmd"
      fi
      local job_info=`ssh2hostwithreturnvalue $gwhost "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '$cmd'" | grep "job:" | sed 's/[ \r]//g'`
      local job_id="`echo $job_info | cut -d':' -f2`"
      checkOozieJobStatus "$job_id"
      OOZIE_EXIT_CODE="$?"
      #Oozie
      displaySmokeTestResult "Oozie" "$OOZIE_EXIT_CODE"
    fi
  }

  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON HADOOP
  ############################################################
  runHadoopSmokeTest(){
    nnweburl="http://${nnhost}:50070"
    jtweburl="http://${jthost}:50030"
    jhweburl="http://${jthost}:51111/jobhistoryhome.jsp"
    echo0 "Hadoop smoke test - wordcount using /etc/passwd file"
    local outname=`date +"%M%d%y"`
    sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '$kinitcmd_smoke_test_user \
      hadoop dfs -copyFromLocal /etc/passwd passwd-${outname} ; hadoop dfs -ls '"
    sshgwforsmoke "$SUDOUSERPREFIX  ${smoke_test_user} \
      $SUDOCMDOPTION 'hadoop jar ${hadoophome}/hadoop-examples.jar \
       wordcount passwd-${outname} ${outname}.out '"
    export HADOOP_EXIT_CODE=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${smoke_test_user} \
      $SUDOCMDOPTION 'hadoop fs -test -e ${outname}.out > /dev/null 2>&1; echo \\\$? '" | sed 's/[ \r]//g'`
    if [[ "$HADOOP_EXIT_CODE" -ne "0" ]] ; then  echo0 "Hadoop Smoke Test: Failed" ; \
      dumpErrorExitStatus "SMOKE_TEST" "Hadoop Smoke Test Failed"; \
      exit 1 ; else echo0 "Hadoop Smoke Test: Passed" ; fi
    if [[ `checkurl "$nnweburl"` -eq 0 ]] ; then echo0 "NameNode web $nnweburl accessible";
      else echo0 "NameNode web $nnweburl not accessible"; fi
    if [[ `checkurl "$jtweburl"` -eq 0 ]] ; then echo0 "Jobtracker web $jtweburl accessible";
      else echo0 "Jobtracker web $jtweburl not accessible"; fi
    if [[ `checkurl "$jhweburl"` -eq 0 ]] ; then echo0 "Jobhistory web $jhweburl accessible";
      else echo0 "Jobhistory web $jhweburl not accessible"; fi
 }

  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON PIG
  ############################################################
  runPigSmokeTest() {
    if [ $installpig == "yes" ] ; then
      echo0 "Pig smoke test - wordcount using /etc/passwd file"
      sshgwforsmoke 'echo "A = load '\''passwd'\'' using PigStorage('\'':'\''); " > /tmp/id.pig '
      sshgwforsmoke 'echo "B = foreach A generate \$0 as id; store B into '\''/tmp/id.out'\''; " >> /tmp/id.pig '
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '${kinitcmd_smoke_test_user} \
        hadoop dfs -rmr passwd /tmp/id.out'"
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '${kinitcmd_smoke_test_user} \
        hadoop dfs -copyFromLocal /etc/passwd passwd ; hadoop dfs -ls '"
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION 'pig -l /tmp/pig.log /tmp/id.pig'"
      export PIG_EXIT_CODE=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${smoke_test_user} \
       $SUDOCMDOPTION 'hadoop fs -test -e /tmp/id.out > /dev/null 2>&1; echo \\\$? '" | sed 's/[ \r]//g'`
      if [[ "$PIG_EXIT_CODE" -ne "0" ]] ; then  echo0 "Pig Smoke Test: Failed" ; \
        return 1 ; else echo0 "Pig Smoke Test: Passed" ; fi
      fi
  }

  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON HCAT
  ############################################################
  runHcatSmokeTest() {
  if [[ "$installhcat" == "yes" ]] ; then
    echo0 "Hcatalog smoke test - show tables, create table, and drop table"
    echo "hcat -e 'show tables'" > ${artifactdownloaddir}/hcatsmoke.sh
    echo "hcat -e 'drop table IF EXISTS hcatsmoke$$;'" >> ${artifactdownloaddir}/hcatsmoke.sh
    echo "hcat -e 'create table hcatsmoke$$ ( id INT, name string ) stored as rcfile ;'" >> ${artifactdownloaddir}/hcatsmoke.sh
    [[ -f ${artifactdownloaddir}/hcatsmoke.sh ]] && chmod 755 ${artifactdownloaddir}/hcatsmoke.sh
    scp2host "${gwhost}" "${artifactdownloaddir}/hcatsmoke.sh" "${destdir}/hcatsmoke.sh"
    if [[ "$security" == "no" ]] ; then
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '${destdir}/hcatsmoke.sh'"
    else
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '${kinitcmd_smoke_test_user} ${destdir}/hcatsmoke.sh'"
    fi
    export HCAT_EXIT_CODE=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${kinitcmd} hadoop --config ${hadoopconfdir} \
      fs -test -e /apps/hive/warehouse/hcatsmoke$$ > /dev/null 2>&1; echo \\\$?'" | sed 's/[ \r]//g'`
    if [[ "$HCAT_EXIT_CODE" -ne "0" ]] ; then  echo0 "Hcat Smoke Test: Failed" ; \
      return 1 ; else echo0 "Hcat Smoke Test: Passed" ; fi
  fi
  }

  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON SQOOP
  ############################################################
  runSqoopSmokeTest() {
    #only run sqoop tests if sqoop is installed
    if [ "yes" != "$installsqoop" ]; then
      return 0
    fi

    echo0 "Sqoop smoke test - version"
    sqoop_smoke_cmd="sqoop version | grep 'Sqoop [0-9].*'"
    local cmd
    if [ 'yes' == "$security" ]; then
      cmd="$kinitcmd_smoke_test_user $sqoop_smoke_cmd"
    else
      cmd=$sqoop_smoke_cmd
    fi
    ssh2host "$gwhost" "$cmd"
    SQOOP_EXIT_CODE="$?"
    #Sqoop
    displaySmokeTestResult "Sqoop" "$SQOOP_EXIT_CODE"
  }

  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON TEMPLETON
  ############################################################
  runTempletonSmokeTest() {
  if [[ "$installtempleton" == "yes" ]] ; then
      echo0 "Running templeton smoke tests"
      ttonhost=`echo $ttonhosts | cut -f1 -d ' '`
      ttonhost="${ttonhost%\\n}"
      ttonurl="http://${ttonhost}:50111/templeton/v1"

      export TEMPLETON_EXIT_CODE=0;

      #test status cmd
      local retVal=`ssh2hostwithreturnvalue $gwhost  "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION \
      '$kinitcmd_smoke_test_user curl --negotiate -u : -s -w \"http_code <%{http_code}>\"    $ttonurl/status 2>&1' "`
      local httpExitCode=`echo $retVal |sed 's/.*http_code <\([0-9]*\)>.*/\1/'`

      if [[ "$httpExitCode" -ne "200" ]] ;
        then
          echo0 "Templeton Smoke Test (status cmd): Failed. : $retVal"
          export TEMPLETON_EXIT_CODE=1
          return 1
      fi

      #try hcat ddl command
      echo "user.name=${smoke_test_user}&exec=show databases;" > ${artifactdownloaddir}/show_db.post.txt
      scp2host  "${gwhost}" "${artifactdownloaddir}/show_db.post.txt" "${destdir}"

      local retVal=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION \
       '$kinitcmd_smoke_test_user curl --negotiate -u : -s -w \"http_code <%{http_code}>\" -d  \@${destdir}/show_db.post.txt  $ttonurl/ddl 2>&1'  " `
      local httpExitCode=`echo $retVal |sed 's/.*http_code <\([0-9]*\)>.*/\1/'`


      if [[ "$httpExitCode" -ne "200" ]] ;
        then
          echo0 "Templeton Smoke Test (ddl cmd): Failed. : $retVal"
          export TEMPLETON_EXIT_CODE=1
          return 1
      fi

      #only run pig tests when doing unsecure
      if [[ "$security" == "no" ]] ; then 
        #      #try pig query
        #      #create pig query first
        local outname=${smoke_test_user}.`date +"%M%d%y"`.$$;
        local ttonTestOutput="/tmp/idtest.${outname}.out";
        local ttonTestInput="/tmp/idtest.${outname}.in";
        local ttonTestScript="idtest.${outname}.pig"
        echo "A = load '$ttonTestInput' using PigStorage(':');"  > ${artifactdownloaddir}/$ttonTestScript
        echo "B = foreach A generate \$0 as id; " >> ${artifactdownloaddir}/$ttonTestScript
        echo "store B into '$ttonTestOutput';" >> ${artifactdownloaddir}/$ttonTestScript
        scp2host  "${gwhost}" "${artifactdownloaddir}/$ttonTestScript" "${destdir}/$ttonTestScript"
        #copy pig script to hdfs
        sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '$kinitcmd_smoke_test_user \
          hadoop dfs -copyFromLocal ${destdir}/$ttonTestScript /tmp/$ttonTestScript  ; '"
        #copy input file to hdfs
        sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '$kinitcmd_smoke_test_user \
          hadoop dfs -copyFromLocal /etc/passwd $ttonTestInput ; '"
  
        local tuser=${smoke_test_user}
  
        #create, copy post args file
        echo -n "user.name=${tuser}&file=/tmp/$ttonTestScript" > \
        ${artifactdownloaddir}/pig_post.txt
        scp2host  "${gwhost}" "${artifactdownloaddir}/pig_post.txt" "${destdir}"
  
        #submit pig query
        local retVal=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION \
         '$kinitcmd_smoke_test_user curl --negotiate -u : -s -w \"http_code <%{http_code}>\" -d  \@${destdir}/pig_post.txt  $ttonurl/pig 2>&1'" `
  
        local httpExitCode=`echo $retVal |sed 's/.*http_code <\([0-9]*\)>.*/\1/'`
        if [[ "$httpExitCode" -ne "200" ]] ;
          then
            echo0 "Templeton Smoke Test (pig cmd): Failed. : $retVal"
            export TEMPLETON_EXIT_CODE=1
            return 1
  
        fi
      fi
      echo0 "Templeton Smoke Test: Passed"
  fi
  }

  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON HBASE
  ############################################################
  runHbaseSmokeTest() {
    if [ "$installhbase" == "yes" ] ; then
      echo0 "Hbase smoke test - disable, drop, create, alter and scan table"
      local hbaseweburl="http://$hbmhost:60010/master-status"
      local outname=`date +"%M%d%y"`
      export HBASE_EXIT_CODE=0

      sshgwforsmoke 'echo "echo status | hbase shell" > /tmp/hbasesmoke.sh '
      sshgwforsmoke 'echo "echo disable \\'\''usertable\\'\'' | hbase shell" >> /tmp/hbasesmoke.sh '
      sshgwforsmoke 'echo "echo drop \\'\''usertable\\'\'' | hbase shell" >> /tmp/hbasesmoke.sh '
      sshgwforsmoke 'echo "echo create \\'\''usertable\\'\'', \\'\''family\\'\'' \
        | hbase shell" >> /tmp/hbasesmoke.sh '
      sshgwforsmoke 'echo "echo put \\'\''usertable\\'\'', \\'\''row01\\'\'',\
        \\'\''family:col01\\'\'', \\'\''value1\\'\'' | hbase shell" >> /tmp/hbasesmoke.sh'
      sshgwforsmoke 'echo "echo scan \\'\''usertable\\'\'' | hbase shell" >> /tmp/hbasesmoke.sh '
      output=`sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '${kinitcmd_smoke_test_user} sh /tmp/hbasesmoke.sh'"`
      (IFS='';echo $output)
      tmpOutput=$(echo $output | grep -v '0 servers')
      HBASE_SMOKE_EXIT_CODE=$?
      ((HBASE_EXIT_CODE=$HBASE_EXIT_CODE+$HBASE_SMOKE_EXIT_CODE))
      export HBASE_SMOKE_EXIT_CODE=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION 'hadoop \
      fs -test -e /apps/hbase/data/usertable > /dev/null 2>&1; echo \\\$? '" | sed 's/[ \r]//g'`
      ((HBASE_EXIT_CODE=$HBASE_EXIT_CODE+$HBASE_SMOKE_EXIT_CODE))
      if [[ "$HBASE_EXIT_CODE" -ne "0" ]] ; then  echo0 "Hbase Smoke Test: Failed" ; \
         return 1 ; else echo0 "Hbase Smoke Test: Passed" ; fi
      if [[ `checkurl "$hbaseweburl"` -eq 0 ]] ; then echo0 "Hbase Master url $hbaseweburl accessible"; \
        else echo0 "Hbase Master url $hbaseweburl not accessible"; fi
    fi
  }



  ############################################################
  #FUNCTION TO INITATE SMOKE TEST ON HIVE
  ############################################################
  runHiveSmokeTest() {
    if [ "$installhive" == "yes" ] ; then
      echo0 "Hive smoke test - create table and describe table"
      echo "echo \"CREATE EXTERNAL TABLE IF NOT EXISTS hivesmoke$$ ( foo INT, bar STRING );\" \
        | hive" > ${artifactdownloaddir}/hivesmoke.sh
      echo "echo \"DESCRIBE hivesmoke$$;\" | hive" >> ${artifactdownloaddir}/hivesmoke.sh
      [[ -f ${artifactdownloaddir}/hivesmoke.sh ]] && chmod 755 ${artifactdownloaddir}/hivesmoke.sh
      scp2host "${gwhost}" "${artifactdownloaddir}/hivesmoke.sh" "${destdir}/hivesmoke.sh"
      if [[ "$security" == "no" ]] ; then
        sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '${destdir}/hivesmoke.sh'"
      else
        sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '${kinitcmd_smoke_test_user} ${destdir}/hivesmoke.sh'"
      fi
      export HIVE_EXIT_CODE=`ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${kinitcmd} hadoop \
      fs -test -e /apps/hive/warehouse/hivesmoke$$ > /dev/null 2>&1; echo \\\$?'" | sed 's/[ \r]//g'`
    if [[ "$HIVE_EXIT_CODE" -ne "0" ]] ; then  echo0 "Hive Smoke Test: Failed" ; \
      return 1 ; else echo0 "Hive Smoke Test: Passed " ; fi
    fi
  }

  ############################################################
  # FUNCTION TO INITIATE SMOKE TEST ON ZOOKEEPER
  ############################################################
  runZkSmokeTest() {
    if [ "$installzk" == "yes" ] ; then
      export ZOOKEEPER_EXIT_CODE=0
      echo0 "Zookeeper smoke test - create root znode and \
        verify data consistency across the quorum"

      zk_node1=`echo $zkhosts | tr ' ' '\n' | head -1`
      #as a workaround for ZOOKEEPER-999
      local setup_cmd="source ${zkconfdir}/zookeeper-env.sh ; export ZOOCFGDIR=$zkconfdir"
      # Delete /zk_smoketest znode if exists
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '$setup_cmd ; echo delete /zk_smoketest | ${zkhome}/bin/zkCli.sh -server $zk_node1:2181' "
      # Create /zk_smoketest znode on one zookeeper server
      sshgwforsmoke "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '$setup_cmd ; echo create /zk_smoketest smoke_data | ${zkhome}/bin/zkCli.sh -server $zk_node1:2181' "

      for i in $zkhosts ; do
        # Verify the data associated with znode across all the nodes in the zookeeper quorum
        output=$(ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '$setup_cmd ; echo get /zk_smoketest | ${zkhome}/bin/zkCli.sh -server $i:2181'")
        echo $output | grep smoke_data
        if [[ $? -ne 0 ]] ; then
          echo "Data associated with znode /zk_smoketests is not consistent on host $i"
          ((ZOOKEEPER_EXIT_CODE=$ZOOKEEPER_EXIT_CODE+1))
        fi
      done

      ssh2gwwithreturnvalue "$SUDOUSERPREFIX ${smoke_test_user} $SUDOCMDOPTION '$setup_cmd ; echo delete /zk_smoketest | ${zkhome}/bin/zkCli.sh -server $zk_node1:2181'"
      if [[ "$ZOOKEEPER_EXIT_CODE" -ne "0" ]] ; then echo0 "Zookeeper Smoke Test: Failed" ; \
        dumpErrorExitStatus "SMOKE_TEST" "Zookeeper Smoke Test Failed"; \
        exit 1 ; else echo0 "Zookeeper Smoke Test: Passed" ; fi
    fi
  }

  ############################################################
  # FUNCTION TO STOP VARIOUS SERVICES
  ############################################################

  stopTempleton() {
    if [[ "$installtempleton" != "yes" ]] ; then
      return
    fi
    echo0 "Stopping Templeton Server"
    #stop each templeton server
    for i in $ttonhosts
    do
      ssh2host "${i}" "$SUDOUSERPREFIX ${templetonuser} $SUDOCMDOPTION \
          '/usr/sbin/templeton_server.sh stop' "
    done
  }

  stopOozie() {
    if [[ "$installoozie" != "yes" ]] ; then
      return
    fi
    echo0 "Stopping Oozie Server"
    stopoozieserver="${ooziehome}/bin/oozie-stop.sh"
    ssh2host "${oozieshost}" "$SUDOUSERPREFIX ${oozieuser} $SUDOCMDOPTION '${stopoozieserver}'"
  }

  #TODO replace this for hive, but how do we stop hive????
  stopHive() {
    if [[ "$installhive" != "yes" ]] ; then
      return
    fi
    echo0 "Stopping Hive Metastore Server"
    #stop all processes running as hive
    stophive="ps aux | awk '{print \\\$1,\\\$2}' | grep $hiveuser | awk '{print \\\$2}' | xargs kill"
    ssh2host "${hivehost}" "$SUDOUSERPREFIX ${hiveuser} $SUDOCMDOPTION \"${stophive}\""
  }

  stopHbase() {
    if [[ "$installhbase" != "yes" ]] ; then
      return
    fi
    echo0 "Stopping HBase"
    stophbasemaster="${hbasehome}/bin/hbase-daemon.sh --config ${hbaseconfdir} stop master"
    stophbasers="${hbasehome}/bin/hbase-daemon.sh --config ${hbaseconfdir} stop regionserver"
    ssh2host "$(echo $rshosts | tr " " ",")" "$SUDOUSERPREFIX ${hbaseuser} $SUDOCMDOPTION '${stophbasers}'"
    sleep 5
    ssh2host "${hbmhost}" "$SUDOUSERPREFIX ${hbaseuser} $SUDOCMDOPTION '${stophbasemaster}'"
  }

  stopZk() {
    if [[ "$installzk" != "yes" ]] ; then
      return
    fi
    echo0 "Stopping Zookeeper"
    stopzkServer="${zkhome}/bin/zkServer.sh stop >> ${zk_log_dir}/zoo.out 2>&1"
    for zk in $zkhosts
    do
      sleep 5
      # since ZOOKEEPER-999 is not there, as a workaround source zookeeper-env.sh before stopping
      ssh2host "${zk}" "$SUDOUSERPREFIX ${zkuser} $SUDOCMDOPTION 'source ${zkconfdir}/zookeeper-env.sh ; export ZOOCFGDIR=$zkconfdir ; $stopzkServer'"
    done
  }

  stopMapReduce() {
    echo0 "Stopping MapReduce"
    stopjt="$hadoop_daemon stop jobtracker"
    stoptt="$hadoop_daemon stop tasktracker"
    stophs="$hadoop_daemon stop historyserver"
    ssh2host "${hadoopslavenodes}" "$SUDOUSERPREFIX ${mapreduser} $SUDOCMDOPTION '${stoptt}'"
    sleep 5
    ssh2host "${jthost}" "$SUDOUSERPREFIX ${mapreduser} $SUDOCMDOPTION '${stophs}; ${stopjt}'"
  }

  stopHdfs() {
    echo0 "Stopping HDFS"
    stopnamenode="$hadoop_daemon stop namenode"
    stopsnamenode="$hadoop_daemon stop secondarynamenode"
    stopdn="$hadoop_daemon stop datanode"
	

    if [[ "$security" == "yes" ]] ; then
      ssh2host "${hadoopslavenodes}" "${stopdn}"
    else
      ssh2host "${hadoopslavenodes}" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '${stopdn}'"
    fi
    sleep 5
    ssh2host "${snhost}" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '$stopsnamenode' "
    sleep 5
    ssh2host "${nnhost}" "$SUDOUSERPREFIX ${hdfsuser} $SUDOCMDOPTION '$stopnamenode' "
  }
