#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#

  ############################################################
  # HANDY UTILITIES FOR EVERYONE   
  ############################################################

  # Log a message to the log file and stderr
  log0() {
    echo "$@" | tee -a $outlog 1>&2
  }
  
  line="==============================================================================="

  # Log a nice, fat line (for visual demarcation).
  log0_line() {
    log0 "$line"
  }

  # Log a message to the log file and stderr, additionally sandwiching it 
  # between 2 calls to log0_line. 
  #  
  # Meant for start-of-section type messages.
  echo0() {
    log0_line
    log0 "$@"
    log0_line
  }

  ############################################################
  #FUNCTION TO VALIDATE USER INPUT
  ############################################################
  validate() {
    sample=$1
    case $sample in
      n|no|No|N|false|FALSE|False)
         echo no;
         ;;
      "")
         echo yes;
         ;;
      *)
         echo yes;
         ;;
    esac
  }

  validatefalse() {
    sample=$1
    case $sample in
      y|yes|Yes|Y|YES|true|TRUE|True)
        echo yes;
        ;;
      "")
        echo no;
        ;;
      *)
        echo no;
        ;;
    esac
  }
