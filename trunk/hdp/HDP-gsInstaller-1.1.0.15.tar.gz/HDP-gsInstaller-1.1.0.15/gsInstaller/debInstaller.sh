#! /bin/bash

#/**
#
#* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

 ############################################################
  # NOT SUPPORTED YET - WORK IN PROGRESS
  ############################################################
  installhadoopdeb() {
    if [ "$installpkg" == "deb" ] ; then
      sshall "[ ! -d /etc/profile.d ] && mkdir -p /etc/profile.d "
      echo0 "Installing hadoop deb"
      sshall "export JAVA_HOME=$javahome ; $WGET --random-wait -q $hadoopdeburl -O /tmp/hadoop.deb; dpkg -i /tmp/hadoop.deb"
    fi
  }

  ############################################################
  # NOT SUPPORTED YET - WORK IN PROGRESS
  ############################################################
  installpigdeb() {
    if [[ "$installpig" == "yes" && $installpkg == "deb" ]] ; then
     sshgw "$WGET -q $pigdeburl -O /tmp/pig.deb ; dpkg -i /tmp/pig.deb"
    fi
  }

  ############################################################
  #FUNCTION NOT SUPPORTED YET - WORK IN PROGRESS
  ############################################################
  installhbasedeb() {
    if [[ "$installhbase" == "yes" && $installpkg == "deb" ]] ; then
      zk_cmd="rm -rf /tmp/zookeeper.tar.gz; $WGET -q $zookeepertarurl -o /tmp/zookeeper.tar.gz; \
        cd /usr/share/hbase/lib; tar xvzf zookeeper.tar.gz  --strip-components 1 zookeeper-*/zookeeper-*.jar"
      sshhbm "$WGET $hbasedeburl -O /tmp/hbase.deb ; dpkg -i /tmp/hbase.deb"
      sshnodes "$WGET $hbasedeburl -O /tmp/hbase.deb ; dpkg -i /tmp/hbase.deb"
    fi
  }


