#/**
##* Copyright 2011, Hortonworks Inc.  All rights reserved.
#
#* Licensed under the Apache License, Version 2.0 (the "License");
#* you may not use this file except in compliance with the License.
#* You may obtain a copy of the License at
#
#* http://www.apache.org/licenses/LICENSE-2.0
#
#* Unless required by applicable law or agreed to in writing, software
#* distributed under the License is distributed on an "AS IS" BASIS,
#* WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#* See the License for the specific language governing permissions and
#* limitations under the License.
#
#*/

#! /bin/bash
#
# monLib.sh - Libraries for the monInstaller

# Print the contents of a file.  If an error message is given it is
# printed for missing files.
file_contents() {
        local fname=$1
        local msg=$2

        if [[ -f $fname ]]; then
                cat $fname
        elif [[ -n "$msg" ]]; then
                log0 "error: $msg"
        fi
}

# Given a list of file names, print the unique non-blank lines from
# those files
uniq_contents() {
        local fname
        for fname in "$@"; do
                file_contents $fname
        done | sort -u
}

# Given a list, print the unique space separated values
uniq_list() {
        for s in "$@"; do
                echo $s
        done | sort -u
}

# print a comma separated string of the given args
join_comma() {
        local result=""
        for s in "$@"; do
                result="$result,$s"
        done
        echo ${result#?}
}


####################################################
# MONITORING VARIABLES 

# The tested variables are themselves defined in gsLib.sh
[[ -z "$nagioshost" ]] && installnagios=no
[[ -z "$gangliahost" || -z "$gangliaweb" ]] && installganglia=no
[[ -z "$dashboardhost" ]] && installdashboard=no

####################################################

################################################################
# FUNCTION TO COLLECT  ALL HOSTS TO INSTALL
################################################################
moncollectserverlist() {
  montargets=`uniq_contents nodes jobtracker \
              namenode snamenode hbasemaster hivemetastore \
              hbasenodes zknodes gangliaserver gangliaweb \
              nagiosserver oozieserver templetonnode`
  #make sure its all lower case
  montargets="`echo $montargets | tr '[:upper:]' '[:lower:]'`"
  
  gangliaclients=""
  for host in $montargets; do
    if [ $host != $gangliahost ] ; then
      gangliaclients="${host} ${gangliaclients}"
    fi
  done
}

################################################################
# FUNCTION TO SHOW INSTALL SELECTION 
################################################################
mondisplayselection() {
        echo0 "Monitoring Details"
        log0 "installsnmp     : $installsnmp"
        log0 "installnagios   : $installnagios"
        log0 "installganglia  : $installganglia"
        log0 "installdashboard  : $installdashboard"
        if [[ -n "$nagioshost"  &&  "$installnagios" == "yes" ]]; then
                log0 "Nagios Server   : $nagioshost"
        fi
        if [[ -n "$gangliahost"  &&  "$installganglia" == "yes" ]]; then
                log0 "Ganglia Server  : $gangliahost"
                log0 "Ganglia Web     : $gangliaweb"
        fi
        if [[ -n "$dashboardhost" && "$installdashboard" == "yes" ]]; then
                log0 "Dashboard Host  : $dashboardhost"
        fi
        if [[ "$monitor_config_only" == "yes" ]]; then
                log0 "Only configuring the monitor, not installing any packages."
        fi
        log0 "install targets : (servers)"
        for host in $montargets; do
                log0 "                  $host"
        done
        log0_line
}

# scp a file to the root user on a remote server
# usage: xscp NODE SRC DST
xscp() {
        local host=$1
        local src=$2
        local dst=$3

        log0 "on $host"
        if [[ -z "$sshkey" ]]; then
                scp $src root@${host}:$dst >> $outlog 2>&1
        else
                scp -i ${sshkey} $src root@${host}:$dst >> $outlog 2>&1
        fi
}

# ssh and run a command as the root user on a remote server.  Log and
# print the result.
# usage: xsh NODE CMD
xssh_tee() {
        local host=$1
        shift
        local cmd="$@"

        log0 "on $host"
        if [[ -z "$sshkey" ]]; then
                ssh -t -q root@${host} $cmd 2>&1 | tee -a $outlog
        else
                ssh -t -q -i ${sshkey} root@${host} $cmd 2>&1 | tee -a $outlog
        fi
}

# ssh and run a command as the root user on a remote server.  Log the
# result.
# usage: xsh NODE CMD
xssh() {
        xssh_tee "$@" >/dev/null
}

############################################################
# FUNCTION TO SCP ALL HOSTS 
############################################################
monscpall() {
  local src=$1
  local dst=$2
  if [[ "x${usepdsh}" == "xyes" ]]; then
    pdshScpExec `commaSeparatedHostList ${montargets}` ${deployuser} $src $dst
  else
    for host in $montargets; do
      xscp $host $src $dst
    done
  fi
}

############################################################
# FUNCTION TO SSH ALL HOSTS 
############################################################
monsshall () {
  local cmd="$@"
  if [ "x${usepdsh}" == "xyes" ]; then
    pdshExec `commaSeparatedHostList ${montargets}` ${deployuser} $cmd
  else
    for host in $montargets; do
      xssh $host $cmd
    done
  fi
}

############################################################
# FUNCTION TO SSH TO ALL HOSTS EXCEPT THE GANGLIA SERVER
############################################################
sshgangliaclients () {
  local cmd="$@"
  if [ "x${usepdsh}" == "xyes" ]; then
    pdshExec `commaSeparatedHostList ${gangliaclients}` ${deployuser} $cmd
  else
    for host in ${gangliaclients}; do
      xssh $host $cmd
    done
  fi
}

############################################################
# FUNCTION TO SCP TO ALL HOSTS EXCEPT THE GANGLIA SERVER
############################################################
scp2gangliaclients() {
  local src=$1
  local dst=$2
  if [ "x${usepdsh}" == "xyes" ]; then
    pdshScpExec `commaSeparatedHostList ${gangliaclients}` ${deployuser} \
        $src $dst
  else
    for host in ${gangliaclients}; do
      xscp $host $src $dst
    done
  fi
}

############################################################
# FUNCTION TO SSH GANGLIASERVER
############################################################
sshgangliaserver () {
        [ "$jobdesc" != "" ] && echo "$jobdesc ${gangliahost}" && jobdesc=""
        xssh $gangliahost "$@"
}

############################################################
# FUNCTION TO SCP TO GANGLIASERVER
############################################################
scp2gangliaserver () {
        xscp $gangliahost $1 $2
}

############################################################
# FUNCTION TO SSH NAGIOSSERVER
############################################################
sshnagios () {
        [ "$jobdesc" != "" ] && echo "$jobdesc ${nagioshost}" && jobdesc=""
        xssh $nagioshost "$@"
}

############################################################
# FUNCTION TO SCP TO NAGIOSSERVER
############################################################
scp2nagios () {
        xscp $nagioshost $1 $2
}

############################################################
# FUNCTION TO SSH TO DASHBOARD HOST
############################################################
sshdashboard () {
        [ "$jobdesc" != "" ] && echo "$jobdesc ${dashboardhost}" && jobdesc=""
        xssh $dashboardhost "$@"
}

############################################################
# FUNCTION TO SCP TO DASHBOARD HOST
############################################################
scp2dashboard () {
        xscp $dashboardhost $1 $2
}

############################################################
## FUNCTION TO INITIATE SNMP SMOKETESTS 
## using standard snmpget - common to all platforms
############################################################
netsnmpsmoketest() {
        if [[ "$installsnmp" == "yes" ]] ; then
                echo0 "Start SNMP smoke test"
                pingsnmp
                echo0 "END SNMP smoke test"
        fi
}

############################################################
# FUNCTION TO SNMP-PING  ALL HOSTS 
## using standard snmpget - common to all platforms
############################################################
pingsnmp() {
        for host in $montargets; do
                log0 "on $host"
                target=`snmpget -v2c -c $snmpcommunity -Os $host system.sysUpTime.0 | tee -a $outlog | awk '{ print $1 }'`
                if [[ $target == "sysUpTimeInstance" ]]; then
                        log0 "$host snmp OK"
                else
                        log0 "$host snmp FAIL"
                fi

        done
}
############################################################
## FUNCTION TO INITIATE NAGIOS SMOKETESTS 
## (calls pingnagios which is at this point specific per platform
############################################################
nagiossmoketest() {
        if [[ "$installnagios" == "yes"  ]] ; then
                echo0 "Start Nagios smoke test"
                pingnagios
                echo0 "END Nagios smoke test"
        fi

        # TODO should test nagios_alerts.php also
}
############################################################
## FUNCTION TO INITIATE GANGLIA SMOKETESTS 
## (calls pingganglia which is at this point specific per platform
############################################################
gangliasmoketest() {
        if [[ "$installganglia" == "yes"  ]] ; then
                echo0 "Start Ganglia smoke test"
                pingganglia
                echo0 "END Ganglia smoke test"
        fi
}

verify_start_time() {
  ofile=$1
  matchtoken=$2
  cmd="cat ${ofile} | awk -F \",\" '{
        for(i=1; i<=NF; i++) { \
          if ( \$i ~ /${matchtoken}\":.*/ ) { \
            tokencnt=split(\$(i), awktokens, \":\"); \
            if ( tokencnt == 2 ) { \
              print awktokens[2]; \
            } \
            break; \
          } \
        } \
      }' | sed -e \"s/ //g\";"
  starttime=`eval $cmd`
  # check time > 2011 Jan 1st
  if [[ ${starttime} < 1293840000 ]]; then
    log0 "Invalid start time < Jan 1st 2011 00:00:00"
    return 1
  fi
  return 0
}

verify_cluster_output() {
  echo "Checking overall cluster response"
  ofile=$1
  ret=`cat ${ofile} | grep "\"namenode_addr\":\"$public_nnhost" | wc -l`
  if [[ "$ret" == "0" ]]; then
    log0 "Did not find namenode_addr in cluster output"
    return 1
  fi
  ret=`cat ${ofile} | grep "\"jobtracker_addr\":\"$public_jthost" | wc -l`
  if [[ "$ret" == "0" ]]; then
    log0 "Did not find jobtracker_addr in cluster output"
    return 1
  fi
  if [[ "$installhbase" == "yes" ]]; then
    ret=`cat ${ofile} | grep "\"hbasemaster_addr\":\"$public_hbmhost" | wc -l`
    if [[ "$ret" == "0" ]]; then
      log0 "Did not find hbasemaster_addr in cluster output"
      return 1
    fi
  else
    ret=`cat ${ofile} | grep "\"hbase_installed\":false" | wc -l`
    if [[ "$ret" == "0" ]]; then
      log0 "Did not find hbase_installed set to false in cluster output"
      return 1
    fi
  fi

  for svc in namenode jobtracker hbasemaster
  do
    if [[ "$svc" == "hbasemaster" && "$installhbase" != "yes" ]]; then
      continue
    fi
    verify_start_time ${ofile} "${svc}_starttime"
    ret=$?
    if [[ "$ret" != "0" ]]; then
      log0 "Invalid ${svc} start time < Jan 1st 2011 00:00:00"
      return 1
    fi
  done

  return 0
}

verify_hdfs_output() {
  echo "Checking hdfs response"
  ofile=$1
  ret=`cat ${ofile} | grep "\"namenode_addr\":\"$public_nnhost" | wc -l`
  if [[ "$ret" == "0" ]]; then
    log0 "Did not find namenode_addr in hdfs output"
    return 1
  fi

  verify_start_time ${ofile} "start_time"
  ret=$?
  if [[ "$ret" != "0" ]]; then
    log0 "Invalid ${public_nnhost} start time < Jan 1st 2011 00:00:00"
    return 1
  fi
  return 0
}

verify_mapreduce_output() {
  log0 "Checking mapreduce response"
  ofile=$1
  ret=`cat ${ofile} | grep "\"jobtracker_addr\":\"$public_jthost" | wc -l`
  if [[ "$ret" == "0" ]]; then
    log0 "Did not find jobtracker in hdfs output"
    return 1
  fi

  verify_start_time ${ofile} "start_time"
  ret=$?
  if [[ "$ret" != "0" ]]; then
    log0 "Invalid ${public_jthost} start time < Jan 1st 2011 00:00:00"
    return 1
  fi
  return 0
}

verify_hbase_output() {
  ofile=$1

  if [[ "$installhbase" == "yes" ]]; then
    # check valid hbase output
    log0 "Checking hbase response"
    ret=`cat ${ofile} | grep "\"hbasemaster_addr\":\"$public_hbmhost" | wc -l`
    if [[ "$ret" == "0" ]]; then
      log0 "Did not find hbasemaster_addr in hdfs output"
      return 1
    fi
    verify_start_time ${ofile} "start_time"
    ret=$?
    if [[ "$ret" != "0" ]]; then
      log0 "Invalid ${public_hbmhost} start time < Jan 1st 2011 00:00:00"
      return 1
    fi
    ret=`cat ${ofile} | grep "\"hbase_installed\":true" | wc -l`
    if [[ "$ret" == "0" ]]; then
      log0 "Did not find hbase_installed set to true in hbase output"
      return 1
    fi
  else
    # check install flag is false
    log0 "Checking hbase installed false response"
    ret=`cat ${ofile} | grep "\"hbase_installed\":false" | wc -l`
    if [[ "$ret" == "0" ]]; then
      log0 "Did not find hbase_installed set to false in hbase output"
      return 1
    fi
  fi
  return 0
}

verify_ganglia_webservices() {
  tmpfile="/tmp/monrpmsinstall_ganglia_ws.$$.out"
  for context in dashboard hdfs mapreduce hbase; do
    for collection in all hdp; do
      rm -f $tmpfile
      cmd="/usr/bin/wget -q -t 1 -T 2 -O $tmpfile \
          \"http://${dashboardhost}/hdp/dashboard/dataServices/ganglia/get_graph_info.php?context=${context}&collection=${collection}\" "
      eval $cmd
      ret=$?
      if [[ "$ret" != "0" || ! -f ${tmpfile} ]]; then
        log0 "Error: Invalid response when trying to query dashboard using $cmd"
        rm -f ${tmpfile}
        return 1
      fi
    done
  done
  rm -f ${tmpfile}
  return 0
}

cleanup_dashboard_smoketest_files() {
  # CLEANUP
  cmd="rm -f /tmp/monrpmsinstall_cluster_jmx.$$.out \
      /tmp/monrpmsinstall_hdfs_jmx.$$.out \
      /tmp/monrpmsinstall_mapreduce_jmx.$$.out \
      /tmp/monrpmsinstall_hbase_jmx.$$.out \
      /tmp/monrpmsinstall_ganglia_ws.$$.out"
  eval $cmd
}

############################################################
## FUNCTION TO INITIATE BACKEND DASHBOARD SCRIPTS SMOKETESTS
############################################################
backenddashboardsmoketest() {
  # Check JMX Webservices
  cmd="/usr/bin/wget -q -t 1 -T 2 -O /tmp/monrpmsinstall_cluster_jmx.$$.out \
    \"http://${dashboardhost}/hdp/dashboard/dataServices/jmx/get_jmx_info.php?info_type=cluster\" "
  eval $cmd
  if [[ "$?" != "0" ]]; then
    log0 "Error: Invalid response when trying to query dashboard using $cmd"
    return 1
  fi
  cmd="/usr/bin/wget -q -t 1 -T 2 -O /tmp/monrpmsinstall_hdfs_jmx.$$.out \
    \"http://${dashboardhost}/hdp/dashboard/dataServices/jmx/get_jmx_info.php?info_type=hdfs\" "
  eval $cmd
  if [[ "$?" != "0" ]]; then
    log0 "Error: Invalid response when trying to query dashboard using $cmd"
    return 1
  fi
  cmd="/usr/bin/wget -q -t 1 -T 2 -O /tmp/monrpmsinstall_mapreduce_jmx.$$.out \
    \"http://${dashboardhost}/hdp/dashboard/dataServices/jmx/get_jmx_info.php?info_type=mapreduce\" "
  eval $cmd
  if [[ "$?" != "0" ]]; then
    log0 "Error: Invalid response when trying to query dashboard using $cmd"
    return 1
  fi
  cmd="/usr/bin/wget -q -t 1 -T 2 -O /tmp/monrpmsinstall_hbase_jmx.$$.out \
    \"http://${dashboardhost}/hdp/dashboard/dataServices/jmx/get_jmx_info.php?info_type=hbase\" "
  eval $cmd
  if [[ "$?" != "0" ]]; then
    log0 "Error: Invalid response when trying to query dashboard using $cmd"
    return 1
  fi

  # TODO check ganglia webservice
  verify_ganglia_webservices
  if [[ "$?" != "0" ]]; then
    log0 "Error: Verify ganglia webservices on dashboard failed"
    return 1
  fi

  # CHECK
  if [[ ! -f /tmp/monrpmsinstall_cluster_jmx.$$.out \
        || ! -f /tmp/monrpmsinstall_hdfs_jmx.$$.out \
        || ! -f /tmp/monrpmsinstall_mapreduce_jmx.$$.out \
        || ! -f /tmp/monrpmsinstall_hbase_jmx.$$.out ]]; then
    log0 "Error: Dashboard wget calls failed"
    return 1
  fi

  # check cluster output
  verify_cluster_output /tmp/monrpmsinstall_cluster_jmx.$$.out
  ret=$?
  if [[ "$ret" != "0" ]]; then
    log0 "Error: verify cluster output failed"
    return 1
  fi

  # check hdfs output
  verify_hdfs_output /tmp/monrpmsinstall_hdfs_jmx.$$.out
  ret=$?
  if [[ "$ret" != "0" ]]; then
    log0 "Error: verify hdfs output failed"
    return 1
  fi

  # check mapreduce output
  verify_mapreduce_output /tmp/monrpmsinstall_mapreduce_jmx.$$.out
  ret=$?
  if [[ "$ret" != "0" ]]; then
    log0 "Error: verify mapreduce output failed"
    return 1
  fi

  # check hbase output
  verify_hbase_output /tmp/monrpmsinstall_hbase_jmx.$$.out
  ret=$?
  if [[ "$ret" != "0" ]]; then
    log0 "Error: verify hbase output failed"
    return 1
  fi

  return 0
}

############################################################
## FUNCTION TO INITIATE DASHBOARD FRONTEND SMOKETESTS
############################################################
dashboardsmoketest() {
  echo0 "Running Dashboard Smoke tests"
  if [[ "$installdashboard" == "yes" ]]; then
    backenddashboardsmoketest
    ret=$?
    cleanup_dashboard_smoketest_files
    if [[ "$ret" != "0" ]]; then
      log0 "Error: Dashboard Smoke Test failed"
      return 1
    fi
  fi
}


############################################################
## FUNCTION TO DISPLAY MON CLUSTER DETAILS
############################################################
monclusterdetails() {
  echo0 "Monitoring Details"
  if [[ -n "$nagioshost" && $installnagios == "yes" ]]; then
    echo "Nagios Server         : ${nagioshost}"
    echo "  Nagios Url          : ${nagioshost}/nagios"
  fi
  if [[ -n "$gangliaweb" && $installganglia == "yes" ]]; then
    echo "Ganglia Web Server    : ${gangliaweb}"
    echo "  Ganglia Url         : ${gangliaweb}/ganglia"
  fi
  if [[ -n "$dashboardhost" && $installdashboard == "yes" ]]; then
    echo "Monitoring Dashboard  : ${dashboardhost}/hdp/dashboard/ui/home.html"
  fi
}
